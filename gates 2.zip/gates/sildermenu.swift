//
//  sildermenu.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 06/06/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit


class sildermenu:UIView {
    
    @IBOutlet var sliderMenuView: UIView!
    @IBOutlet weak var stackViewft: UIStackView!
   
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupView()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        
        setupView()
    }
    
    func setupView() {
        let bundle = Bundle(for: type(of: self))
        UINib(nibName: "slidermenu", bundle: bundle).instantiate(withOwner: self, options: nil)
        
        addSubview(sliderMenuView)
        sliderMenuView.frame = bounds
        sliderMenuView.isUserInteractionEnabled = true
        sliderMenuView.backgroundColor = hexStringToUIColor(hex:"333134")
        
        
    }
   
     
    @IBAction func home(_ sender: Any) {
        
        let vcName = "HomePage"
        let storyboard: UIStoryboard = UIStoryboard (name: "Main", bundle: nil)
        let currentNavi = self.getCurrentNavigation()
        let viewCv = storyboard.instantiateViewController(withIdentifier: vcName)
        currentNavi?.pushViewController(viewCv, animated: true)
        
        
        
    }
    
    
    @IBAction func aboutGates(_ sender: Any) {
        
        
        let vcName = "AboutGatesCorporation"
        let storyboard: UIStoryboard = UIStoryboard (name: "Main", bundle: nil)
        let currentNavi = self.getCurrentNavigation()
        let viewCv = storyboard.instantiateViewController(withIdentifier: vcName)
        currentNavi?.pushViewController(viewCv, animated: true)
       
        
    }
    
    
    @IBAction func ProductSearch(_ sender: Any) {
        
        
        let vcName = "ProductSearch"
        let storyboard: UIStoryboard = UIStoryboard (name: "Main", bundle: nil)
        let currentNavi = self.getCurrentNavigation()
        let viewCv = storyboard.instantiateViewController(withIdentifier: vcName)
        currentNavi?.pushViewController(viewCv, animated: true)
        
    }
    
    
    @IBAction func Videos(_ sender: Any) {
        
        let gatesEmployee = UserDefaults.standard.string(forKey: "usertype")
        let distrubUser = UserDefaults.standard.bool(forKey: "distribuUser")
       var vcName:String!
        if gatesEmployee != "Gates Employee"{
        
        vcName = "trainLoginview"
        
        }
        else {
        
        if distrubUser {
            vcName = "trainLoginview"
        }
        else {
            vcName = "VideosCategory"
            
        }
        
        }
        let storyboard: UIStoryboard = UIStoryboard (name: "Main", bundle: nil)
        let currentNavi = self.getCurrentNavigation()
        let viewCv = storyboard.instantiateViewController(withIdentifier: vcName)
        currentNavi?.pushViewController(viewCv, animated: true)

       
        
    }
    
    @IBAction func WhatNew(_ sender: Any) {
        
        let vcName = "What'sNew"
        let storyboard: UIStoryboard = UIStoryboard (name: "Main", bundle: nil)
        let currentNavi = self.getCurrentNavigation()
        let viewCv = storyboard.instantiateViewController(withIdentifier: vcName)
        currentNavi?.pushViewController(viewCv, animated: true)

        
        
    }
    @IBAction func Schemes(_ sender: Any) {
        
        let vcName = "Schemes"
        let storyboard: UIStoryboard = UIStoryboard (name: "Main", bundle: nil)
        let currentNavi = self.getCurrentNavigation()
        let viewCv = storyboard.instantiateViewController(withIdentifier: vcName)
        currentNavi?.pushViewController(viewCv, animated: true)
        sliderMenuView.removeFromSuperview()

        
    }
    @IBAction func Notification(_ sender: Any) {
        
        let vcName = "Notification"
        let storyboard: UIStoryboard = UIStoryboard (name: "Main", bundle: nil)
        let currentNavi = self.getCurrentNavigation()
        let viewCv = storyboard.instantiateViewController(withIdentifier: vcName)
        currentNavi?.pushViewController(viewCv, animated: true)
       
        
    }
    @IBAction func Distribution(_ sender: Any) {
        
        
        let gatesEmployee = UserDefaults.standard.string(forKey: "usertype")
        
        if gatesEmployee != "Gates Employee"
            
        {
            let alertController = UIAlertController(title: "Alert", message: "You are not authorized to view this page!", preferredStyle: UIAlertControllerStyle.alert)
            let ok = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: {(action) -> Void in
                
            })
            
            alertController.addAction(ok)
          let currentView = self.getCurrentViewController()
            currentView?.present(alertController, animated: true, completion: nil)
            
        }
        else {
        
        let distrubUser = UserDefaults.standard.bool(forKey: "distribuUser")
        var vcName:String!
        if distrubUser {
        vcName = "distriLogin"
        }
        else {
        vcName = "distributionNetwork"
        
        }
        
        
        let storyboard: UIStoryboard = UIStoryboard (name: "Main", bundle: nil)
        let currentNavi = self.getCurrentNavigation()
        let viewCv = storyboard.instantiateViewController(withIdentifier: vcName)
        currentNavi?.pushViewController(viewCv, animated: true)
    }
    
    }
    @IBAction func Contact(_ sender: Any) {
        
        
        let vcName = "Contact"
        let storyboard: UIStoryboard = UIStoryboard (name: "Main", bundle: nil)
        let currentNavi = self.getCurrentNavigation()
        let viewCv = storyboard.instantiateViewController(withIdentifier: vcName)
        currentNavi?.pushViewController(viewCv, animated: true)
       
        
    }
    @IBAction func OtherLinks(_ sender: Any) {
        
        
        let vcName = "OtherLinks"
        let storyboard: UIStoryboard = UIStoryboard (name: "Main", bundle: nil)
        let currentNavi = self.getCurrentNavigation()
        let viewCv = storyboard.instantiateViewController(withIdentifier: vcName)
        currentNavi?.pushViewController(viewCv, animated: true)

      
    }
    
    @IBAction func EditProfile(_ sender: Any) {
        
        
        let vcName = "Edit"
        let storyboard: UIStoryboard = UIStoryboard (name: "Main", bundle: nil)
        let currentNavi = self.getCurrentNavigation()
        let viewCv = storyboard.instantiateViewController(withIdentifier: vcName)
        currentNavi?.pushViewController(viewCv, animated: true)


        
        
    }
    func getCurrentViewController() -> UIViewController? {
        
        if let rootController = UIApplication.shared.keyWindow?.rootViewController {
            var currentController: UIViewController! = rootController
            while( currentController.presentedViewController != nil ) {
                currentController = currentController.presentedViewController
            }
            return currentController
        }
        return nil
     }
    
    
    func getCurrentNavigation() -> UINavigationController? {
        
        if let rootController = UIApplication.shared.keyWindow?.rootViewController {
            var currentController: UIViewController! = rootController
            while( currentController.presentedViewController != nil ) {
                currentController = currentController.presentedViewController
            }
            return currentController as! UINavigationController?
        }
        return nil
    }
    
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.characters.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt32 = 0
        Scanner(string: cString).scanHexInt32(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
    
}
