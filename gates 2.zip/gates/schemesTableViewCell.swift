//
//  schemesTableViewCell.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 31/03/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit

class schemesTableViewCell: UITableViewCell {

    @IBOutlet var lbl1: UILabel!
    @IBOutlet var lbl2: UILabel!
    @IBOutlet var lbl3: UILabel!
    @IBOutlet weak var moredetails: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
