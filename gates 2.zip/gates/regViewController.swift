//
//  regViewController.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Naddy on 10/03/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit
import CoreData

class regViewController: UIViewController,UITextFieldDelegate{

 
    @IBOutlet var main: UIView!
//    @IBOutlet var dropdown: DropMenuButton!
    @IBOutlet var emailupdate: UIButton!
    @IBOutlet var mobileupdates: UIButton!
    @IBOutlet var conditionupdates: UIButton!
    @IBOutlet weak var register: UIButton!
    @IBOutlet weak var skip: UIButton!
    var isclicked:Bool!
    var emailupdateconf:Bool!
    var mobileupdatesconf:Bool!
    var conditionupdatesconf:Bool!
    var textbox:String? = "All"
    var typeuser:String? = "End Users"
    let activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.whiteLarge)
    var idc:Int! = 0
   
    @IBOutlet weak var conditionbuttton: UIButton!
    @IBOutlet weak var drop2: UIDropDown!
    @IBOutlet weak var drop3: UIDropDown3!
    @IBOutlet var Name: UILabel!
    @IBOutlet var NameTextField: UITextField!
    @IBOutlet var Email: UILabel!
    @IBOutlet var EmailTextField: UITextField!
    @IBOutlet var Mobile: UILabel!
    @IBOutlet var MobileTextField: UITextField!
    @IBOutlet var Address: UILabel! // state
    @IBOutlet var AddressTextField: UITextField!
    @IBOutlet var Address2: UILabel! // city
    @IBOutlet var AddressTextField2: UITextField!
    @IBOutlet var Address3: UILabel! // pinncode
    @IBOutlet var AddressTextField3: UITextField!
    @IBOutlet var Address4: UILabel! // address1
    @IBOutlet var AddressTextField4: UITextField!
    @IBOutlet var Address5: UILabel! // address2
    @IBOutlet var AddressTextField5: UITextField!
    @IBOutlet var CompanyName: UILabel!
    @IBOutlet var CompanyNameTextField: UITextField!
    @IBOutlet var TypeOfUser: UILabel!
//    @IBOutlet var TypeOfUserTextField: dropMenuButton2!
    @IBOutlet weak var countrycode: UILabel!
    var mobileNumber = ""
    
    var checked = UIImage(named:"checkbox1")
    var unchecked = UIImage(named:"unchecked_checkbox_1")
 
    var myMutableString2 = NSMutableAttributedString(
        string: "Company Name",
        attributes: [:])

    var myMutableString3 = NSMutableAttributedString(
        string: "User Type",
        attributes: [:])
    var myMutableString = NSMutableAttributedString(
        string: "Mobile",
        attributes: [:])
    var myMutableString4 = NSMutableAttributedString(
        string: "State",
        attributes: [:])
    var myMutableString5 = NSMutableAttributedString(
        string: "City",
        attributes: [:])
    
    
    
    
    func notstar(){
        myMutableString2 = NSMutableAttributedString(
            string: "Company Name",
            attributes: [:])
        
        myMutableString3 = NSMutableAttributedString(
            string: "User Type",
            attributes: [:])
        myMutableString = NSMutableAttributedString(
            string: "Mobile",
            attributes: [:])
        myMutableString4 = NSMutableAttributedString(
            string: "State",
            attributes: [:])
        myMutableString5 = NSMutableAttributedString(
            string: "City",
            attributes: [:])
        
        Mobile.attributedText = myMutableString
        CompanyName.attributedText = myMutableString2
        TypeOfUser.attributedText = myMutableString3
        Address.attributedText = myMutableString4
        Address2.attributedText = myMutableString5
        
    }
    
    
    func star(){
        myMutableString2 = NSMutableAttributedString(
            string: "Company Name*",
            attributes: [:])
        
        myMutableString3 = NSMutableAttributedString(
            string: "User Type*",
            attributes: [:])
        myMutableString = NSMutableAttributedString(
            string: "Mobile*",
            attributes: [:])
        myMutableString4 = NSMutableAttributedString(
            string: "State*",
            attributes: [:])
        myMutableString5 = NSMutableAttributedString(
            string: "City*",
            attributes: [:])
        myMutableString.addAttribute(
            NSForegroundColorAttributeName,
            value: UIColor.red,
            range: NSRange(
                location:6,
                length:1))
        
        
        myMutableString2.addAttribute(
            NSForegroundColorAttributeName,
            value: UIColor.red,
            range: NSRange(
                location:12,
                length:1))
        myMutableString3.addAttribute(
            NSForegroundColorAttributeName,
            value: UIColor.red,
            range: NSRange(
                location:9,
                length:1))
        myMutableString4.addAttribute(
            NSForegroundColorAttributeName,
            value: UIColor.red,
            range: NSRange(
                location:5,
                length:1))
        myMutableString5.addAttribute(
            NSForegroundColorAttributeName,
            value: UIColor.red,
            range: NSRange(
                location:4,
                length:1))
        
        Mobile.attributedText = myMutableString
        CompanyName.attributedText = myMutableString2
        TypeOfUser.attributedText = myMutableString3
        Address.attributedText = myMutableString4
        Address2.attributedText = myMutableString5
        
    }
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = true

    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        activityIndicator.center = CGPoint(x: view.bounds.size.width/2, y: view.bounds.size.height/2)
        activityIndicator.color = UIColor.red
        view.addSubview(activityIndicator)

        emailupdate.layer.cornerRadius = 6
        mobileupdates.layer.cornerRadius = 6
        register.layer.cornerRadius = 5
        skip.layer.cornerRadius = 5
        
        let imageView = UIImageView(frame: self.view.frame)
        let image = UIImage(named: "background-2")!
        imageView.image = image
        self.view.addSubview(imageView)
        
        
        
        self.view.sendSubview(toBack: imageView)

//        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(trainingVideoLoginPageViewController.dismissKeyboard))
//        view.addGestureRecognizer(tap)
        
        NameTextField.delegate = self
        EmailTextField.delegate = self
        MobileTextField.delegate = self
        AddressTextField.delegate = self
        AddressTextField2.delegate = self
        AddressTextField3.delegate = self
        AddressTextField4.delegate = self
        AddressTextField5.delegate = self
        CompanyNameTextField.delegate = self
        countrycode.layer.masksToBounds = true
        countrycode.layer.cornerRadius = 5
        
        isclicked = false
        emailupdateconf = false
        mobileupdatesconf = false
        conditionupdatesconf = false
        
        
        
       
        Mobile.attributedText = myMutableString
        CompanyName.attributedText = myMutableString2
        TypeOfUser.attributedText = myMutableString3
        Address.attributedText = myMutableString4
        Address2.attributedText = myMutableString5

        NameTextField.resignFirstResponder()
                EmailTextField.resignFirstResponder()
        MobileTextField.resignFirstResponder()
        
        
        
        drop3.cornerRadius = 5
        drop3.borderColor = UIColor.clear
        drop3.textColor = UIColor.white
        drop3.layer.borderColor = UIColor.white.cgColor
        drop3.placeholder = "Select"
        drop3.options = ["Select","Brunei","Cambodia","Indonesia","Malaysia","Myanmar","Philippines","Singapore","Thailand","Vietnam"]
        drop3.didSelect { (option, index) in
            
            switch index {
            case 0:
                self.notstar()
                self.countrycode.text = ""
                self.textbox = ""
            case 1:
                self.textbox = "Brunei"
                self.countrycode.text = "673"
                self.notindia()
                self.star()

            case 2:
                self.textbox = "Cambodia"
                self.countrycode.text = "855"
                self.notindia()
                self.star()
                
            case 3:
                self.textbox = "Indonesia"
                self.countrycode.text = "62"
                self.notindia()
                self.star()
             
            case 4:
                self.textbox = "Malaysia"
                self.countrycode.text = "60"
                self.notindia()
                self.star()
                
            case 5:
                self.textbox = "Myanmar"
                self.countrycode.text = "95"
                self.notindia()
                self.star()
                
            case 6:
                self.textbox = "Philippines"
                self.countrycode.text = "63"
                self.notindia()
                self.star()
                
            case 7:
                self.textbox = "Singapore"
                self.countrycode.text = "65"
                self.notindia()
                self.star()
                
            case 8:
                self.textbox = "Thailand"
                self.countrycode.text = "66"
                self.notindia()
                self.star()

            case 9:
                self.textbox = "Vietnam"
                self.countrycode.text = "84"
                self.notindia()
                self.star()
            default:
                break
            }
            
            
            
        }
        drop3.animationType = UIDropDownAnimationType.Default


        drop2.cornerRadius = 5
        drop2.borderColor = UIColor.clear
        drop2.textColor = UIColor.white
        drop2.layer.borderColor = UIColor.white.cgColor
        drop2.placeholder = "Select"
        drop2.options = ["Distributor", "Work Shop", "Part Shop","Gates Employee","End Users"]
        drop2.didSelect { (option, index) in
            self.typeuser = option
        }
        drop2.animationType = UIDropDownAnimationType.Default

    }
        //////////////

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        // Dispose of any resources that can be recreated.
    }
    @IBAction func save(_ sender: Any) {
//        
        
        UserDefaults.standard.set(false,forKey:"skipuser");
        UserDefaults.standard.synchronize();

        mobileNumber = "\(countrycode.text!)"+"\(MobileTextField.text!)"
        print(mobileNumber)
        if currentReachabilityStatus == .notReachable {
            alert()
        }
        else
        {
            if textbox == "" {
                
                 displayMyAlertMessage("Please select one country to download the data!")
                
            }
            
            else
            {
     
        if textbox != "India"
        {
            if typeuser == "" {
                if conditionupdatesconf == false {
                    
                    displayMyAlertMessage("Please accept to terms and conditions!")
                }
                else
                    
                {
                    json(params:["name":NameTextField.text!,"email":EmailTextField.text!,"mobileno":mobileNumber,"usertype":typeuser!,"state ":AddressTextField.text!,"city ":AddressTextField2.text!,"pincode":AddressTextField3.text!,"address1":AddressTextField4.text!,"address2":AddressTextField5.text!,"ReceivePromotions":mobileupdatesconf,"ReceiveUpdates":emailupdateconf!,"RegistrationType":"ios","Status":"Active","Date":"01-01-17","apppid":"ios","Password":"Muthu","Country":textbox!])
                }
            
            
        }
            else {

            if((MobileTextField.text?.isEmpty)! || (CompanyNameTextField.text?.isEmpty)! || (AddressTextField.text?.isEmpty)! || (AddressTextField2.text?.isEmpty)!)
        {
            
            // Display alert message
            
            displayMyAlertMessage("Fields marked with * are mandatory!");
            
            
            
            return;
        }
            else
            {
            
                
                if validate(value: MobileTextField.text!) == true {
                    if (typeuser?.isEmpty)! {
                        
                        displayMyAlertMessage("Please select the user type!");
                        
                    }
                    else {
                        
                        
                        
                        if typeuser == "Gates Employee"{
                            
                            
                            if(EmailTextField.text?.isEmpty)! {
                                displayMyAlertMessage("Please provide your Gates email id!");
                            }
                            else
                            {
                                if isValidEmail(testStr: EmailTextField.text!) == true {
                                    
                                    if (emailupdateconf == true && (EmailTextField.text?.isEmpty)!) {
                                    
                                    displayMyAlertMessage("Please enter your email id to receive latest update via email or uncheck the update via email option!")
                                    
                                    }
                                    
                                    else {
                   
                                        if conditionupdatesconf == false {
                                            
                                            displayMyAlertMessage("Please accept to terms and conditions!")
                                        }
                                        else
                                            
                                        {
                                            json(params:["name":NameTextField.text!,"email":EmailTextField.text!,"mobileno":mobileNumber,"usertype":typeuser!,"state ":AddressTextField.text!,"city ":AddressTextField2.text!,"pincode":AddressTextField3.text!,"address1":AddressTextField4.text!,"address2":AddressTextField5.text!,"ReceivePromotions":mobileupdatesconf,"ReceiveUpdates":emailupdateconf!,"RegistrationType":"ios","Status":"Active","Date":"01-01-17","apppid":"ios","Password":"Muthu","Country":textbox!])
                                        }
                                    }
                                }
                                else {
                                    displayMyAlertMessage("Please enter a valid Gates email id!")
                                    
                                }
                            }
                            ////////////
                        }
                        else {
                            
                            if (emailupdateconf == true && (EmailTextField.text?.isEmpty)!) {
                                
                                displayMyAlertMessage("Please enter your email id to receive latest update via email or uncheck the update via email option!")
                                
                            }
                                
                            else {
                                
                                if conditionupdatesconf == false {
                                    
                                    displayMyAlertMessage("Please accept to terms and conditions!")
                                }
                                else
                                    
                                {
                                    json(params:["name":NameTextField.text!,"email":EmailTextField.text!,"mobileno":mobileNumber,"usertype":typeuser!,"state ":AddressTextField.text!,"city ":AddressTextField2.text!,"pincode":AddressTextField3.text!,"address1":AddressTextField4.text!,"address2":AddressTextField5.text!,"ReceivePromotions":mobileupdatesconf,"ReceiveUpdates":emailupdateconf!,"RegistrationType":"ios","Status":"Active","Date":"01-01-17","apppid":"ios","Password":"Muthu","Country":textbox!])
                                }
                            }
                        
                        }
                        
                    }
                }
                else
                {
                    displayMyAlertMessage("Not valid Phone Number")
                }
                
            
            }
            
        }
        }
        else
        
        {
            if typeuser == "" {
                if conditionupdatesconf == false {
                    
                    displayMyAlertMessage("Please accept to terms and conditions!")
                }
                else
                    
                {
                    json(params:["name":NameTextField.text!,"email":EmailTextField.text!,"mobileno":mobileNumber,"usertype":typeuser!,"state ":AddressTextField.text!,"city ":AddressTextField2.text!,"pincode":AddressTextField3.text!,"address1":AddressTextField4.text!,"address2":AddressTextField5.text!,"ReceivePromotions":mobileupdatesconf,"ReceiveUpdates":emailupdateconf!,"RegistrationType":"ios","Status":"Active","Date":"01-01-17","apppid":"ios","Password":"Muthu","Country":textbox!])
                }
                
                
            }
            else {
            
            if((MobileTextField.text?.isEmpty)!)
            {
                
                // Display alert message
                
                displayMyAlertMessage("Fields marked with * are mandatory!");
                
                return;
                
            }
            
            else
            {
            
                if validate(value: MobileTextField.text!) == true {
                    if (typeuser?.isEmpty)! {
                    
                    displayMyAlertMessage("Please select the user type!");
                    
                    }
                    else {
                    
                    
                    
                        if typeuser == "Gates Employee"{
                            
                            
                            if(EmailTextField.text?.isEmpty)! {
                                displayMyAlertMessage("Please enter your Gates email id!");
                            }
                            else
                            {
                                if isValidEmail(testStr: EmailTextField.text!) == true {
                                    
                                    if (emailupdateconf == true && (EmailTextField.text?.isEmpty)!) {
                                        
                                        displayMyAlertMessage("Please enter your email id to receive latest update via email or uncheck the update via email option!")
                                        
                                    }
                                        
                                    else {
                                        if conditionupdatesconf == false {
                                        
                                            displayMyAlertMessage("Please accept to terms and conditions!")
                                        }
                                        else
 
                                        {
                                        json(params:["name":NameTextField.text!,"email":EmailTextField.text!,"mobileno":mobileNumber,"usertype":typeuser!,"state ":AddressTextField.text!,"city ":AddressTextField2.text!,"pincode":AddressTextField3.text!,"address1":AddressTextField4.text!,"address2":AddressTextField5.text!,"ReceivePromotions":mobileupdatesconf,"ReceiveUpdates":emailupdateconf!,"RegistrationType":"ios","Status":"Active","Date":"01-01-17","apppid":"ios","Password":"Muthu","Country":textbox!])
                                        }
                                    }
                                    
                                    
//
                                }
                                else {
                                    displayMyAlertMessage("Please enter a valid Gates email id!")
                                    
                                }
                            }
                            
                        }
                        else {
                            if (emailupdateconf == true && (EmailTextField.text?.isEmpty)!) {
                                
                                displayMyAlertMessage("Please enter your email ID to receive latest update via email or uncheck the update via email option!")
                                
                            }
                                
                            else {
                                
                                if conditionupdatesconf == false {
                                    
                                    displayMyAlertMessage("Please accept to terms and conditions!")
                                }
                                else
                                    
                                {
                                    json(params:["name":NameTextField.text!,"email":EmailTextField.text!,"mobileno":mobileNumber,"usertype":typeuser!,"state ":AddressTextField.text!,"city ":AddressTextField2.text!,"pincode":AddressTextField3.text!,"address1":AddressTextField4.text!,"address2":AddressTextField5.text!,"ReceivePromotions":mobileupdatesconf,"ReceiveUpdates":emailupdateconf!,"RegistrationType":"ios","Status":"Active","Date":"01-01-17","apppid":"ios","Password":"Muthu","Country":textbox!])
                                }
                            }
                        }
                    }
                }
                else
                {
                    displayMyAlertMessage("Please enter a valid phone number!")
                }
                
            
            }
        }
        }
        }
    }
    
       

        
}
    
    
    
    @IBAction func emailupdatesckd(_ sender: Any) {
        if isclicked == true {
         isclicked = false
        }
        else
        {
        isclicked = true
        }
        
        if isclicked == true
        {
            emailupdate.setImage(checked, for: .normal)
            emailupdateconf = true
        }
        else
        {
            emailupdate.setImage(unchecked, for: .normal)
            emailupdateconf = false
        }
    }
//
    @IBAction func mobileupdatesckd(_ sender: Any) {
        
        if isclicked == true {
            isclicked = false
        }
        else
        {
            isclicked = true
        }
        
        if isclicked == true
        {
            mobileupdates.setImage(checked, for: .normal)
            mobileupdatesconf = true
        }
        else
        {
            mobileupdates.setImage(unchecked, for: .normal)
            mobileupdatesconf = false
            
        }
    }
    
    @IBAction func conditionupdatesckd(_ sender: Any) {
        
        if isclicked == true {
            isclicked = false
        }
        else
        {
            isclicked = true
        }
        
        if isclicked == true
        {
            conditionupdates.setImage(checked, for: .normal)
            conditionupdatesconf = true
        }
        else
        {
            conditionupdates.setImage(unchecked, for: .normal)
            conditionupdatesconf = false
            
        }
        
    }
    
   
    
    
  
    
    
    func india() {
      
//        _: CGRect = UIScreen.main.bounds
         Address.isHidden = true // state
       AddressTextField.isHidden = true
    Address2.isHidden = true // city
        AddressTextField2.isHidden = true
         Address3.isHidden = true
        AddressTextField3.isHidden = true
        Address4.isHidden = true // address1
        AddressTextField4.isHidden = true
        Address5.isHidden = true // address2
        AddressTextField5.isHidden = true
    CompanyName.isHidden = true
    CompanyNameTextField.isHidden = true
    TypeOfUser.frame = CGRect(x:40, y:244, width: 100, height:25)
//        TypeOfUserTextField.frame = CGRect(x:170, y:244, width: screenSize.maxX - 190, height:25)
        
    }
    
    func notindia() {
        //let screenSize: CGRect = UIScreen.main.bounds
        Address.isHidden = false // state
        AddressTextField.isHidden = false
        Address2.isHidden = false // city
        AddressTextField2.isHidden = false
        Address3.isHidden = false
        AddressTextField3.isHidden = false
        Address4.isHidden = false // address1
        AddressTextField4.isHidden = false
        Address5.isHidden = false // address2
        AddressTextField5.isHidden = false
        CompanyName.isHidden = false
        CompanyNameTextField.isHidden = false
       // TypeOfUser.frame = CGRect(x:40, y:454, width: 100, height:25)
        //TypeOfUserTextField.frame = CGRect(x:170, y:454, width: screenSize.maxX - 190, height:25)
        
    }
    
    
    

    
    func isValidEmail(testStr:String) -> Bool {

        if testStr.contains("@"){
        let words = testStr.components(separatedBy: "@")
        
        if words[1] == "gates.com"{
            
            return true
        }
        else {
            
            return false
        }
        }
        else { return false }
    }
    
    func validate(value: String) -> Bool {
        
        if (value.characters.count >= 6) && (value.characters.count <= 20) {
            return true
        }
        else
        {
            
            return false
        }
    }
    
    func displayMyAlertMessage(_ userMessage:String)
    {
        
        let myAlert = UIAlertController(title:"Gates Finder", message:userMessage, preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler:nil);
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }
    
    func json (params:[String:Any])
    {
        activityIndicator.isHidden = false
        activityIndicator.startAnimating()
        let session = URLSession.shared
        let url = "http://54.255.163.200/api/registration/post2"
        let request = NSMutableURLRequest(url: NSURL(string: url)! as URL)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        do{
            request.httpBody = try JSONSerialization.data(withJSONObject: params, options: JSONSerialization.WritingOptions())
            let task = session.dataTask(with: request as URLRequest, completionHandler: {(data, response, error) in
                if let response = response {
                    let nsHTTPResponse = response as! HTTPURLResponse
                    let statusCode = nsHTTPResponse.statusCode
                    print ("status code = \(statusCode)")
                }
                if let error = error {
                    print ("\(error)")
                    self.displayMyAlertMessage("Registeration failed! Please try again later.\n\(error)")
                }
                if let data = data {
                    do{
                        let jsonResponse = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions()) as! NSDictionary
                        print(jsonResponse)
                        
                        
                        if let result = jsonResponse["result"] as? String {
                        DispatchQueue.main.async(execute: {
                            self.activityIndicator.isHidden = true
                            self.activityIndicator.stopAnimating()
                        })
                        if result == "Success" {
                            self.alert("Registered Successfully")
                            let datarecive = jsonResponse["data"] as! NSDictionary
                            self.idc = datarecive["id"] as! Int
                            self.loaclSave()
                            //
                        }
                        else if result == "AlreadyRegistered"{
                            self.alert("Already Registered User")
                            let datarecive = jsonResponse["data"] as! NSDictionary
                             self.idc = datarecive["id"] as! Int
                            self.loaclSave()
                        }
                        else if result == "MobileNotFound" {
                            self.displayMyAlertMessage("You are not a valid distributor of Gates. Please contact Gates for more details!")
                            
                        }
                        else {
                            self.displayMyAlertMessage("Registeration failed! Please try again later.")
                            print("Something Nothing")
                        }
                        }
                        else {
                            self.displayMyAlertMessage("Registeration failed! Please try again later.")
                            print("Something Nothing")
                        }
                        
//                        let resutl = jsonResponse["result"] as String
                    }catch _ {
                        let erro = String(data: data, encoding: String.Encoding.utf8)
                        self.displayMyAlertMessage("Oops not good JSON formatted response\(String(describing: erro))")
                       
                    }
                }
            })
            task.resume()
        }catch _ {
            print ("Oops something happened buddy")
            self.displayMyAlertMessage("Registeration failed! Please try again later.")
        }
    
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        NameTextField.resignFirstResponder()
        EmailTextField.resignFirstResponder()
        MobileTextField.resignFirstResponder()
        AddressTextField.resignFirstResponder()
        AddressTextField2.resignFirstResponder()
        AddressTextField3.resignFirstResponder()
        AddressTextField4.resignFirstResponder()
        AddressTextField5.resignFirstResponder()
        CompanyNameTextField.resignFirstResponder()
        return true
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
        
    }
    
    func animateTextField(textField: UITextField, up: Bool)
    {
        let movementDistance:CGFloat = -130
        let movementDuration: Double = 0.3
        
        var movement:CGFloat = 0
        if up
        {
            movement = movementDistance
        }
        else
        {
            movement = -movementDistance
        }
        UIView.beginAnimations("animateTextField", context: nil)
        UIView.setAnimationBeginsFromCurrentState(true)
        UIView.setAnimationDuration(movementDuration)
        self.view.frame = self.view.frame.offsetBy(dx: 0, dy: movement)
        UIView.commitAnimations()
    }
    
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        self.animateTextField(textField: textField, up:true)
    }
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        self.animateTextField(textField: textField, up:false)
    }       
    
    func alert(_ userMessage:String){
        
        let alertController = UIAlertController(title: "Gates Finder", message: userMessage, preferredStyle: UIAlertControllerStyle.alert)
        let ok = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: {(action) -> Void in
            //The (withIdentifier: "VC2") is the Storyboard Segue identifier.
            self.getthedate()
           self.performSegue(withIdentifier: "regview", sender: self)
            
        })
        
        alertController.addAction(ok)
        self.present(alertController, animated: true, completion: nil)
    }
    
   
    
    func alert(){
        
        let alertController = UIAlertController(title: "Gates Finder", message: "No internet connection", preferredStyle: UIAlertControllerStyle.alert)
        let ok = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: {(action) -> Void in
           
        })
        
        alertController.addAction(ok)
        self.present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func Skip(_ sender: Any) {
        if conditionupdatesconf == false {
            
            displayMyAlertMessage("Please accept to terms and conditions!")
        }
        else
        {
        
        if currentReachabilityStatus == .notReachable {
            alert()
        }
        else {
        self.loaclSave()
        self.getthedate()
            UserDefaults.standard.set(true,forKey:"skipuser");
            UserDefaults.standard.synchronize();
        self.performSegue(withIdentifier: "regview", sender: self)
        }
    }
    }
    
    func getthedate(){
        let date = Date()
        let formatter = DateFormatter()
        let hour = Calendar.current.component(.hour, from: date)
        let minutes = Calendar.current.component(.minute, from: date)
        let seconds = Calendar.current.component(.second, from: date)
        let time = "\(hour):\(minutes):\(seconds)"
        formatter.dateFormat = "yyyy.MM.dd"
        let Date2 = formatter.string(from: date)
        UserDefaults.standard.set(Date2, forKey: "thedateis")

        UserDefaults.standard.set(time, forKey: "theTimeis")
        
        UserDefaults.standard.synchronize();
        
        
    }
    
    func loaclSave() {
        UserDefaults.standard.set(self.textbox, forKey: "country")
        UserDefaults.standard.set(self.NameTextField.text!, forKey: "name")
          UserDefaults.standard.set(mobileNumber, forKey: "mobile")
         UserDefaults.standard.set(self.EmailTextField.text!, forKey: "email")
        UserDefaults.standard.set(self.AddressTextField.text!, forKey: "Address1")
        UserDefaults.standard.set(self.AddressTextField2.text!, forKey: "Address2")
        UserDefaults.standard.set(self.AddressTextField3.text!, forKey: "Address3")
        UserDefaults.standard.set(self.AddressTextField4.text!, forKey: "Address4")
        UserDefaults.standard.set(self.AddressTextField5.text!, forKey: "Address5")
        UserDefaults.standard.set(self.CompanyNameTextField.text!, forKey: "company")
        UserDefaults.standard.set(self.idc!, forKey: "idvalue")
        UserDefaults.standard.set(self.emailupdateconf!, forKey: "mobileupdate")
        UserDefaults.standard.set(self.mobileupdatesconf!, forKey: "emailupdate")
        UserDefaults.standard.set(self.typeuser!, forKey: "usertype")
        
        UserDefaults.standard.set(true,forKey:"isUserLoggedIn");
         UserDefaults.standard.set(false, forKey: "distribuUser")

        UserDefaults.standard.synchronize();
    
    
    }
    let customView = UIView()
    @IBAction func TC(_ sender: Any) {
        
        let message = "Gates Mobile Applications\nEnd User License Agreement\nSeptember 2017 \n\n\nREAD THIS AGREEMENT CAREFULLY BEFORE USING THIS GATES MOBILE APP.  THE GATES CORPORATION AND ITS AFFILIATES AND SUBSIDIARIES (“GATES”) WILL ONLY LICENSE THE GATES MOBILE APP WITH WHICH THIS LICENSE AGREEMENT HAS BEEN ASSOCIATED (THE “APP”) TO YOU IF YOU FIRST ACCEPT THE TERMS OF THIS AGREEMENT BY CLICKING “ACCEPT” OR LOGGING INTO, ACCESSING OR USING THE APP.  IF YOU DO NOT AGREE TO THE TERMS OF THIS AGREEMENT, YOU MAY NOT DOWNLOAD, INSTALL OR USE THE APP.\n\n\nThe App is available only to individuals aged 18 years or older and is intended only for individuals aged 18 years or older. This App is not marketed or intended for use by anyone less than 18. By consenting to the terms of this Agreement, you represent and warrant to Gates that you are at least 18 years old\n\n\nThis End User License Agreement (“Agreement”) is between Gates and you and/or your company (“you” or “Licensee”) and governs your use of any App from Gates that you access and/or download for use in an iPhone®, iPad®, Android®, BlackBerry® or other similar mobile environment for which Gates makes the App available (“Mobile Platform”).  You may view the terms of this Agreement at any time by accessing: http://gates.com/PICGaugeTC\n\n\n1.   Acceptance of Terms and Conditions; Charges\nBy accessing, downloading and/or using the App, you acknowledge having read and understood, and you hereby agree, to be bound by and comply with these terms. If you do not agree to these terms, you must not install or use the App. The App is protected by law, including, but not limited to, the laws of the United States and other countries, as well as international treaties, protecting the copyrights, trademarks and other intellectual property of Gates and its licensors\n\nGates does not collect any fees from you for the App. However, you may incur network or data charges, roaming charges or other costs or fees when you download or use the App or certain of its features, such as location-based services like store locators (“Network Charges”).  Gates has no liability to you for any of Network Charges\n\n\n2.   License Grant\nThe term “App” includes the mobile applications computer programs (software) that you access and/or download, and associated data and information (including any user guide, updates and revisions) available to you.  With limited exceptions with respect to software or elements of the App that Gates has licensed from third parties, the App is owned by Gates and is licensed, not sold Subject to the terms of this Agreement, Gates grants you a limited, revocable, terminable, nonexclusive license to use the App solely as described in this Agreement, and solely on the Mobile Platform for which the Software was specifically designed by Gates. Gates may, in its sole discretion, make available to you updates to the App and related data and information, but has no obligation to do so; any updates provided by Gates are subject to the terms of this Agreement.  Except as expressly stated herein, no other rights are granted to you by implication, estoppel, or otherwise, under any patent, copyright, trade secret, trademark, or other intellectual property right of Gates or any of its licensors\n\n\n3.  License Limitations\nYou are authorized to use the App solely as an individual for the limited purpose of  accessing the Gates  product catalogue and selecting applicable Gates Products.  “Gates Products” means products and associated hardware manufactured by Gates or sold or marketed under any Gates label\nYou must not copy, modify, transfer, rent, lease, sublicense, assign, reverse assemble, reverse compile or create derivative works of the App; nor may you disclose the Software to third parties, nor may you access, download or use the Software in any environment or any platform other than a Mobile Platform for which it was designed. To the extent any of the foregoing restrictions on reverse engineering, decompiling or other use of the App are not enforceable under applicable law, then the restriction will apply to the greatest extent consistent with applicable law, and you will not engage in such activities without first giving Gates written notice of your intended course of action sufficiently in advance of such action to allow Gates to provide any relevant assistance or information that might obviate the need for such action.  Gates reserves the right to modify the App and related data and information at any time, and to change its functionality.  You acknowledge and agree that Gates retains sole ownership of all intellectual property rights in the App, Gates Products and related information, including but not limited to patent, copyright, trade dress, trade secret, and trademark rights\n\n\n4.   Termination of License Rights\nThis Agreement and the license granted to you will terminate automatically upon your breach of this Agreement.  Gates may terminate your license rights, and/or may stop offering the App, data and/or information, at any time for any reason without notice and without liability. Upon any termination, you agree to cease all use of the App and to remove the App from the Mobile Platform(s)\n\n\n5.   Protection of Confidential Information.\nYou agree to hold all Confidential Information in confidence indefinitely. 'Confidential Information shall' mean the App and any and all information, data, specifications, designs, constructions, techniques, formulae, materials, and manufacturing processes of or concerning Gates Products, except information which is: published or otherwise becomes part of the public domain through no act or omission by you; received by you from a third party who is legally in possession of the same and not under an obligation of confidentiality with respect thereto; or, was already in your possession, with no duty of confidentiality attached thereto, prior to its receipt from Gates, as evidenced by written records.  This obligation of confidentiality shall survive termination, cancellation, or expiration of this License Agreement\n\n\n6.   Trademarks and Copyrights\nThe trademarks, service marks, and logos (the 'Trademarks') used and displayed in the Software are registered and unregistered Trademarks of Gates and others. Nothing in this Agreement or the Software should be construed as granting, by implication, estoppel, or otherwise, any license or right to use any Trademark without the written permission of the Trademark owner. Trademarks of Gates may not be used in any way without prior written permission of Gates. The copyrights in the Software and all data and information provided in connection with the Software are owned  by Gates or by the original author or creator. Except as stated herein, none of the Software, data or information may be copied, reproduced, distributed, republished, downloaded, displayed, posted or transmitted in any form or by any means, including, but not limited to, electronic, mechanical, photocopying, recording, or otherwise, without the prior written permission of Gates or the copyright owner\n\n\n7.   Links To Third Party Sites\nThe App may contain links to third-party sites. Any linked sites are not under the control of Gates, and Gates is not responsible for the contents of any linked site, any link contained in a linked site, any changes or updates to such linked sites, or any transmission from any linked site. Gates is providing these links to third-party sites only as a convenience, and the inclusion of any link does not imply endorsement by Gates of the site.  You may not add links to the App to any third party sites.  Doing so shall terminate this license with immediate effect\n\n\n8.  NO WARRANTY; DISCLAIMER\nGATES DOES NOT GUARANTEE, REPRESENT OR WARRANT THAT YOUR USE OF THE APP, INFORMATION AND/OR DATA WILL BE UNINTERRUPTED OR ERROR-FREE.  WHILE GATES USES REASONABLE EFFORTS TO USE ACCURATE AND UP-TO-DATE INFORMATION AND DATA IN AND IN CONNECTION WITH THE APP, THE DATA AND OTHER INFORMATION ARE PROVIDED ON AN 'AS IS' BASIS WITHOUT WARRANTIES OF ANY KIND, EXPRESS OR IMPLIED. GATES SPECIFICALLY DISCLAIMS ALL WARRANTIES OF EVERY KIND AS TO THE APP, DATA AND OTHER INFORMATION, INCLUDING, BUT NOT LIMITED TO, ANY WARRANTIES OF TITLE, NON-INFRINGEMENT, OTHER VIOLATION OF RIGHTS, MERCHANTABILITY OR FITNESS FOR PARTICULAR PURPOSE. GATES DOES NOT WARRANT OR MAKE ANY REPRESENTATIONS REGARDING THE USE, VALIDITY, ACCURACY, OR RELIABILITY OF, OR THE RESULTS OF THE USE OF, OR OTHERWISE RESPECTING, THE APP, DATA OR OTHER INFORMATION, AND YOU SHALL BE SOLELY RESPONSIBLE FOR THE RESULTS, USE, EFFICIENCY AND SUITABILITY OF THE SOFTWARE, DATA AND INFORMATION \n\n\n9.  LIMITATION OF LIABILITY\nIN NO EVENT SHALL GATES BE LIABLE TO LICENSEE FOR ANY DIRECT, INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL DAMAGES OR LOST PROFITS, ARISING OUT OF OR RELATED TO THIS LICENSE AGREEMENT, THE SOFTWARE OR RELATED DATA AND INFORMATION, EVEN IF GATES HAS BEEN ADVISED OF THE POSSIBILITY THEREOF.  IN NO EVENT SHALL GATES BE LIABLE TO LICENSEE FOR ANY DAMAGES RESULTING FROM: (A) ANY FAILURE OF THE SOFTWARE, INCLUDING, BUT NOT LIMITED TO LOSS OF DATA; (B) DELAY IN THE DELIVERY OF THE SOFTWARE; (C) THE PERFORMANCE OF SERVICES RELATED TO THE SOFTWARE; (D) INACCURACY OF THE DATA OR INFORMATION, (E) ANY UPDATES OR CHANGES TO THE SOFTWARE, DATA AND/OR INFORMATION, AND/OR (F) CLAIMS REGARDING INFRINGEMENT OF INTELLECTUAL PROPERTY RIGHTS, TORT OR NEGLIGENCE\n\n\n10.  Certain Third Parties and Additional Terms\nThe company or companies that make the Mobile Platform available to you (e.g., Research In Motion Ltd., Apple, Inc., Google, Inc., etc.) are made express third party beneficiaries (“TPBs”) to the terms of this Agreement and all limitations and disclaimers provided herein.  By downloading, installing or using the App, you acknowledge and agree that none of the TPBs has any liability to you under any theory, including contract, tort, strict liability or otherwise, for your downloading, installation or use of the App or any data that you receive from or provide through the App.  [Additional terms applicable to your use of the App on specific Mobile Platforms are set forth in Appendix 1 to this Agreement\n\n\n11.   Gates Products\nGates’ obligations and responsibilities regarding Gates Products or services are governed solely by the agreements under which they are sold or licensed. Gates does not guarantee availability of individual part numbered Gates Products. Gates Products availability must be confirmed at time of any order and each Product’s availability is in no way dependent upon or guaranteed by its identification in this App. Gates Products orders are subject to acceptance or rejection by Gates\n\nWARNING!  Do not use any Gates product including belts, pulleys or sprockets on any aircraft system, drone system, or rotor drive system. Gates Products are not designed, tested or certified for flight or aircraft use in any country.  Use Gates Products only on applications specified in Gates Product literature. Install and maintain products according to the vehicle manufacturer’s recommended procedures and with recommended tools. Failure to follow these instructions could result in injury or property damage. Gates disclaims all liability due to failure to follow these instructions. Forum information is meant for United States visitors only\n\n\n12.   Privacy and Data Collection\nThe App may request or collect certain limited information about you when you use it.  Such information might consist personal information that you provide, such as, for example, your name, your email address, the names and email addresses of people that are stored on devices that connect to the App or that you send content and information to through the App your username and password for your accounts and online service providers.  Other information collected may include device identification as well as technical data and related information, including but not limited to technical information about your device, system and application software.  The App may also collect information regarding what content you send through the Software and who you send it to (“Transmission Data”).  The App may also use cookies or other passive tracking mechanisms and tools to collect information in order to facilitate your use of the App.  Furthermore, Gates may collect aggregated non-personal data from all users of the App, such as amount of use, nature of inquiries, etc. (“Aggregate Data”).  Gates will only use the Aggregate Data to assess the overall use of the App by users in order to determine how the App is being used and how it and other products can be improved \n\n Please keep in mind that the nature of the App and services may be interactive, and as part of your use of the App you will be provided the opportunity to share information and content with third parties, including information such as your location. You should use caution when deciding what information and content to share through the App.\n\n Gates does not share personal information about you (i.e., information that can be associated with you personally, but excluding information such as your location which is collected without association with you individually) with any third parties. Gates may share Aggregate Data with vendors who assist Gates in providing its products and services; with Gates’s affiliated companies, including any parent or subsidiaries of Gates.  Gates may share data about end users if Gates believes it is necessary to comply with legal process (such as a court order, subpoena, search warrant, etc.), or other legal requirements of any governmental authority; if Gates believes it would potentially mitigate Gates’ liability in an actual or potential lawsuit; if Gates believes it is permitted by law or if doing so will not violate the law; or if Gates believes it is otherwise necessary to protect Gates’ rights or property; or is necessary to protect the interests of other users of the App. In the unlikely event that all or part of Gates’ business is sold or acquired by a third party, Gates will transfer such information to the new business owner\n\n\n13.  Security\n The App has security measures built in to protect against the unauthorized use, loss, misuse and/or alteration of the App and related data and information\n\n\n14.   Compliance with Laws and Government Users\nYou shall comply with all applicable laws regarding the use of the App. You shall adhere to the U.S. Export Administration Laws and Regulations and shall not export or re-export the App or any technical data to any proscribed country listed in the U.S. Export Administration Regulations unless properly authorized by the U.S. Government and Gates.  The App is a 'commercial item' as that term is defined in 48 C.F.R. 2.101 consisting of 'commercial computer software' and 'commercial computer software documentation' as such terms are used in 48 C.F.R. 227.7202-1, 227.7202-3, 227.7202-4.  If you are in the U.S. Government or any agency or department thereof,the App is licensed (a) only as a commercial item and (b) with only those rights as are granted hereunder\n\n\n15.  Governing Law\nThis Agreement and use of the App will be governed by the laws of the State of Colorado, USA, notwithstanding Colorado choice of law provisions.  All parties submit to the jurisdiction of either the Courts of the State of Colorado or U.S. Federal District Courts within Colorado and agree to accept service of process by registered or certified mail, return receipt requested, in accordance with Colorado or Federal rules of civil procedure\n\n\n16.  Entire Agreement; Updates\nThis Agreement contains the entire agreement of the parties with respect to the App.  It supersedes all prior understandings, writings, proposals, representations or communications, oral or written, of either party. Gates reserves the right to update and/or change the terms and conditions of this Agreement at any time.  Gates will make updated and/or changed terms and conditions available to you by sending them or a notice to you, posting them on Gates’ website, and/or providing them as a new click-through Agreement that must be accepted before continued use of the App is permitted. Your continued use of the App constitutes your agreement to the updated and/or changed terms and conditions.  If you do not agree to any of the updated and/or changed terms and conditions, you shall stop all  use of the App immediately\n\n\n17.Contact\nIf you have any questions about the App or this Agreement, you can contact Gates at AutoApps@Gates.com\n\n\n[Appendix 1\n\nCertain Additional Terms\n\nDepending on which Mobile Platform(s) you use to access the App, the following terms and conditions also apply as part of this Agreement and your license to the App\nBlackberry Users (including Blackberry handheld devices and Blackberry tablet computers)\n\nPortions copyright (c) 2002-2011 Research In Motion Limited. All rights reserved\nYou acknowledge that the App has been provided to you with certain application templates, code stubs, code snippets, example applications, sample code and code fragments in source code form that were provided by Research In Motion Ltd\n(“Distributable Code”).  Upon written request from you, Gates will identify to you the Distributable Code.\n\nYou acknowledge that your rights to the Distributable Code are subject to the following: (A) the license granted is a non-exclusive, terminable license for you to use the Distributable Code only on or in conjunction with the App; (B) except for the limited license to use the Distributable Code on or in conjunction with the App, you acquire no intellectual property or other proprietary rights, including, without limitation, patents, designs, trademarks, copyright or rights in any confidential information in or related to the Distributable Code; (C) reverse engineering the Distributable Code is prohibited, except to the extent that such restrictions cannot be enforced under applicable law; (D) you must cease all use of the Distributable Code within a reasonable period of time following expiration or termination of this Agreement; (E) RIM shall not be liable to you for any damages whatsoever; (F) you shall import, export, re-export and use the Distributable Code only in accordance with the laws and regulations of the of the country(ies) and/or territory(ies) in which the Distributable Code is  used, imported, exported and/or re-exported; (G) neither Gates nor RIM make any warranties, express or implied, related to the Distributable Code; and (H) you shall not alter any copyright, trademark or patent notice in the Distributable Code.]"
        
        
        
         let screenSize: CGRect = UIScreen.main.bounds
       
        
        customView.frame = CGRect.init(x: 0, y: 0, width: screenSize.width, height: screenSize.height)
        customView.backgroundColor = UIColor.black     //give color to the view
        customView.center = self.view.center
      
        
        let textView:UITextView = {
            let text = UITextView()
            text.frame = CGRect(x:0, y: 0, width: screenSize.width, height: screenSize.maxY - 40)
            text.backgroundColor = UIColor.black
            text.text = message
            text.textColor = UIColor.white
            text.isEditable = false
            return text
            
        }()
        
        
        
        
        let okay:UIButton = {
            let button = UIButton()
            button.frame = CGRect(x:0, y: screenSize.maxY - 40, width: screenSize.width, height: 40)
            button.backgroundColor = UIColor.red
            button.setTitle("OK",for: .normal)
            button.setTitleColor(UIColor.white, for: .normal)
            button.addTarget(self, action: #selector(okayaction), for: .touchUpInside)
            return button
        }()
        customView.addSubview(textView)
        customView.addSubview(okay)
        
          self.view.addSubview(customView)
        
        
    }
    
    func okayaction() {
        customView.removeFromSuperview()
    }
    
    
    
}

