//
//  DropMenuButton.swift
//  DropDownMenu
//
//  Created by Marcos Paulo Rodrigues Castro on 9/1/16.
//  Copyright © 2016 HackTech. All rights reserved.
//

import UIKit

class dropMenuForNavigation: UIButton, UITableViewDelegate, UITableViewDataSource
{
    var items = [String]()
    var table = UITableView()
    var act = [() -> (Void)]()
    var isclicked:Bool! = false
    
    var superSuperView = UIView()
    let screenSize: CGRect = UIScreen.main.bounds
    
    func showItems()
    {
        
        fixLayout()
        
        if(table.alpha == 0)
        {
            self.layer.zPosition = 1
            UIView.animate(withDuration: 0.3
                , animations: {
                    self.table.alpha = 1;
            })
            
        }
            
        else
        {
            
            UIView.animate(withDuration: 0.3
                , animations: {
                    self.table.alpha = 0;
                    self.layer.zPosition = 0
            })
            
        }
        
    }
    
    
    func initMenu(_ items: [String], actions: [() -> (Void)])
    {
        
        if isclicked == true {
            isclicked = false
        }
        else
        {
            isclicked = true
        }
        
        if isclicked == true
        {

        
        self.items = items
        self.act = actions
        
        var resp = self as UIResponder
        
        while !(resp.isKind(of: UIViewController.self) || (resp.isKind(of: UITableViewCell.self))) && resp.next != nil
        {
            resp = resp.next!
            
        }
        
        if let vc = resp as? UIViewController{
            superSuperView = vc.view
        }
        else if let vc = resp as? UITableViewCell{
            superSuperView = vc
        }
        
        table = UITableView()
        table.rowHeight = self.frame.height
        table.delegate = self
        table.dataSource = self
        table.isUserInteractionEnabled = true
        table.alpha = 0
        table.separatorColor = self.backgroundColor
        superSuperView.addSubview(table)
        self.addTarget(self, action:#selector(dropMenuForNavigation.showItems), for: .touchUpInside)
        
        //table.registerNib(UINib(nibName: "CustomCell", bundle: nil), forCellReuseIdentifier: "cell")
        }
        else
        {
            
        table.isHidden = true
        
        }
    }
    
    func initMenu(_ items: [String])
    {
        self.items = items
        
        var resp = self as UIResponder
        
        while !(resp.isKind(of: UIViewController.self) || (resp.isKind(of: UITableViewCell.self))) && resp.next != nil
        {
            resp = resp.next!
            
        }
        
        if let vc = resp as? UIViewController{
            
            superSuperView = vc.view
        }
        else if let vc = resp as? UITableViewCell{
            
            superSuperView = vc
            
        }
        
        table = UITableView()
        table.rowHeight = self.frame.height
        table.delegate = self
        table.dataSource = self
        table.isUserInteractionEnabled = true
        table.alpha = 0
        table.separatorColor = self.backgroundColor
        superSuperView.addSubview(table)
        superSuperView.bringSubview(toFront: table)
        
        self.addTarget(self, action:#selector(dropMenuForNavigation.showItems), for: .touchUpInside)
        
        //table.registerNib(UINib(nibName: "CustomCell", bundle: nil), forCellReuseIdentifier: "cell")
        
    }
    
    
    func fixLayout()
    {
        
        let auxPoint2 = superSuperView.convert(self.frame.origin, from: self.superview)
        
        var tableFrameHeight = CGFloat()
        
        if (items.count >= 12){
            tableFrameHeight = self.frame.height * 12
        }else{
            
            tableFrameHeight = self.frame.height * CGFloat(items.count)
        }
        table.frame = CGRect(x: screenSize.maxX - 150, y: auxPoint2.y + self.frame.height, width: 150 , height:tableFrameHeight)
        table.rowHeight = self.frame.height
        
        table.reloadData()
        
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.setNeedsDisplay()
        fixLayout()
        
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        
        return items.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        
//        self.setTitle(items[(indexPath as NSIndexPath).row], for: UIControlState())
//        self.setTitle(items[(indexPath as NSIndexPath).row], for: UIControlState.highlighted)
//        self.setTitle(items[(indexPath as NSIndexPath).row], for: UIControlState.selected)
        
        if self.act.count > 1
        {
            self.act[indexPath.row]()
        }
        
        showItems()
        tableView.isHidden = true
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        let itemLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 150, height: self.frame.height))
        itemLabel.textAlignment = NSTextAlignment.center
        itemLabel.text = items[(indexPath as NSIndexPath).row]
        itemLabel.font = self.titleLabel?.font
        itemLabel.textColor = self.backgroundColor
        
        let bgColorView = UIView()
        bgColorView.backgroundColor = UIColor.black
        
        let cell = UITableViewCell(frame: CGRect(x: 0, y: 0, width: self.frame.width, height: self.frame.height))
        //        cell.backgroundColor = self.titleLabel?.textColor
        cell.selectedBackgroundView = bgColorView
        cell.separatorInset = UIEdgeInsetsMake(0, self.frame.width, 0, self.frame.width)
        cell.addSubview(itemLabel)
        
        
        return cell
    }
    
}
