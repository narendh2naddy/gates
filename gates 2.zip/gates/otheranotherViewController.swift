//
//  otheranotherViewController.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 15/03/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

//import UIKit
//
//class otheranotherViewController: UIViewController, UITableViewDelegate, UITableViewDataSource{
//    
//    @IBOutlet var tableView: UITableView!
//    var trainvd:Array = ["testingurl1","testingurl2"]
//    var strURLToOpen = ["http://www.brainmagic.com","http://www.gates.com"]
//    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        self.tableView.delegate = self
//        self.tableView.dataSource = self
//        // Do any additional setup after loading the view.
//    }
//    
//    override func didReceiveMemoryWarning() {
//        super.didReceiveMemoryWarning()
//        // Dispose of any resources that can be recreated.
//    }
//    
//    // MARK: UITableView
//    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        return trainvd.count
//    }
//    
//    
//    
//    
//    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        
//        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath ) as! otheranotherTableViewCell
//        
//        
//        cell.img.image = UIImage(named:"youtube")
//        cell.label.text = trainvd[indexPath.row]
//        
//        return cell
//    }
//    
//    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        
//        if let url = NSURL(string:strURLToOpen[indexPath.row]){ UIApplication.shared.open(url as URL, options: [:], completionHandler: nil) }
//        
//    }
//
//
//}
