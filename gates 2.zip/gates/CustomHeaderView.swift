//
//  CustomHeaderView.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 09/03/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit

class CustomHeaderView: UIView {
    @IBOutlet var label: UITableView!

    /*
    // Only override draw() if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func draw(_ rect: CGRect) {
        // Drawing code
    }
    */

}
  
