//
//  NavigationBar.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 20/04/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit

protocol NavigationProctocal {
    
    func menubar()
    
}


class NavigationBar: UIViewController{

        
    var delegate: NavigationProctocal?
    
    let screenSize: CGRect = UIScreen.main.bounds
    let btn1:dropMenuForNavigation! = dropMenuForNavigation(frame: CGRect(x: 0, y: 0, width: 25, height: 25))
    var isclicked:Bool! = true
    let btn2 = UIButton(type: .custom)
    let customView = UIView()
    
    let someImageView: UIImageView = {
        let theImageView = UIImageView()
        theImageView.image = UIImage(named: "scv")
        theImageView.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        theImageView.translatesAutoresizingMaskIntoConstraints = false //You need to call this property so the image is added to your view
        return theImageView
    }()
    func menubar() {
        delegate?.menubar()
        btn1.setImage(UIImage(named: "NavMenu"), for: .normal)
        btn1.addTarget(self, action: #selector(action), for: .touchUpInside)
        btn2.setImage(UIImage(named: "drowarrow"), for: .normal)
        btn2.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        btn2.addTarget(self, action: #selector(signout), for: .touchUpInside)
        let item1 = UIBarButtonItem(customView: btn1)
        let item2 = UIBarButtonItem(customView: btn2)
        self.navigationItem.setRightBarButtonItems([item1,item2], animated: true)
        
    }
    func action(sender:UIButton!) {
        btn1.initMenu(["Home","About Gates","Product Search","Videos","What's New","Schemes","Notification","Distribution","Contact","Other Links","Edit"], actions: [({ () -> (Void) in
            let vcName = "HomePage"
            let viewCv = self.storyboard?.instantiateViewController(withIdentifier: vcName)
            self.navigationController?.pushViewController(viewCv!, animated: true)
        }), ({ () -> (Void) in
            let vcName = "AboutGatesCorporation"
            let viewCv = self.storyboard?.instantiateViewController(withIdentifier: vcName)
            self.navigationController?.pushViewController(viewCv!, animated: true)
        }), ({ () -> (Void) in
            let vcName = "ProductSearch"
            let viewCv = self.storyboard?.instantiateViewController(withIdentifier: vcName)
            self.navigationController?.pushViewController(viewCv!, animated: true)
        })
            , ({ () -> (Void) in
                let vcName = "VideosCategory"
                let viewCv = self.storyboard?.instantiateViewController(withIdentifier: vcName)
                self.navigationController?.pushViewController(viewCv!, animated: true)
            }), ({ () -> (Void) in
                let vcName = "What'sNew"
                let viewCv = self.storyboard?.instantiateViewController(withIdentifier: vcName)
                self.navigationController?.pushViewController(viewCv!, animated: true)
            }), ({ () -> (Void) in
                let vcName = "Schemes"
                let viewCv = self.storyboard?.instantiateViewController(withIdentifier: vcName)
                self.navigationController?.pushViewController(viewCv!, animated: true)
            }), ({ () -> (Void) in
                let vcName = "Notification"
                let viewCv = self.storyboard?.instantiateViewController(withIdentifier: vcName)
                self.navigationController?.pushViewController(viewCv!, animated: true)
            }), ({ () -> (Void) in
                let vcName = "distributionNetwork"
                let viewCv = self.storyboard?.instantiateViewController(withIdentifier: vcName)
                self.navigationController?.pushViewController(viewCv!, animated: true)
            }), ({ () -> (Void) in
                let vcName = "Contact"
                let viewCv = self.storyboard?.instantiateViewController(withIdentifier: vcName)
                self.navigationController?.pushViewController(viewCv!, animated: true)
            }), ({ () -> (Void) in
                let vcName = "OtherLinks"
                let viewCv = self.storyboard?.instantiateViewController(withIdentifier: vcName)
                self.navigationController?.pushViewController(viewCv!, animated: true)
            }), ({ () -> (Void) in
                let vcName = "Edit"
                let viewCv = self.storyboard?.instantiateViewController(withIdentifier: vcName)
                self.navigationController?.pushViewController(viewCv!, animated: true)
            })
            
            ])
    }///
 
    func signout(){
        
        if isclicked == true {
            isclicked = false
            
            customView.frame = CGRect.init(x: screenSize.minX, y: 64, width: screenSize.width, height: 65)
            customView.backgroundColor = UIColor.white     //give color to the view
            
            self.view.addSubview(customView)
            self.customView.addSubview(someImageView)
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI))
                
            }
            UIView.animate(withDuration: 0.2, delay: 0.2, options: UIViewAnimationOptions.curveEaseIn, animations: {
                self.customView.alpha = 1.0
            }, completion: nil)
        
        }
        else
        {
            isclicked = true
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI * 2))
            }
            
            UIView.animate(withDuration: 0.2, delay: 0.2, options: UIViewAnimationOptions.curveEaseOut, animations: {
                self.customView.alpha = 0.0
            }, completion: nil)
            
        }
        
        
    }

}
