//
//  editViewController.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 01/04/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit
import CoreData

class editViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextFieldDelegate {
    @IBOutlet var img: UIImageView!

    @IBOutlet weak var subview: UIView!
    
    @IBOutlet var namefd: UITextField!
    @IBOutlet var emailfd: UITextField!
    @IBOutlet var mobilefd: UITextField!
    @IBOutlet var statefd: UITextField!
    @IBOutlet var cityfd: UITextField!
    @IBOutlet var pincodefd: UITextField!
    @IBOutlet var address1: UITextField!
    @IBOutlet var addres2: UITextField!
    @IBOutlet var companyfd: UITextField!
    var emailupdateconf:Bool!
    var mobileupdatesconf:Bool!
    @IBOutlet var emailupdate: UIButton!
    @IBOutlet var mobileupdates: UIButton!
    var isclicked:Bool!
    var isclicked3:Bool!
    var checked = UIImage(named:"checkbox1")
    var unchecked = UIImage(named:"unchecked_checkbox_1")

    @IBOutlet weak var updatedButton: UIButton!
    @IBOutlet weak var coutryName: UILabel!
    @IBOutlet weak var userTypedisply: UILabel!
    @IBOutlet weak var image2: UIImageView!
    let picker = UIImagePickerController()
    var data:NSData!

    let id = UserDefaults.standard.string(forKey: "idvalue")
    let name = UserDefaults.standard.string(forKey: "name")
    let mobile = UserDefaults.standard.string(forKey: "mobile")
    let email = UserDefaults.standard.string(forKey: "email")
    let addressg1 = UserDefaults.standard.string(forKey: "Address1")
    let addressg2 = UserDefaults.standard.string(forKey: "Address2")
    let address3 = UserDefaults.standard.string(forKey: "Address3")
    let address4 = UserDefaults.standard.string(forKey: "Address4")
    let address5 = UserDefaults.standard.string(forKey: "Address5")
    let company = UserDefaults.standard.string(forKey: "company")
    let mobileupdate = UserDefaults.standard.bool(forKey: "mobileupdate")
    let emailupdate2 = UserDefaults.standard.bool(forKey: "emailupdate")
     let usertype = UserDefaults.standard.string(forKey: "usertype")
    let country = UserDefaults.standard.string(forKey: "country")
    
        
    override func viewDidLoad() {
        super.viewDidLoad()
        ///
        updatedButton.layer.cornerRadius = 5
//        namefd.delegate = self
//        emailfd.delegate = self
//        mobilefd.delegate = self
        statefd.delegate = self
        cityfd.delegate = self
        pincodefd.delegate = self
        address1.delegate = self
        addres2.delegate = self
        companyfd.delegate = self
        if country == "All"{
        let refreshAlert = UIAlertController(title: "Gates Finder", message: "You skipped registration. Please register to edit your profile! ", preferredStyle: UIAlertControllerStyle.alert)
        
        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
            self.deteleIT()
            let viewCv = self.storyboard?.instantiateViewController(withIdentifier: "editToRegview")
            self.navigationController?.pushViewController(viewCv!, animated: true)
            
        }))
        
        refreshAlert.addAction(UIAlertAction(title: "Not Now", style: .cancel, handler: { (action: UIAlertAction!) in
            let viewCv = self.storyboard?.instantiateViewController(withIdentifier: "HomePage")
            self.navigationController?.pushViewController(viewCv!, animated: true)
        }))
        
        present(refreshAlert, animated: true, completion: nil)
        }
        ///
       
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(editViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
        self.title = "Edit Profile"
        let imageView = UIImageView(frame: self.view.frame)
        let image = UIImage(named: "background-2")!
        imageView.image = image
        self.view.addSubview(imageView)
        
        self.view.sendSubview(toBack: imageView)

         self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "Back", style: UIBarButtonItemStyle.plain, target: nil, action: nil)


      
        namefd.text = name
        emailfd.text = email
        mobilefd.text = mobile
        statefd.text = addressg1
        cityfd.text = addressg2
        pincodefd.text = address3
        address1.text = address4
        addres2.text = address5
        companyfd.text = company
        emailupdateconf = emailupdate2
        mobileupdatesconf = mobileupdate
        coutryName.text = country
        userTypedisply.text = usertype
      
        isclicked = UserDefaults.standard.bool(forKey: "mobileupdate")
        isclicked3 = UserDefaults.standard.bool(forKey: "emailupdate")
        if isclicked == true
        {
            emailupdate.setImage(checked, for: .normal)
            emailupdateconf = true
        }
        else
        {
            emailupdate.setImage(unchecked, for: .normal)
            emailupdateconf = false
        }
        
        if isclicked3 == true
        {
            mobileupdates.setImage(checked, for: .normal)
            mobileupdatesconf = true
        }
        else
        {
            mobileupdates.setImage(unchecked, for: .normal)
            mobileupdatesconf = false
            
        }

        
        picker.delegate = self
        menubar()
        
           img.image = UIImage(named: "title_image.png")
        // Do any additional setup after loading the view.
    }
    
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        namefd.resignFirstResponder()
        emailfd.resignFirstResponder()
        mobilefd.resignFirstResponder()
        statefd.resignFirstResponder()
        cityfd.resignFirstResponder()
        pincodefd.resignFirstResponder()
        address1.resignFirstResponder()
        addres2.resignFirstResponder()
        companyfd.resignFirstResponder()
        return true
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
        
    }
    
    func animateTextField(textField: UITextField, up: Bool)
    {
        let movementDistance:CGFloat = -130
        let movementDuration: Double = 0.3
        
        var movement:CGFloat = 0
        if up
        {
            movement = movementDistance
        }
        else
        {
            movement = -movementDistance
        }
        UIView.beginAnimations("animateTextField", context: nil)
        UIView.setAnimationBeginsFromCurrentState(true)
        UIView.setAnimationDuration(movementDuration)
        self.view.frame = self.view.frame.offsetBy(dx: 0, dy: movement)
        UIView.commitAnimations()
    }
    
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        self.animateTextField(textField: textField, up:true)
    }
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        self.animateTextField(textField: textField, up:false)
    }

    @IBAction func update(_ sender: Any) {
        
        if isclicked == true {
            isclicked = false
        }
        else
        {
            isclicked = true
        }
        
        if isclicked == true
        {
            emailupdate.setImage(checked, for: .normal)
            emailupdateconf = true
        }
        else
        {
            emailupdate.setImage(unchecked, for: .normal)
            emailupdateconf = false
        }
    }



    @IBAction func promotion(_ sender: Any) {
        
        if isclicked3 == true {
            isclicked3 = false
        }
        else
        {
            isclicked3 = true
        }
        
        if isclicked3 == true
        {
            mobileupdates.setImage(checked, for: .normal)
            mobileupdatesconf = true
        }
        else
        {
            mobileupdates.setImage(unchecked, for: .normal)
            mobileupdatesconf = false
            
        }

        
    }



    @IBAction func finalupdate(_ sender: Any) {
        
    if currentReachabilityStatus == .notReachable {displayMyAlertMessage("No Internet Connection ")}
        else {
            if(!(statefd.text?.isEmpty)!) && (!(cityfd.text?.isEmpty)!) && (!(companyfd.text?.isEmpty)!) {
                if(!(mobilefd.text?.isEmpty)!)
                {
                    if validate(value: mobilefd.text!) == true
                    {
                        if usertype == "Gates Employee" {
                            if isValidEmail(testStr: emailfd.text!) == true {
                                UserDefaults.standard.set(data, forKey: "profileImage")
                                json(params:["name":namefd.text!,"email":emailfd.text!,"mobileno":mobilefd.text!,"state ":statefd.text!,"city ":cityfd.text!,"pincode":pincodefd.text!,"address1":address1.text!,"address2":addres2.text!,"ReceivePromotions":mobileupdatesconf,"ReceiveUpdates":emailupdateconf!,"RegistrationType":"ios","Status":"Active","Date":"01-01-17","apppid":"ios","Password":"Muthu","id":id!,"usertype":usertype!,"Country":country!])
                                
                            }
                            else {displayMyAlertMessage("Please enter your Gates email id!")}
                         }
                        else {
                        UserDefaults.standard.set(data, forKey: "profileImage")
                        json(params:["name":namefd.text!,"email":emailfd.text!,"mobileno":mobilefd.text!,"state ":statefd.text!,"city ":cityfd.text!,"pincode":pincodefd.text!,"address1":address1.text!,"address2":addres2.text!,"ReceivePromotions":mobileupdatesconf,"ReceiveUpdates":emailupdateconf!,"RegistrationType":"ios","Status":"Active","Date":"01-01-17","apppid":"ios","Password":"Muthu","id":id!,"usertype":usertype!,"Country":country!])
                        }}
                        else {displayMyAlertMessage("Please enter a valid phone number!")}
                }
                else {displayMyAlertMessage(" Please enter the phone number!")}
                    }
            
            else {     displayMyAlertMessage("Fields marked with * are mandatory!")             }
        
        
        }
        
    }
    
    
    func json (params:[String:Any])
    {
        let session = URLSession.shared
        let url = "http://54.255.163.200/api/registration/Edit"
        let request = NSMutableURLRequest(url: NSURL(string: url)! as URL)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        do{
            request.httpBody = try JSONSerialization.data(withJSONObject: params, options: JSONSerialization.WritingOptions())
            let task = session.dataTask(with: request as URLRequest, completionHandler: {(data, response, error) in
                if let response = response {
                    let nsHTTPResponse = response as! HTTPURLResponse
                    let statusCode = nsHTTPResponse.statusCode
                    print ("status code = \(statusCode)")
                }
                if let error = error {
                    print ("\(error)")
                }
                if let data = data {
                    do{
                        let jsonResponse = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions()) as! NSDictionary
                        print(jsonResponse)
                        let datarecive = jsonResponse["data"] as! NSDictionary
                        print(datarecive)
                        
                        let result = jsonResponse["result"] as! String
                        print(result)
                        if result == "Success" {
                            self.displayMyAlertMessage2("Your profile updated successfully!")
                            self.loaclSave()
                                                        //
                        }
                                                else {
                            self.displayMyAlertMessage2("Updation failed! Please try again later.")
                            print("Something Nothing")
                        }
                        
                        
                        
                    }catch _ {
                        let erro = String(data: data, encoding: String.Encoding.utf8)
                        print ("OOps not good JSON formatted response\(String(describing: erro))")
                        
                        
                        
                    }
                }
            })
            task.resume()
        }catch _ {
            print ("Oops something happened buddy")
        }
        
    }
    @IBAction func uploadPicture(_ sender: Any) {
        
        
        picker.allowsEditing = false
        picker.sourceType = .photoLibrary
        picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        present(picker, animated: true, completion: nil)
    }
    func imagePickerController(_ picker: UIImagePickerController,didFinishPickingMediaWithInfo info: [String :Any])
    {
        
        
        if let chosenImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            //3
            image2.image = chosenImage //4
            let qty :CGFloat = 0.5
            data = UIImageJPEGRepresentation(chosenImage,qty) as NSData?
            
            //             imagedata = getArrayOfBytesFromImage(imageData: data)
            
            
        } else{
            print("Something went wrong")
        }
        
        
        self.dismiss(animated:true, completion: nil) //5
        
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }

    func isValidEmail(testStr:String) -> Bool {
        
        if testStr.contains("@"){
            let words = testStr.components(separatedBy: "@")
            
            if words[1] == "gates.com"{
                
                return true
            }
            else {
                
                return false
            }
        }
        else { return false }
    }
    
    func validate(value: String) -> Bool {
        
        if (value.characters.count >= 6) && (value.characters.count <= 20) {
            return true
        }
        else
        {
            
            return false
        }
    }
    func displayMyAlertMessage2(_ userMessage:String)
    {
        
        let myAlert = UIAlertController(title:"Gates Finder", message:userMessage, preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default,  handler: {(action) -> Void in
        
        
        let vcName = "HomePage"
        let storyboard: UIStoryboard = UIStoryboard (name: "Main", bundle: nil)
        let viewCv = storyboard.instantiateViewController(withIdentifier: vcName)
        self.navigationController?.pushViewController(viewCv, animated: true)
    })
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }
    func displayMyAlertMessage(_ userMessage:String)
    {
        
        let myAlert = UIAlertController(title:"Gates Finder", message:userMessage, preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default,  handler: {(action) -> Void in
            })
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }
    
    func loaclSave() {
        
        UserDefaults.standard.set(self.namefd.text!, forKey: "name")
        UserDefaults.standard.set(self.mobilefd.text!, forKey: "mobile")
        UserDefaults.standard.set(self.emailfd.text!, forKey: "email")
        UserDefaults.standard.set(self.statefd.text!, forKey: "Address1")
        UserDefaults.standard.set(self.cityfd.text!, forKey: "Address2")
        UserDefaults.standard.set(self.pincodefd.text!, forKey: "Address3")
        UserDefaults.standard.set(self.address1.text!, forKey: "Address4")
        UserDefaults.standard.set(self.addres2.text!, forKey: "Address5")
        UserDefaults.standard.set(self.companyfd.text!, forKey: "company")
        UserDefaults.standard.set(self.emailupdateconf!, forKey: "mobileupdate")
        UserDefaults.standard.set(self.mobileupdatesconf!, forKey: "emailupdate")
     
        
        UserDefaults.standard.synchronize();
        
        
    }
    
    ///// tops buttons
    let screenSize: CGRect = UIScreen.main.bounds
    let btn1 = UIButton(frame: CGRect(x: 0, y: 0, width: 20, height: 15))
    var isclicked2:Bool! = true
    var menuclicked = false
    let btn2 = UIButton(type: .custom)
    let customView = UIView()
    let btn3 = UIButton()
    let myView = sildermenu()
    
    
    let signoutUser:UIButton = {
        let screenSize: CGRect = UIScreen.main.bounds
        let button = UIButton()
        button.frame = CGRect(x: screenSize.maxX - 140 , y: 25, width: 140, height: 20)
        let image:UIImage = UIImage(named: "signout")!
        button.imageEdgeInsets = UIEdgeInsets(top: 0,left: 14,bottom: 0,right: 100)
        button.setImage(image, for:.normal)
        button.addTarget(self, action: #selector(userSignOut), for: .touchUpInside)
        
        return button

        
    }()
    
    
    
    
    func userSignOut(){
        
        UserDefaults.standard.set(false,forKey:"distribuUser");
        someTextView2.isHidden = true
        signoutUser.isHidden = true
        let myAlert = UIAlertController(title:"Gates Finder", message:"Signed out successfully", preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
            
            
        })
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }

    
    let someTextView:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.minX + 60 , y: 25, width: 100, height: 20)
        let usertype = UserDefaults.standard.string(forKey: "name")
        theUserName.text = usertype
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    let someTextView2:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.maxX - 80 , y: 25, width: 80, height: 20)
        theUserName.text = "Sign Out"
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    
    
    let someImageView: UIImageView = {
        let screenSize: CGRect = UIScreen.main.bounds
        let profilepic = UserDefaults.standard.object(forKey: "profileImage")
        let theImageView = UIImageView()
        if profilepic != nil {
            theImageView.image = UIImage(data: profilepic as! Data)
            
        }
        else {
            theImageView.image = UIImage(named:"imagesss")
            
        }
        
        theImageView.frame = CGRect(x: screenSize.minX + 10, y: 16, width: 35, height: 35)
        theImageView.layer.borderWidth = 1.0
        theImageView.layer.masksToBounds = false
        theImageView.layer.borderColor = UIColor.black.cgColor
        theImageView.layer.cornerRadius = theImageView.frame.size.width/2
        theImageView.clipsToBounds = true
        theImageView.translatesAutoresizingMaskIntoConstraints = true //You need to call this property so the image is added to your view
        return theImageView
    }()
    func menubar() {
        let distrubUser = UserDefaults.standard.bool(forKey: "distribuUser")
        
        btn1.setImage(UIImage(named: "NavMenu"), for: .normal)
        btn1.addTarget(self, action: #selector(action), for: .touchUpInside)
        btn2.setImage(UIImage(named: "drowarrow"), for: .normal)
        btn2.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn2.addTarget(self, action: #selector(signout), for: .touchUpInside)
        btn3.setImage(UIImage(named: "left-arrow-key"), for: .normal)
        btn3.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn3.addTarget(self, action: #selector(back), for: .touchUpInside)
        
        
        if distrubUser == true {
            someTextView2.isHidden = false
            signoutUser.isHidden = false
            
        }
        else {
            someTextView2.isHidden = true
            signoutUser.isHidden = true
        }
        let item1 = UIBarButtonItem(customView: btn1)
        let item2 = UIBarButtonItem(customView: btn2)
        let item3 = UIBarButtonItem(customView: btn3)
        self.navigationItem.setRightBarButtonItems([item2,item1], animated: true)
        self.navigationItem.setLeftBarButtonItems([item3], animated: true)
        
        
    }
    func back() {
        _ = self.navigationController?.popViewController(animated: true)
        
        dismiss(animated: true, completion: nil)
        
    }
    
    
    func action(sender:UIButton!) {
        menubaraction()
    }
    
    
    
    func menubaraction() {
        let myviewsize = myView.bounds
        
        
        if (menuclicked){
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            })
            
        }
        else
        {
            self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: self.screenSize.width/2, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: myviewsize.width, height:myviewsize.height)
            })
            
            
            
            
        }
        menuclicked = !menuclicked
        
        view.addSubview(myView)
        
    }
    override func viewDidAppear(_ animated: Bool) {
        
        let myviewsize = myView.bounds
        if (menuclicked){
            
            self.myView.frame = CGRect(x: 0, y: 65, width: 0, height:self.screenSize.height - 65)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            menuclicked = !menuclicked
            
        }
        menubar()
    }
    func signout(){
        
        if isclicked2 == true {
            isclicked2 = false
            
            customView.frame = CGRect.init(x: screenSize.minX, y: 64, width: screenSize.width, height: 65)
            customView.backgroundColor = UIColor.white     //give color to the view
            
            self.view.addSubview(customView)
            self.customView.addSubview(someImageView)
            self.customView.addSubview(someTextView)
            self.customView.addSubview(someTextView2)
            self.customView.addSubview(signoutUser)
            
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI))
                
            }
            UIView.animate(withDuration: 0.2, delay: 0.2, options: UIViewAnimationOptions.curveEaseIn, animations: {
                self.customView.alpha = 1.0
                
                
            }, completion: nil)
            
            
            
        }
        else
        {
            isclicked2 = true
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI * 2))
            }
            
            
            UIView.animate(withDuration: 1.0, animations: {
                self.customView.frame.origin.y = self.view.frame.origin.y - self.view.frame.size.height
                
            })
            
        }
        
        
    }

    func deteleIT() {
        UserDefaults.standard.set(false,forKey:"isUserLoggedIn");
        
        UserDefaults.standard.synchronize();
        
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let context = appDel.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Product")
        request.returnsObjectsAsFaults = false
        
        do {
            let results = try context.fetch(request)
            
            if results.count > 0 {
                
                for result in results as! [NSManagedObject]
                {
                    context.delete(result)
                    print("NSManagedObject has been Deleted")
                }
                try context.save() } } catch {}
        
        let request1 = NSFetchRequest<NSFetchRequestResult>(entityName: "OEsearch")
        request1.returnsObjectsAsFaults = false
        
        do {
            let results = try context.fetch(request1)
            
            if results.count > 0 {
                
                for result in results as! [NSManagedObject]
                {
                    context.delete(result)
                    print("NSManagedObject has been Deleted")
                }
                try context.save() } } catch {}
        let request2 = NSFetchRequest<NSFetchRequestResult>(entityName: "Image")
        request2.returnsObjectsAsFaults = false
        
        do {
            let results = try context.fetch(request2)
            
            if results.count > 0 {
                
                for result in results as! [NSManagedObject]
                {
                    context.delete(result)
                    print("NSManagedObject has been Deleted")
                }
                try context.save() } } catch {}
    }
}
