//
//  whatsmoreinfoViewController.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 15/03/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit

class whatsmoreinfoViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    var addnew:String = ""
    var addnew1:String = ""
    var addnew2:String = ""
    var addnew3:String = ""
    var addnew4:String = ""
    var addnew5:String = ""
    var addnew6:String = ""
    var addnew7:String = ""
    var addnew8:String = ""
    var addnew9:String = ""
    var addnew10:String = ""
    var addnew11:String = ""
    var addnew12:String = ""
    var addnew13:String = ""
    var addnew14:String = ""
    var addnew15:String = ""
     var addnew16:String = ""
    
    
    @IBOutlet var img: UIImageView!
    @IBOutlet var tableView: UITableView!
   
    @IBOutlet weak var label: UILabel!
    
    var titleFoeTable:[String?] = []
    var valueFoeTable:[String?] = []

    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        tableView.estimatedRowHeight = 100
        tableView.rowHeight = UITableViewAutomaticDimension
       self.title = "More Details"
        let imageView = UIImageView(frame: self.view.frame)
        let image = UIImage(named: "background-2")!
        imageView.image = image
        self.view.addSubview(imageView)
        self.view.sendSubview(toBack: imageView)
        tableView.backgroundColor = UIColor.clear
        
         self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "Back", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
        menubar()
        
        titleFoeTable = ["Vehicle Make","Vehicle Model","Vehicle Model Code","CC","Year From","Month From","Year Till","Month Till","Part Description","Gates Part Number","Engine Code","Driven Unit 1","Driven Unit 2","Equipment Date From","Equipment Date To","Product Additional Info"]
        valueFoeTable = ["\(addnew1)","\(addnew2)","\(addnew3)","\(addnew4)","\(addnew6)","\(addnew7)","\(addnew8)","\(addnew9)","\(addnew10)","\(addnew5)","\(addnew)","\(addnew11)","\(addnew12)","\(addnew13)","\(addnew14)","\(addnew16)"]
        
        imageload()
       
        
        ///
        
        
        
        
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return titleFoeTable.count
    }

    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath ) as! moreseachTableViewCell
        
        cell.tilte2.text = titleFoeTable[indexPath.row]
        cell.value2.text = valueFoeTable[indexPath.row]
        if indexPath.row % 2 == 0
        {
            cell.backgroundColor = UIColor.darkGray
            cell.tilte2.textColor = UIColor.white
            cell.value2.textColor = UIColor.white
        }
        else
        {
            cell.backgroundColor = UIColor.lightGray
            cell.tilte2.textColor = UIColor.black
            cell.value2.textColor = UIColor.black
            
        }
        
        return cell
    }

    
    ///// tops buttons
    let screenSize: CGRect = UIScreen.main.bounds
    let btn1 = UIButton(frame: CGRect(x: 0, y: 0, width: 20, height: 15))
    var isclicked:Bool! = true
    var menuclicked = false
    let btn2 = UIButton(type: .custom)
    let customView = UIView()
    let btn3 = UIButton()
    let myView = sildermenu()
    
    
    let signoutUser:UIButton = {
        let screenSize: CGRect = UIScreen.main.bounds
        let button = UIButton()
        button.frame = CGRect(x: screenSize.maxX - 140 , y: 25, width: 140, height: 20)
        let image:UIImage = UIImage(named: "signout")!
        button.imageEdgeInsets = UIEdgeInsets(top: 0,left: 14,bottom: 0,right: 100)
        button.setImage(image, for:.normal)
        button.addTarget(self, action: #selector(userSignOut), for: .touchUpInside)
        
        return button

        
    }()
    
    
    
    
    func userSignOut(){
        
        UserDefaults.standard.set(false,forKey:"distribuUser");
        someTextView2.isHidden = true
        signoutUser.isHidden = true
        let myAlert = UIAlertController(title:"Gates Finder", message:"Signed out successfully", preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
            
            
        })
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }
    
    let someTextView:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.minX + 60 , y: 25, width: 100, height: 20)
        let usertype = UserDefaults.standard.string(forKey: "name")
        theUserName.text = usertype
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    let someTextView2:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.maxX - 80 , y: 25, width: 80, height: 20)
        theUserName.text = "Sign Out"
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    
    
    let someImageView: UIImageView = {
        let screenSize: CGRect = UIScreen.main.bounds
        let profilepic = UserDefaults.standard.object(forKey: "profileImage")
        let theImageView = UIImageView()
        if profilepic != nil {
            theImageView.image = UIImage(data: profilepic as! Data)
            
        }
        else {
            theImageView.image = UIImage(named:"imagesss")
            
        }
        
        theImageView.frame = CGRect(x: screenSize.minX + 10, y: 16, width: 35, height: 35)
        theImageView.layer.borderWidth = 1.0
        theImageView.layer.masksToBounds = false
        theImageView.layer.borderColor = UIColor.black.cgColor
        theImageView.layer.cornerRadius = theImageView.frame.size.width/2
        theImageView.clipsToBounds = true
        theImageView.translatesAutoresizingMaskIntoConstraints = true //You need to call this property so the image is added to your view
        return theImageView
    }()
    func menubar() {
        let distrubUser = UserDefaults.standard.bool(forKey: "distribuUser")
        
        btn1.setImage(UIImage(named: "NavMenu"), for: .normal)
        btn1.addTarget(self, action: #selector(action), for: .touchUpInside)
        btn2.setImage(UIImage(named: "drowarrow"), for: .normal)
        btn2.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn2.addTarget(self, action: #selector(signout), for: .touchUpInside)
        btn3.setImage(UIImage(named: "left-arrow-key"), for: .normal)
        btn3.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn3.addTarget(self, action: #selector(back), for: .touchUpInside)
        
        
        if distrubUser == true {
            someTextView2.isHidden = false
            signoutUser.isHidden = false
            
        }
        else {
            someTextView2.isHidden = true
            signoutUser.isHidden = true
        }
        let item1 = UIBarButtonItem(customView: btn1)
        let item2 = UIBarButtonItem(customView: btn2)
        let item3 = UIBarButtonItem(customView: btn3)
        self.navigationItem.setRightBarButtonItems([item2,item1], animated: true)
        self.navigationItem.setLeftBarButtonItems([item3], animated: true)
        
        
        
    }
    func back() {
        _ = self.navigationController?.popViewController(animated: true)
        
        dismiss(animated: true, completion: nil)
        
    }
    
    
    func action(sender:UIButton!) {
        menubaraction()
    }
    
    
    
    func menubaraction() {
        let myviewsize = myView.bounds
        
        
        if (menuclicked){
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            })
            
        }
        else
        {
            self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: self.screenSize.width/2, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: myviewsize.width, height:myviewsize.height)
            })
            
            
            
            
        }
        menuclicked = !menuclicked
        
        view.addSubview(myView)
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        let myviewsize = myView.bounds
        if (menuclicked){
            self.myView.frame = CGRect(x: 0, y: 65, width: 0, height:self.screenSize.height - 65)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            
        }
        menubar()
    }
    ///
    
    func signout(){
        
        if isclicked == true {
            isclicked = false
            
            customView.frame = CGRect.init(x: screenSize.minX, y: 64, width: screenSize.width, height: 65)
            customView.backgroundColor = UIColor.white     //give color to the view
            
            self.view.addSubview(customView)
            self.customView.addSubview(someImageView)
            self.customView.addSubview(someTextView)
            self.customView.addSubview(someTextView2)
            self.customView.addSubview(signoutUser)
            
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI))
                
            }
            UIView.animate(withDuration: 0.2, delay: 0.2, options: UIViewAnimationOptions.curveEaseIn, animations: {
                self.customView.alpha = 1.0
                
                
            }, completion: nil)
            
            
            
        }
        else
        {
            isclicked = true
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI * 2))
            }
            
            
            UIView.animate(withDuration: 1.0, animations: {
                self.customView.frame.origin.y = self.view.frame.origin.y - self.view.frame.size.height
                
            })
            
        }
        
        
    }
    
    
    func imageload() {
        
        
        if addnew15.characters.count >= 4
        {
            if currentReachabilityStatus == .notReachable {
                self.img.image = UIImage(named:"nointernet-1")
                
            }
            else
            {
                
//                let trimmedString = "http://54.255.163.200/ImageUpload/\(addnew15).jpg"
                let catPictureURL = URL(string: addnew15)!
                let session = URLSession(configuration: .default)
                let downloadPicTask = session.dataTask(with: catPictureURL) { (data, response, error) in
                    // The download has finished.
                    if let e = error {
                        print("Error downloading picture: \(e)")
                    } else {
                        // No errors found.
                        // It would be weird if we didn't have a response, so check for that too.
                        if (response as? HTTPURLResponse) != nil {
                            
                            if ((response as? HTTPURLResponse)?.statusCode)! == 200 {
                                
                                if let imageData = data {
                                    // Finally convert that Data into an image and do what you wish with it.
                                    self.img.image = UIImage(data: imageData)
                                    self.label.text = ""
                                    
                                }
                                else {
                                    self.img.image = UIImage(named:"no_image")
                                }
                                // Do something with your image.
                            } else {
                                print("Couldn't get image: Image is nil")
                                self.img.image = UIImage(named:"no_image")
                            }
                        } else {
                            print("Couldn't get response code for some reason")
                            self.img.image = UIImage(named:"no_image")
                        }
                    }
                }
                
                downloadPicTask.resume()
                
                
                
            }
            
        }
        else
        {
            //        img.image = UIImage(data: imageData2 as Data)
            
            img.image = UIImage(named:"no_image")
            
        }
        

    }

}
