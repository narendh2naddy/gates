//
//  distributortableviewTableViewCell.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 15/03/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit

class distributortableviewTableViewCell: UITableViewCell {
    @IBOutlet var distributorName: UILabel!
    @IBOutlet var companyName: UILabel!
    @IBOutlet var contactPersonName: UILabel!
    @IBOutlet var addres: UILabel!
    @IBOutlet var city: UILabel!
    @IBOutlet var state: UILabel!
    @IBOutlet var country: UILabel!
    @IBOutlet var pinncode: UILabel!
    @IBOutlet var email: UILabel!
    @IBOutlet var landline: UILabel!
    @IBOutlet var mobile: UILabel!
    @IBOutlet var picture: UIImageView!
    @IBOutlet var business: UILabel!
    @IBOutlet weak var location: UIButton!
    @IBOutlet weak var edit: UIButton!
    @IBOutlet weak var longtudie: UILabel!
    @IBOutlet weak var usertype: UILabel!
    @IBOutlet weak var business2: UILabel!
   

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
