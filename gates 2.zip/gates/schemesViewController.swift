//
//  schemesViewController.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 31/03/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit

class schemesViewController: UIViewController,UITableViewDelegate, UITableViewDataSource{

    @IBOutlet var img: UIImageView!
    @IBOutlet var tableView: UITableView!
    
    let activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.whiteLarge)
    
    var data:[String] = []
    var data1:[String] = []
    var data2:[String] = []
    var data3:[String] = []
    let country = UserDefaults.standard.string(forKey: "country")
    let mobile = UserDefaults.standard.string(forKey: "mobile")
    let email = UserDefaults.standard.string(forKey: "email")
    var usertype = UserDefaults.standard.string(forKey: "usertype")

   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let skipUser = UserDefaults.standard.bool(forKey: "skipuser");
        
        if skipUser {
            self.displayMyAlertMessage("You skipped registration process. You need to register to view this page. Please go to Edit Profile page to register yourself! ")
            
        }
        
        
        
         self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "Back", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
        if currentReachabilityStatus == .notReachable {
            alert()
        }
        menubar()
        postdata()
//       json(params:["Mobile":mobile!,"Email":email!,"Usertype":usertype!,"Country":country!])
        tableView.tableFooterView = UIView()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        tableView.estimatedRowHeight = 100
        tableView.rowHeight = UITableViewAutomaticDimension
        img.image = UIImage(named: "title_image.png")
        self.title = "Programs"
        let imageView = UIImageView(frame: self.view.frame)
        let image = UIImage(named: "background-2")!
        imageView.image = image
        self.view.addSubview(imageView)
        self.view.sendSubview(toBack: imageView)
        tableView.backgroundColor = UIColor.clear
        activityIndicator.center = CGPoint(x: view.bounds.size.width/2, y: view.bounds.size.height/2)
        activityIndicator.color = UIColor.red
        view.addSubview(activityIndicator)
        
        activityIndicator.isHidden = false
        activityIndicator.startAnimating()
        // Do any additional setup after loading the view.

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func alert(){
        
        let alertController = UIAlertController(title: "Alert", message: "No internet connection", preferredStyle: UIAlertControllerStyle.alert)
        let ok = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: {(action) -> Void in
            
            _ = self.navigationController?.popViewController(animated: true)
            
        })
        
        alertController.addAction(ok)
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    func postdata() {
        if usertype == "Gates Employee"
        {
            usertype = "GatesEmployee"
        }
        let urlString = "http://54.255.163.200/api/common/getschemepassword/?Mobile=\(mobile!)&Email=\(email!)&Usertype=\(usertype!)&Country=\(country!)"
        let urlchange = urlString.replacingOccurrences(of: " ", with: "%20")
        print(urlchange)
        let url = URL(string: urlchange)
        URLSession.shared.dataTask(with:url!) { (data, response, error) in
            if error != nil {
                print(error!)
            } else {
                do {
                    let parsedData = try JSONSerialization.jsonObject(with: data!, options: []) as! NSDictionary
                    print(parsedData)
                    
                   if let result = parsedData["result"] as? String {
                    
                    if result == "Success" {
                    
                        let data = parsedData["data"] as! NSArray
                        
                        if data.count != 0{
                        for i in 0..<data.count {
                            
                            let Schemesname :String!
                            let description :AnyObject!
                            let ShemeExpiryDate :String!
                            let link:String!
                            
                            let subb = data[i] as! NSDictionary
                            
                            
                            if subb["Schemesname"] is NSNull {Schemesname = ""}
                            else { Schemesname = subb["Schemesname"] as! String   }
                            
                            if subb["Product"] is NSNull {description = "" as AnyObject!}
                            else { description = subb["Product"] as AnyObject!   }
                            
                            if subb["UDate"] is NSNull {ShemeExpiryDate = ""}
                            else { ShemeExpiryDate = subb["UDate"] as! String   }
                            
                            if subb["Link"] is NSNull {link = ""}
                            else { link = subb["Link"] as! String   }
                            
                            
                            self.data.append(Schemesname)
                            self.data1.append(description as! String)
                            self.data2.append(ShemeExpiryDate)
                             self.data3.append(link)
                            
                            
                        }
                    }
                    else {
                        self.displayMyAlertMessage("No Programs available!")
                        }
                    }
                    else if result == "InvalidUser"{
                        
                        self.displayMyAlertMessage("Invalid user please contact gates admin!")
                        
                    }
                    else {
                        self.displayMyAlertMessage("No Programs available!")
                        
                    }
                    
                }
                else {  self.displayMyAlertMessage("Server issue try later")    }
                    

                
                
                } catch let error as NSError {
                    print(error)
                }
            }
            self.reload()
            
            }.resume()
        
        reload()
        
        DispatchQueue.main.async(execute: {
            self.activityIndicator.isHidden = true
            self.activityIndicator.stopAnimating()
        })
        
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        if data.count == 0 {
//            let myAlert = UIAlertController(title:"Gates", message:"No Data Found", preferredStyle: UIAlertControllerStyle.alert);
//            
//            let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
//                
//                _ = self.navigationController?.popViewController(animated: true)
//                
//            })
//            
//            myAlert.addAction(okAction);
//            
//            self.present(myAlert, animated:true, completion:nil);
//            
//        }
        
        return  data.count
        
    }
    
//    func numberOfSectionsInTableView(tableView: UITableView) -> Int
//    {
//        return 2
//    }
//    
//    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
//    {
//        
//        return 60
//        
//    }
//    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
//        
//        let reuseIdentifier : String!
//        reuseIdentifier = String(format: "HeaderCell")
//        
//        let headerView = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier)
//        
//        return headerView
//    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath ) as! schemesTableViewCell
        
        cell.lbl1.text = " \(data[indexPath.row])"
        cell.lbl2.text = data1[indexPath.row]
        cell.lbl3.text = data2[indexPath.row]
        cell.moredetails.tag = indexPath.row

        cell.moredetails.addTarget(self, action:#selector(moreinfosss), for: .touchUpInside)
         cell.moredetails.layer.cornerRadius = 5
        
        cell.backgroundColor = UIColor.clear
        let backgroundView = UIView()
        backgroundView.backgroundColor = UIColor.darkGray
        cell.selectedBackgroundView = backgroundView

        return cell
    }
    
   func moreinfosss(_ sender : UIButton){
        
        if data3[sender.tag] == "" {
            
            let myAlert = UIAlertController(title:"Gates Finder", message:"No link Found!!!", preferredStyle: UIAlertControllerStyle.alert);
            
            let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in

                
                
            })
            
            myAlert.addAction(okAction);
            
            self.present(myAlert, animated:true, completion:nil);
            
        }
        else {
            
            
            let urlstring = data3[sender.tag]
           let correctedvalue = urlstring.replacingOccurrences(of: " ", with: "%20")
            
            if let url = NSURL(string:correctedvalue){ UIApplication.shared.open(url as URL, options: [:], completionHandler: nil) }
            
            
        
        }
        
    }
    
    
    
    
    
    
    
    func reload() {
        
        DispatchQueue.main.async{
            self.tableView.reloadData()
        }
    }
    func displayMyAlertMessage(_ userMessage:String)
    {
        
        let myAlert = UIAlertController(title:"Gates Finder", message:userMessage, preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
            
            let vcName = "HomePage"
            let storyboard: UIStoryboard = UIStoryboard (name: "Main", bundle: nil)
            let viewCv = storyboard.instantiateViewController(withIdentifier: vcName)
            self.navigationController?.pushViewController(viewCv, animated: true)
            
        })
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }
    ///// tops buttons
    let screenSize: CGRect = UIScreen.main.bounds
    let btn1 = UIButton(frame: CGRect(x: 0, y: 0, width: 20, height: 15))
    var isclicked:Bool! = true
    var menuclicked = false
    let btn2 = UIButton(type: .custom)
    let customView = UIView()
    let btn3 = UIButton()
    let myView = sildermenu()
    
    
    let signoutUser:UIButton = {
        let screenSize: CGRect = UIScreen.main.bounds
        let button = UIButton()
        button.frame = CGRect(x: screenSize.maxX - 140 , y: 25, width: 140, height: 20)
        let image:UIImage = UIImage(named: "signout")!
        button.imageEdgeInsets = UIEdgeInsets(top: 0,left: 14,bottom: 0,right: 100)
        button.setImage(image, for:.normal)
        button.addTarget(self, action: #selector(userSignOut), for: .touchUpInside)
        
        return button
        
    }()
    
    
    
    
    func userSignOut(){
        
        UserDefaults.standard.set(false,forKey:"distribuUser");
        someTextView2.isHidden = true
        signoutUser.isHidden = true
        let myAlert = UIAlertController(title:"Gates Finder", message:"Signed out successfully", preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
            
            
        })
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }

    
    let someTextView:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.minX + 60 , y: 25, width: 100, height: 20)
        let usertype = UserDefaults.standard.string(forKey: "name")
        theUserName.text = usertype
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    let someTextView2:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.maxX - 80 , y: 25, width: 80, height: 20)
        theUserName.text = "Sign Out"
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    
    
    let someImageView: UIImageView = {
        let screenSize: CGRect = UIScreen.main.bounds
        let profilepic = UserDefaults.standard.object(forKey: "profileImage")
        let theImageView = UIImageView()
        if profilepic != nil {
            theImageView.image = UIImage(data: profilepic as! Data)
            
        }
        else {
            theImageView.image = UIImage(named:"imagesss")
            
        }
        
        theImageView.frame = CGRect(x: screenSize.minX + 10, y: 16, width: 35, height: 35)
        theImageView.layer.borderWidth = 1.0
        theImageView.layer.masksToBounds = false
        theImageView.layer.borderColor = UIColor.black.cgColor
        theImageView.layer.cornerRadius = theImageView.frame.size.width/2
        theImageView.clipsToBounds = true
        theImageView.translatesAutoresizingMaskIntoConstraints = true //You need to call this property so the image is added to your view
        return theImageView
    }()
    func menubar() {
        let distrubUser = UserDefaults.standard.bool(forKey: "distribuUser")
        
        btn1.setImage(UIImage(named: "NavMenu"), for: .normal)
        btn1.addTarget(self, action: #selector(action), for: .touchUpInside)
        btn2.setImage(UIImage(named: "drowarrow"), for: .normal)
        btn2.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn2.addTarget(self, action: #selector(signout), for: .touchUpInside)
        btn3.setImage(UIImage(named: "left-arrow-key"), for: .normal)
        btn3.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn3.addTarget(self, action: #selector(back), for: .touchUpInside)
        
        
        if distrubUser == true {
            someTextView2.isHidden = false
            signoutUser.isHidden = false
            
        }
        else {
            someTextView2.isHidden = true
            signoutUser.isHidden = true
        }
        let item1 = UIBarButtonItem(customView: btn1)
        let item2 = UIBarButtonItem(customView: btn2)
        let item3 = UIBarButtonItem(customView: btn3)
        self.navigationItem.setRightBarButtonItems([item2,item1], animated: true)
        self.navigationItem.setLeftBarButtonItems([item3], animated: true)
        
        
        
    }
    func back() {
        let vcName = "HomePage"
        let storyboard: UIStoryboard = UIStoryboard (name: "Main", bundle: nil)
        let viewCv = storyboard.instantiateViewController(withIdentifier: vcName)
        self.navigationController?.pushViewController(viewCv, animated: true)
        
    }
    
    
    func action(sender:UIButton!) {
        menubaraction()
    }
    
    
    
    func menubaraction() {
        let myviewsize = myView.bounds
        
        
        if (menuclicked){
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            })
            
        }
        else
        {
            self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: self.screenSize.width/2, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: myviewsize.width, height:myviewsize.height)
            })
            
            
            
            
        }
        menuclicked = !menuclicked
        view.addSubview(myView)
        
        
    }
    override func viewDidAppear(_ animated: Bool) {
        
        let myviewsize = myView.bounds
        if (menuclicked){
            
            self.myView.frame = CGRect(x: 0, y: 65, width: 0, height:self.screenSize.height - 65)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            menuclicked = !menuclicked
            
        }
        menubar()
    }
    func signout(){
        
        if isclicked == true {
            isclicked = false
            
            customView.frame = CGRect.init(x: screenSize.minX, y: 64, width: screenSize.width, height: 65)
            customView.backgroundColor = UIColor.white     //give color to the view
            
            self.view.addSubview(customView)
            self.customView.addSubview(someImageView)
            self.customView.addSubview(someTextView)
            self.customView.addSubview(someTextView2)
            self.customView.addSubview(signoutUser)
            
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI))
                
            }
            UIView.animate(withDuration: 0.2, delay: 0.2, options: UIViewAnimationOptions.curveEaseIn, animations: {
                self.customView.alpha = 1.0
                
                
            }, completion: nil)
            
            
            
        }
        else
        {
            isclicked = true
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI * 2))
            }
            
            
            UIView.animate(withDuration: 1.0, animations: {
                self.customView.frame.origin.y = self.view.frame.origin.y - self.view.frame.size.height
                
            })
            
        }
        
        
    }

}
