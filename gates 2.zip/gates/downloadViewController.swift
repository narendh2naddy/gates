//
//  downloadViewController.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 30/03/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit
import CoreData

class downloadViewController: UIViewController {

    @IBOutlet var textlbl: UILabel!
    @IBOutlet var message: UILabel!
    @IBOutlet var alreattext: UILabel!
    @IBOutlet weak var go1: UIButton!
    
    @IBOutlet var processindicate: UIProgressView!
    
    var nee_thirubi_varakudathe:Bool! = false
    var time = Timer()
    let activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.whiteLarge)
    let country = UserDefaults.standard.string(forKey: "country")
    let name = UserDefaults.standard.string(forKey: "name")
    var errorOucc = false
    
    
    override func viewDidAppear(_ animated: Bool) {
        if nee_thirubi_varakudathe! {
            performSegue(withIdentifier: "Navigation", sender: self)
        }
    
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        activityIndicator.center = CGPoint(x: view.bounds.size.width/2, y: view.bounds.size.height/2)
        activityIndicator.color = UIColor.red
        view.addSubview(activityIndicator)

        UserDefaults.standard.set(false, forKey: "downloadsuccss")
        
        UserDefaults.standard.synchronize();

        
       go1.layer.cornerRadius = 5
        go1.isHidden = true
        textlbl.text = name
        postdata()
        
        message.text = "Thank you for registering in Gates Finder. You have chosen \(country!) as your country. You will be able to view \(country!) products !"
        
        self.activityIndicator.isHidden = false
        self.activityIndicator.startAnimating()

       
        // Do any additional setup after loading the view.
    }

    func start(){
        self.activityIndicator.isHidden = true
        self.activityIndicator.stopAnimating()
         time = Timer.scheduledTimer(timeInterval: 0.000001, target: self, selector: #selector(downloadViewController.go), userInfo: nil, repeats: true)
    }
    
    func go()  {
        processindicate.progress += 0.000001
        
        
    }
    
    
    
    @IBAction func gobutton(_ sender: Any) {
        
        if processindicate.progress == 1 {
        
            nee_thirubi_varakudathe = true
            UserDefaults.standard.set(true, forKey: "downloadsuccss")
            UserDefaults.standard.set(true, forKey: "firsttime")
            
            UserDefaults.standard.synchronize();
            
        
            performSegue(withIdentifier: "Navigation", sender: self)
            
            
            
            
        }
        else {
        
            alreattext.text = "Please wait until the data gets downloaded!"
        
        }
        
    }
    
    
    func postdata() {
     
     product()
//        OE()
        print("done comple")
        
    }
    
    
    func product(){
        let appdelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appdelegate.persistentContainer.viewContext
        // Strat of Produt
        let urlString = "http://54.255.163.200/api/product/get/?Country=\(country!)"
        let urlchange = urlString.replacingOccurrences(of: " ", with: "%20")
        let url = URL(string: urlchange)
        URLSession.shared.dataTask(with:url!) { (data, response, error) in
            if error != nil {
                 self.alert("Download interrupted due to \(error?.localizedDescription).Restart the download")
            } else {
                do {
                 
                    let parsedData = try JSONSerialization.jsonObject(with: data!, options: []) as! NSArray
                    DispatchQueue.main.async {
                        for i in 0..<parsedData.count {
                            let product = NSEntityDescription.insertNewObject(forEntityName: "Product", into: context)
                            
                            let Product = parsedData[i] as! NSDictionary
                            
                            if Product["Segment"] is NSNull {product.setValue("", forKey: "segment")}
                            else{product.setValue(Product["Segment"], forKey: "segment")}
                            
                            if Product["Make"] is NSNull {product.setValue("", forKey: "make")}
                            else{product.setValue(Product["Make"], forKey: "make")}
                            
                            if Product["Model"] is NSNull {product.setValue("", forKey: "model")}
                            else{product.setValue(Product["Model"], forKey: "model")}
                            
                            if Product["Stroke"] is NSNull {product.setValue("", forKey: "stroke")}
                            else{product.setValue(Product["Stroke"], forKey: "stroke")}
                            
                            if Product["Modelcode"] is NSNull {product.setValue("", forKey: "modelcode")}
                            else{product.setValue(Product["Modelcode"], forKey: "modelcode")}
                            
                            if Product["Enginecode"] is NSNull {product.setValue("", forKey: "enginecode")}
                            else{product.setValue(Product["Enginecode"], forKey: "enginecode")}
                            
                            if Product["Year_From"] is NSNull {product.setValue("", forKey: "year_From")}
                            else{product.setValue(Product["Year_From"], forKey: "year_From")}
                            
                            if Product["Month_From"] is NSNull {product.setValue("", forKey: "month_From")}
                            else{product.setValue(Product["Month_From"], forKey: "month_From")}
                            
                            if Product["Year_Till"] is NSNull {product.setValue("", forKey: "year_Till")}
                            else{product.setValue(Product["Year_Till"], forKey: "year_Till")}
                            
                            if Product["Month_Till"] is NSNull {product.setValue("", forKey: "month_Till")}
                            else{product.setValue(Product["Month_Till"], forKey: "month_Till")}
                            
                            if Product["PartDescription"] is NSNull {product.setValue("", forKey: "part_Description")}
                            else{product.setValue(Product["PartDescription"], forKey: "part_Description")}
                            
                            if Product["Gates_Part_Number"] is NSNull {product.setValue("", forKey: "gates_Part_Number")}
                            else{product.setValue(Product["Gates_Part_Number"], forKey: "gates_Part_Number")}
                            
                            if Product["Equipment"] is NSNull {product.setValue("", forKey: "equipment")}
                            else{product.setValue(Product["Equipment"], forKey: "equipment")}
                            
                            if Product["Equipment_2"] is NSNull {product.setValue("", forKey: "equipment_2")}
                            else{product.setValue(Product["Equipment_2"], forKey: "equipment_2")}
                            
                            if Product["Equipment_Date_From"] is NSNull {product.setValue("", forKey: "equipment_Date_From")}
                            else{product.setValue(Product["Equipment_Date_From"], forKey: "equipment_Date_From")}
                            
                            if Product["Equipment_Date_To"] is NSNull {product.setValue("", forKey: "equipment_Date_To")}
                            else{product.setValue(Product["Equipment_Date_To"], forKey: "equipment_Date_To")}
                            
                            if Product["Part_Description1"] is NSNull {product.setValue("", forKey: "imageName")}
                            else{product.setValue(Product["Part_Description1"], forKey: "imageName")}

                            if Product["ProductAdditionalInfo"] is NSNull {product.setValue("", forKey: "productAdditionalInfo")}
                            else{product.setValue(Product["ProductAdditionalInfo"], forKey: "productAdditionalInfo")}

                            print("row\(i)\(Product["Make"]!)")
                            do {
                                try context.save()
                                
                            }
                            catch let error as NSError {
                                print(error)
                                self.alert("Download interrupted due to \(error.localizedDescription).Restart the download")

                                
                            }
                          
                            if self.errorOucc {
                            
                                break
                            }
                            
                        }
                        print("DONE1")
                        self.OE()
                    }
                    
                } catch let error as NSError {
                    print(error)
                     self.alert("Download interrupted due to \(error.localizedDescription).Restart the download")

                }
            }
            
            }.resume()
        
     
        /// end of produt
    
    }
    
    
    
    func OE(){
        let appdelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appdelegate.persistentContainer.viewContext
        
        /// strat of OE
        
        let urlString1 = "http://54.255.163.200/api/product/GetOEParts"
        let url1 = URL(string: urlString1)
        URLSession.shared.dataTask(with:url1!) { (data, response, error) in
            if error != nil {
                 self.alert("Download interrupted due to \(error?.localizedDescription).Restart the download")
            } else {
                do {
                    let parsedData1 = try JSONSerialization.jsonObject(with: data!, options: []) as! NSArray
                     DispatchQueue.main.async {
                        for i in 0..<parsedData1.count {
                            ///////
                            let product1 = NSEntityDescription.insertNewObject(forEntityName: "OEsearch", into: context)
                            
                            let Product1 = parsedData1[i] as! NSDictionary
                            
                            if Product1["OEMake"] is NSNull {product1.setValue("", forKey: "oeMake")}
                            else{product1.setValue(Product1["OEMake"], forKey: "oeMake")}
                            
                            if Product1["OENumber"] is NSNull {product1.setValue("", forKey: "oeNumber")}
                            else{product1.setValue(Product1["OENumber"], forKey: "oeNumber")}

                            if Product1["PartDescription"] is NSNull {product1.setValue("", forKey: "partDescription")}
                            else{product1.setValue(Product1["PartDescription"], forKey: "partDescription")}

                            if Product1["gatesPartNumber"] is NSNull {product1.setValue("", forKey: "gatesPartNumber")}
                            else{product1.setValue(Product1["gatesPartNumber"], forKey: "gatesPartNumber")}

                            if Product1["Part_Description"] is NSNull {product1.setValue("", forKey: "imageName")}
                            else{product1.setValue(Product1["Part_Description"], forKey: "imageName")}

                            print("OE Row \(i)")
                            do {
                                try context.save()
                                
                            }
                            catch let error as NSError {
                                print(error)
                                 self.alert("Download interrupted due to \(error.localizedDescription).Restart the download")

                                
                            }
                          
                            if self.errorOucc {
                                
                                break
                            }
                            
                            ////////
                            
                        }
                        print("DONE2")
                        self.go1.isHidden = false
                        DispatchQueue.main.async {
                            
                            self.start()
                        }
                        

                }
                
                } catch let error as NSError {
                    print(error)
                    self.alert("Download interrupted due to \(error.localizedDescription).Restart the download")

                }
            }
            
            }.resume()
        
        
        ///end of oe
    }
    func postdata3() {
        
        let appdelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appdelegate.persistentContainer.viewContext
        
        let urlString = "http://54.255.163.200/api/common/getImages"
        
        let url = URL(string: urlString)
        URLSession.shared.dataTask(with:url!) { (data, response, error) in
            if error != nil {
                print(error!)
            } else {
                do {
                    
                    let parsedData = try JSONSerialization.jsonObject(with: data!, options: []) as! NSDictionary
                    DispatchQueue.main.async {
                        
                        if let result = parsedData["result"] as? String  {
                        print(result)
                        if result == "Success" {
                            let data = parsedData["data"] as! NSArray
                            for i in 0..<data.count {
                                
                                let product = NSEntityDescription.insertNewObject(forEntityName: "Image", into: context)
                                
                                let Product = data[i] as! NSDictionary
                                
                                let aString = (Product["Part_Description"]) as! String
                                if aString != "" {
                                let newString = aString.replacingOccurrences(of: " ", with: "_", options: .literal, range: nil)
                                
                                print(aString)
                                product.setValue(newString, forKey: "imageName")
                                }
                                
                                let value = (Product["ProductURL"]) as! String
                                if value != ""{
                                let url = value.trimmingCharacters(in: .whitespaces)
                                let pictureURL = URL(string:url)!
                                let session = URLSession(configuration: .default)
                                let downloadPicTask = session.dataTask(with: pictureURL) { (data, response, error) in
                                    // The download has finished.
                                    if let e = error {
                                        print("Error downloading picture: \(e)")
                                    } else {
                                        // No errors found.
                                        // It would be weird if we didn't have a response, so check for that too.
                                        if (response as? HTTPURLResponse) != nil {
                                            if let imageData = data {
                                                // Finally convert that Data into an image and do what you wish with it.
                                                product.setValue(imageData, forKey: "imageData")
                                                print("this the\(imageData)")
                                                
                                                
                                                // Do something with your image.
                                            } else {
                                                print("Couldn't get image: Image is nil")
                                            }
                                        } else {
                                            print("Couldn't get response code for some reason")
                                        }
                                    }
                                }
                                
                                downloadPicTask.resume()
                                
                            }
                            
                            }
                            do {
                                try context.save()
                                
                            }
                            catch {
                                print("errro")
                                
                            }
                            ////////
                        }
                        }
                        //////

                    }
                    self.product()
                    
                } catch let error as NSError {
                    print(error)
                }
            }
            
            }.resume()
        
        //
    }
    
    
    
    func alert(_ userMessage:String){
        
        let alertController = UIAlertController(title: "OOPS!!!", message: userMessage, preferredStyle: UIAlertControllerStyle.alert)
        let ok = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: {(action) -> Void in
          
           self.restated()
            
        })
        
        alertController.addAction(ok)
        self.present(alertController, animated: true, completion: nil)
       
        
        
}
    
    
    
    func restated() {
        
        if currentReachabilityStatus == .notReachable {
            alert("No internet Connection")
        }
        else {
//        errorOucc = true
        deteleIT()
        processindicate.progress = 0
        postdata()
        }
    }
    
    func deteleIT() {
        
        let appDel = UIApplication.shared.delegate as! AppDelegate
        let context = appDel.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Product")
        request.returnsObjectsAsFaults = false
        
        do {
            let results = try context.fetch(request)
            
            if results.count > 0 {
                
                for result in results as! [NSManagedObject]
                {
                    context.delete(result)
                    print("NSManagedObject has been Deleted")
                }
                try context.save() } } catch {}
        
        let request1 = NSFetchRequest<NSFetchRequestResult>(entityName: "OEsearch")
        request1.returnsObjectsAsFaults = false
        
        do {
            let results = try context.fetch(request1)
            
            if results.count > 0 {
                
                for result in results as! [NSManagedObject]
                {
                    context.delete(result)
                    print("NSManagedObject has been Deleted")
                }
                try context.save() } } catch {}
//        let request2 = NSFetchRequest<NSFetchRequestResult>(entityName: "Image")
//        request2.returnsObjectsAsFaults = false
//        
//        do {
//            let results = try context.fetch(request2)
//            
//            if results.count > 0 {
//                
//                for result in results as! [NSManagedObject]
//                {
//                    context.delete(result)
//                    print("NSManagedObject has been Deleted")
//                }
//                try context.save() } } catch {}
    }

    
}
