//
//  PDTableViewCell.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 04/03/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit

class PDTableViewCell: UITableViewCell {
    @IBOutlet var label1: UILabel!
    @IBOutlet var label2: UILabel!
    @IBOutlet var label4: UILabel!
    @IBOutlet var label6: UILabel!
    @IBOutlet var label7: UILabel!
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
}
