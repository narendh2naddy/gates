//
//  distributormapController.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 13/03/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit

struct Location {
    let title: String
    let latitude: Double
    let longitude: Double
}

class MyPointAnnotation : MKPointAnnotation {
    var pinTintColor: UIColor?
}



class distributormapController: UIViewController , CLLocationManagerDelegate,ZHDropDownMenuDelegate,ZHDropDownMenuDelegate2,ZHDropDownMenuDelegate3,MKMapViewDelegate{
 
    
    
    var dataGet:[String]! = []
    var dataGet1:[String]! = []
    var dataGet2:[String]! = []
    var dataGet3:[AnyObject]! = []
    var dataGet4:[AnyObject]! = []
    var dataGet5:[String]! = []

    
    
    @IBOutlet weak var menu: ZHDropDownMenu!
    @IBOutlet weak var menu1: ZHDropDownMenu2!
    @IBOutlet weak var menu2: ZHDropDownMenu3!
    
    var State:String! = ""
    var City:String! = ""
    var Usertype:String! = ""
    let country:String! = UserDefaults.standard.string(forKey: "country")
    
//    let country = "Thailand"

    let locationManager = CLLocationManager()
    
    @IBOutlet var img: UIImageView!
    
    @IBOutlet weak var map: MKMapView!
    var matchingItems: [MKMapItem] = [MKMapItem]()
    
    let loc = GetLocation()
    
    
   
        
        override func viewDidLoad() {
            super.viewDidLoad()
            self.map.delegate = self;
             menu2.delegate = self
            menu1.delegate = self
            menu.delegate = self
            let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
            backgroundImage.image = UIImage(named: "background-2")
            backgroundImage.contentMode =  UIViewContentMode.scaleAspectFill
            self.view.insertSubview(backgroundImage, at: 0)
            
             self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "Back", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
            menubar()
            
            menu.menuHeight = 100;
            menu.buttonImage = UIImage(named: "default_down.png")
            
            menu1.menuHeight = 100;
            menu1.buttonImage = UIImage(named: "default_down.png")
            
            menu2.menuHeight = 100;
            menu2.buttonImage = UIImage(named: "default_down.png")
            
            self.title = "Channel Network Map"
            menu.placeholder = "All"
            menu1.placeholder = "All"
            menu2.placeholder = "All"

            img.image = UIImage(named: "title_image.png")
            map.showsUserLocation = true
            
          self.tabBarController?.title = " Channel Network Map"

            if (CLLocationManager.locationServicesEnabled())
            {
                locationManager.delegate = self
                locationManager.desiredAccuracy = kCLLocationAccuracyBest
                locationManager.requestAlwaysAuthorization()
                locationManager.startUpdatingLocation()
               
            }
           
            
             postdata()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        
        let location = locations.last! as CLLocation
        
        let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        
        self.map.setRegion(region, animated: true)
         locationManager.stopUpdatingLocation()
    }
    
    
    ///////////
       
    
    func dropDownMenu(_ menu: ZHDropDownMenu!, didChoose index: Int,didInput text: String!){
        
        self.State = text
        
        if State != "All" {
            
            
            City = ""
            dataGet2.removeAll()
            dataGet2 = ["All"]
            menu1.defaultValue = "All"
            filter()
            
            locationManager.stopUpdatingLocation()
            let locations2 = self.geoCodeUsingAddress(address: State as NSString)
            
            let center = locations2
            let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 2, longitudeDelta: 2))
            
            self.map.setRegion(region, animated: true)
            
        }
        else
        {
            State = ""
            
            filter()
            locationManager.stopUpdatingLocation()
            let locations2 = self.geoCodeUsingAddress(address: country as NSString)
            
            let center = locations2
            let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 2, longitudeDelta: 2))
            
            self.map.setRegion(region, animated: true)
            
        }
        
        
    }
    
    public func dropDownMenu2(_ menu: ZHDropDownMenu2!, didChoose index: Int, didInput text: String!) {
        self.City = text
        
        
        if City != "All"{
            filter()
           
            locationManager.stopUpdatingLocation()
            let locations2 = self.geoCodeUsingAddress(address: City as NSString)
            
            let center = locations2
            let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 2, longitudeDelta: 2))
            
            self.map.setRegion(region, animated: true)
            
        }
        else {
            
            City = ""
            filter()
            
            
            locationManager.stopUpdatingLocation()
            let locations2 = self.geoCodeUsingAddress(address: country as NSString)
            
            let center = locations2
            let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 2, longitudeDelta: 2))
            
            self.map.setRegion(region, animated: true)
        }
        
        
        
    }
    
    public func dropDownMenu3(_ menu: ZHDropDownMenu3!, didChoose index: Int, didInput text: String!) {
        
        
        self.Usertype = text
        
        
        if Usertype != "All"{
            filter()
            locationManager.stopUpdatingLocation()
            let locations2 = self.geoCodeUsingAddress(address: country as NSString)
            
            let center = locations2
            let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 5, longitudeDelta: 5))

            self.map.setRegion(region, animated: true)
            
        }
        else {
            
            Usertype = ""
            filter()
            let locations2 = self.geoCodeUsingAddress(address: country as NSString)
            
            let center = locations2
            let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 5, longitudeDelta: 5))

            
            locationManager.stopUpdatingLocation()
            self.map.setRegion(region, animated: true)


            
        }
        
        
    }
    
    
    
    
    
    func geoCodeUsingAddress(address: NSString) -> CLLocationCoordinate2D {
        var latitude: Double = 0
        var longitude: Double = 0
        
        let addressstr : NSString = "http://maps.google.com/maps/api/geocode/json?sensor=false&address=\(address),\(country!)" as NSString
        let urlStr  = addressstr.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)
        let searchURL: NSURL = NSURL(string: urlStr! as String)!
        do {
            let newdata = try Data(contentsOf: searchURL as URL)
            if let responseDictionary = try JSONSerialization.jsonObject(with: newdata, options: []) as? NSDictionary {
                let status = responseDictionary.object(forKey: "status") as! String
                print(status)
                if status == "OK" {
                    let array = responseDictionary.object(forKey: "results") as! NSArray
                    let dic = array[0] as! NSDictionary
                    let locationDic = (dic.object(forKey: "geometry") as! NSDictionary).object(forKey: "location") as! NSDictionary
                    latitude = locationDic.object(forKey: "lat") as! Double
                    longitude = locationDic.object(forKey: "lng") as! Double
                    
                }
                else if status == "OVER_QUERY_LIMIT" {
                    
                    let myAlert = UIAlertController(title:"Gates Finder", message:"There is an issue with google maps service try once again !!!", preferredStyle: UIAlertControllerStyle.alert);
                    
                    let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
                        
                        latitude = 0.0
                        longitude = 0.0
                        
                    })
                    
                    myAlert.addAction(okAction);
                    
                    self.present(myAlert, animated:true, completion:nil);
                
                
                
                }
                else {
                    let myAlert = UIAlertController(title:"Gates Finder", message:"Invalid Address !!!", preferredStyle: UIAlertControllerStyle.alert);
                    
                    let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
                        
                        latitude = 0.0
                        longitude = 0.0
                        
                    })
                    
                    myAlert.addAction(okAction);
                    
                    self.present(myAlert, animated:true, completion:nil);
                    
                }
            }} catch {
                
        }
        var center = CLLocationCoordinate2D()
        center.latitude = latitude
        center.longitude = longitude
        return center
    }
    
    
    func postdata() {
        
        dataGet1 = ["All"]
        dataGet2 = ["All"]

        
        
        let urlString = "http://54.255.163.200/api/distributor/get/?Country=\(country!)"
        let formattedString = urlString.replacingOccurrences(of: " ", with: "%20")
        let url = URL(string: formattedString)
        URLSession.shared.dataTask(with:url!) { (data, response, error) in
            if error != nil {
                print(error!)
            } else {
                do {
                    let parsedData = try JSONSerialization.jsonObject(with: data!, options: []) as! NSDictionary
                    let result = parsedData["result"] as! String
                    if result == "Success" {
                        let data = parsedData["data"] as! NSArray
                        for i in 0..<data.count {
                            
                            let Product = data[i] as! NSDictionary
                            
                             if Product["CompanyName"] is NSNull {self.dataGet.append("")} else {self.dataGet.append((Product["CompanyName"]) as! String)}
                            
                             if Product["State"] is NSNull {self.dataGet1.append("")} else {self.dataGet1.append((Product["State"]) as! String)}
                            
                             if Product["City"] is NSNull {self.dataGet2.append("")} else {self.dataGet2.append((Product["City"]) as! String)}
                            
                             if Product["Latitude"] is NSNull {self.dataGet3.append("" as AnyObject)} else {self.dataGet3.append((Product["Latitude"]) as AnyObject)}
                             if Product["Longitude"] is NSNull {self.dataGet4.append("" as AnyObject)} else {self.dataGet4.append((Product["Longitude"]) as AnyObject)}
                             if Product["TypeOfUser"] is NSNull {self.dataGet5.append("")} else {self.dataGet5.append(Product["TypeOfUser"] as! String)}
                            
                            
//                            self.dataGet.append(Product["Name"] as! String)
//                            self.dataGet1.append(Product["State"] as! String)
//                            self.dataGet2.append(Product["City"] as! String)
//                            self.dataGet3.append(Product["Latitude"]  as AnyObject)
//                             self.dataGet4.append(Product["Longitude"] as AnyObject)
//                            self.dataGet5.append(Product["TypeOfUser"] as! String)
                            if (Product["Latitude"] is NSNull) || (Product["Longitude"] is NSNull) || (Product["CompanyName"] is NSNull) || (Product["TypeOfUser"] is NSNull) {
                            }
                            else {
                           
                            if (Product["Latitude"] as! String) == "" || (Product["Latitude"] as! String) == "NULL" {
                            
                            }
                            else
                            {
                                 print(Product["Latitude"]!)
                                let x = Double(Product["Latitude"] as! String)
                                let y = Double(Product["Longitude"]as! String)
                            let latitude: CLLocationDegrees = CLLocationDegrees(x!)
                            let longitude: CLLocationDegrees = CLLocationDegrees(y!)
                            
                            let locations = [
                                Location(title: (Product["CompanyName"]) as! String,  latitude:latitude , longitude:longitude)]
                            
                            for location in locations {
                                let annotation = MyPointAnnotation()
                                
                                if (Product["TypeOfUser"] as! String)=="Distributor"
                                {
                                    annotation.pinTintColor = .red
                                }
                                else if (Product["TypeOfUser"] as! String)=="Work Shop"
                                {
                                    annotation.pinTintColor = .blue
                                }
                                else
                                {
                                    
                                    annotation.pinTintColor = .green
                                    
                                }
                                
                                annotation.title = location.title
                                annotation.coordinate = CLLocationCoordinate2D(latitude: location.latitude, longitude: location.longitude)
                                self.map.addAnnotation(annotation) ///
                            }
                            
                            }
                            }
                            
                        }
                        
                        
                    }
                    
                    
                } catch let error as NSError {
                    print(error)
                }
            }
            self.reload()
            
            }.resume()
        
      reload()
        
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: "myAnnotation") as? MKPinAnnotationView
        
        if annotation is MKUserLocation {
            let pin = mapView.view(for: annotation) ?? MKAnnotationView(annotation: annotation, reuseIdentifier: nil)
            pin.image = UIImage(named: "current-location")
            pin.canShowCallout = true
            return pin
        }
        
        if annotationView == nil {
            annotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: "myAnnotation")
        } else {
            annotationView?.annotation = annotation
        }
        
        if let annotation = annotation as? MyPointAnnotation {
            annotationView?.pinTintColor = annotation.pinTintColor
        }
        
        annotationView?.canShowCallout = true
        annotationView?.animatesDrop = false
    
        return annotationView
    }

    func reload() {
        
        DispatchQueue.main.async{
            //
            self.menu.options = self.uniq(source: self.dataGet1.map { $0.capitalized})
            self.menu1.options = self.uniq(source: self.dataGet2.map { $0.capitalized})
            self.menu2.options = ["All","Distributor","Work Shop","Part Shop"]
            
            
            
        }
    }

    
    
    
    func filter(){
        
        map.removeAnnotations(map.annotations)
        
        let urlString = "http://54.255.163.200/api/distributor/get/?TypeOfUser=\(Usertype!)&Country=\(country!)&State=\(State!)&City=\(City!)"
        
        print(urlString)
        
        let formattedString = urlString.replacingOccurrences(of: " ", with: "%20")
        let url = URL(string: formattedString)
        URLSession.shared.dataTask(with:url!) { (data, response, error) in
            if error != nil {
                print(error!)
            } else {
                do {
                    let parsedData = try JSONSerialization.jsonObject(with: data!, options: []) as! NSDictionary
                    
                    let result = parsedData["result"] as! String
                    if result == "Success" {
                        let data = parsedData["data"] as! NSArray
                        //
                        for i in 0..<data.count {
                            
                            let Product = data[i] as! NSDictionary
                            
                            if Product["CompanyName"] is NSNull {self.dataGet.append("")} else {self.dataGet.append((Product["CompanyName"]) as! String)}
                            
                            if Product["State"] is NSNull {self.dataGet1.append("")} else {self.dataGet1.append((Product["State"]) as! String)}
                            
                            if Product["City"] is NSNull {self.dataGet2.append("")} else {self.dataGet2.append((Product["City"]) as! String)}
                            
                            if Product["Latitude"] is NSNull {self.dataGet3.append("" as AnyObject)} else {self.dataGet3.append((Product["Latitude"]) as AnyObject)}
                            if Product["Longitude"] is NSNull {self.dataGet4.append("" as AnyObject)} else {self.dataGet4.append((Product["Longitude"]) as AnyObject)}
                            if Product["TypeOfUser"] is NSNull {self.dataGet5.append("")} else {self.dataGet5.append(Product["TypeOfUser"] as! String)}

                            
                            if (Product["Latitude"] is NSNull) || (Product["Longitude"] is NSNull) || (Product["CompanyName"] is NSNull) || (Product["TypeOfUser"] is NSNull) {
                            }
                                
                            else if (Product["Latitude"] as! String) == "" || (Product["Latitude"] is NSNull) || (Product["Latitude"] as! String) == "NULL"{
                                
                            }
                            else
                            {
                                let x = Double(Product["Latitude"] as! String)
                                let y = Double(Product["Longitude"]as! String)
                                let latitude: CLLocationDegrees = CLLocationDegrees(x!)
                                let longitude: CLLocationDegrees = CLLocationDegrees(y!)
                                
                                let locations = [
                                    Location(title: (Product["CompanyName"]) as! String,  latitude:latitude , longitude:longitude)]
                                
                                for location in locations {
                                    let annotation = MyPointAnnotation()
                                    if (Product["TypeOfUser"] as! String)=="Distributor"
                                    {
                                        annotation.pinTintColor = .red
                                    }
                                    else if (Product["TypeOfUser"] as! String)=="Work Shop"
                                    {
                                        annotation.pinTintColor = .blue
                                    }
                                    else
                                    {
                                        
                                        annotation.pinTintColor = .green
                                        
                                    }
                                    
                                    annotation.title = location.title
                                    annotation.coordinate = CLLocationCoordinate2D(latitude: location.latitude, longitude: location.longitude)
                                    self.map.addAnnotation(annotation) ///
                                }
                                
                            }
                            
                            
                            //
                        }
                        
                        
                    }
                        
                    
                        //
                        
                        
                   
                    
                    
                } catch let error as NSError {
                    print(error)
                }
            }
            self.reload()
            
            }.resume()
        
        reload()
        
        
    }
    
    func uniq<S : Sequence, T : Hashable>(source: S) -> [T] where S.Iterator.Element == T {
        var buffer = [T]()
        var added = Set<T>()
        for elem in source {
            if !added.contains(elem) {
                buffer.append(elem)
                added.insert(elem)
            }
        }
        return buffer
    }
    
    ///// tops buttons
    let screenSize: CGRect = UIScreen.main.bounds
    let btn1 = UIButton(frame: CGRect(x: 0, y: 0, width: 20, height: 15))
    var isclicked:Bool! = true
    var menuclicked = false
    let btn2 = UIButton(type: .custom)
    let customView = UIView()
    let btn3 = UIButton()
    let myView = sildermenu()
    
    
    let signoutUser:UIButton = {
        let screenSize: CGRect = UIScreen.main.bounds
        let button = UIButton()
        button.frame = CGRect(x: screenSize.maxX - 140 , y: 25, width: 140, height: 20)
        let image:UIImage = UIImage(named: "signout")!
        button.imageEdgeInsets = UIEdgeInsets(top: 0,left: 14,bottom: 0,right: 100)
        button.setImage(image, for:.normal)
        button.addTarget(self, action: #selector(userSignOut), for: .touchUpInside)
        
        return button

        
    }()
    
    
    
    
    func userSignOut(){
        
        UserDefaults.standard.set(false,forKey:"distribuUser");
        someTextView2.isHidden = true
        signoutUser.isHidden = true
        let myAlert = UIAlertController(title:"Gates Finder", message:"Signed out successfully", preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
            let vcName = "distributionNetwork"
            let storyboard: UIStoryboard = UIStoryboard (name: "Main", bundle: nil)
            let viewCv = storyboard.instantiateViewController(withIdentifier: vcName)
            self.navigationController?.pushViewController(viewCv, animated: true)
            
        })
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }

    
    let someTextView:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.minX + 60 , y: 25, width: 100, height: 20)
        let usertype = UserDefaults.standard.string(forKey: "name")
        theUserName.text = usertype
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    let someTextView2:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.maxX - 80 , y: 25, width: 80, height: 20)
        theUserName.text = "Sign Out"
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    
    
    let someImageView: UIImageView = {
        let screenSize: CGRect = UIScreen.main.bounds
        let profilepic = UserDefaults.standard.object(forKey: "profileImage")
        let theImageView = UIImageView()
        if profilepic != nil {
            theImageView.image = UIImage(data: profilepic as! Data)
            
        }
        else {
            theImageView.image = UIImage(named:"imagesss")
            
        }
        
        theImageView.frame = CGRect(x: screenSize.minX + 10, y: 16, width: 35, height: 35)
        theImageView.layer.borderWidth = 1.0
        theImageView.layer.masksToBounds = false
        theImageView.layer.borderColor = UIColor.black.cgColor
        theImageView.layer.cornerRadius = theImageView.frame.size.width/2
        theImageView.clipsToBounds = true
        theImageView.translatesAutoresizingMaskIntoConstraints = true //You need to call this property so the image is added to your view
        return theImageView
    }()
    func menubar() {
        let distrubUser = UserDefaults.standard.bool(forKey: "distribuUser")
        
        btn1.setImage(UIImage(named: "NavMenu"), for: .normal)
        btn1.addTarget(self, action: #selector(action), for: .touchUpInside)
        btn2.setImage(UIImage(named: "drowarrow"), for: .normal)
        btn2.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn2.addTarget(self, action: #selector(signout), for: .touchUpInside)
        btn3.setImage(UIImage(named: "left-arrow-key"), for: .normal)
        btn3.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn3.addTarget(self, action: #selector(back), for: .touchUpInside)
        
        
        if distrubUser == true {
            someTextView2.isHidden = false
            signoutUser.isHidden = false
            
        }
        else {
            someTextView2.isHidden = true
            signoutUser.isHidden = true
        }
        let item1 = UIBarButtonItem(customView: btn1)
        let item2 = UIBarButtonItem(customView: btn2)
        let item3 = UIBarButtonItem(customView: btn3)
        self.tabBarController?.navigationItem.setRightBarButtonItems([item2,item1], animated: true)
        self.tabBarController?.navigationItem.setLeftBarButtonItems([item3], animated: true)
        
        
        
        
    }
    func back() {
        _ = self.navigationController?.popViewController(animated: true)
        
        dismiss(animated: true, completion: nil)
        
    }
    
    
    func action(sender:UIButton!) {
        menubaraction()
    }
    
    
    
    func menubaraction() {
        let myviewsize = myView.bounds
        
        
        if (menuclicked){
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            })
            
        }
        else
        {
            self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: self.screenSize.width/2, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: myviewsize.width, height:myviewsize.height)
            })
            
            
            
            
        }
        menuclicked = !menuclicked
        
        view.addSubview(myView)
        
    }
    override func viewDidAppear(_ animated: Bool) {
        
        let myviewsize = myView.bounds
        if (menuclicked){
            
            self.myView.frame = CGRect(x: 0, y: 65, width: 0, height:self.screenSize.height - 65)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            menuclicked = !menuclicked
            
        }
        menubar()
    }
    func signout(){
        
        if isclicked == true {
            isclicked = false
            
            customView.frame = CGRect.init(x: screenSize.minX, y: 64, width: screenSize.width, height: 65)
            customView.backgroundColor = UIColor.white     //give color to the view
            
            self.view.addSubview(customView)
            self.customView.addSubview(someImageView)
            self.customView.addSubview(someTextView)
            self.customView.addSubview(someTextView2)
            self.customView.addSubview(signoutUser)
            
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI))
                
            }
            UIView.animate(withDuration: 0.2, delay: 0.2, options: UIViewAnimationOptions.curveEaseIn, animations: {
                self.customView.alpha = 1.0
                
                
            }, completion: nil)
            
            
            
        }
        else
        {
            isclicked = true
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI * 2))
            }
            
            
            UIView.animate(withDuration: 1.0, animations: {
                self.customView.frame.origin.y = self.view.frame.origin.y - self.view.frame.size.height
                
            })
            
        }
        
        
    }

}



