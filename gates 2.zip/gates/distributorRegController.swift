//
//  distributorRegController.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 14/03/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit
import Alamofire


class distributorRegController: UIViewController,UIImagePickerControllerDelegate, UINavigationControllerDelegate,UITextFieldDelegate{
    @IBOutlet weak var usertyprdropdown: DropMenuButton!

//    @IBOutlet var Name: UITextField!
      
    @IBOutlet weak var companyex: UITextView!
//    @IBOutlet var Company: UITextField!
    
    @IBOutlet var Contact: UITextField!
    
    @IBOutlet weak var addresss: UITextView!
//    @IBOutlet var Address: UITextField!
    
    @IBOutlet var City: UITextField!
    
    @IBOutlet var State: UITextField!
    
    @IBOutlet var pincode: UITextField!
    
    @IBOutlet var Email: UITextField!
    @IBOutlet weak var addbutton: UIButton!
    @IBOutlet weak var cancelbutton: UIButton!
    
    @IBOutlet var LandLine: UITextField!
    @IBOutlet var Mobile: UITextField!
    @IBOutlet var Opportunities: UITextField!
    @IBOutlet var latitude: UITextField!
    @IBOutlet var longitute: UITextField!

    @IBOutlet weak var header: UIImageView!
    @IBOutlet weak var countrydroper: UILabel!
    @IBOutlet var img: UIImageView!
    let picker = UIImagePickerController()
    var data:NSData!
    var imagedata:NSMutableArray!
    let country = UserDefaults.standard.string(forKey: "country")
            var freshLaunch = true
    @IBOutlet weak var dsubView: UIView!
   
   var usertype5555 = ""

    let activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.whiteLarge)

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        addbutton.layer.cornerRadius = 5
        cancelbutton.layer.cornerRadius = 5

        header.image = UIImage(named: "title_image.png")
         picker.delegate = self
        let imageView = UIImageView(frame: self.view.frame)
        let image = UIImage(named: "background-2")!
        imageView.image = image
        self.view.addSubview(imageView)
        self.view.sendSubview(toBack: imageView)
        self.title = " Add Channel Network"
        
         self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "Back", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
        menubar()
        countrydroper.text = country
//        countrydroper.layer.borderColor = UIColor.white.cgColor
//        countrydroper.layer.borderWidth = 1
        UITabBarItem.appearance().setTitleTextAttributes([NSForegroundColorAttributeName : UIColor.red], for: .normal)
         self.navigationController?.navigationBar.barTintColor = UIColor.black

        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(trainingVideoLoginPageViewController.dismissKeyboard))
        tap.numberOfTapsRequired = 2
        view.addGestureRecognizer(tap)
        
//        Name.delegate = self
//        Company.delegate = self
//         Contact.delegate = self
//        Address.delegate = self
//         City.delegate = self
      State.delegate = self
         pincode.delegate = self
        Email.delegate = self
     LandLine.delegate = self
       Mobile.delegate = self
         Opportunities.delegate = self
        latitude.delegate = self
        longitute.delegate = self
        
        activityIndicator.center = CGPoint(x: view.bounds.size.width/2, y: view.bounds.size.height/2)
        activityIndicator.color = UIColor.red
        view.addSubview(activityIndicator)
        companyex.layer.cornerRadius = 5
        addresss.layer.cornerRadius = 5
//
        
        usertyprdropdown.layer.cornerRadius = 5
        usertyprdropdown.layer.borderWidth = 1
        usertyprdropdown.layer.borderColor = UIColor.white.cgColor

        
        usertyprdropdown.initMenu(["Distributor","Work Shop","Part Shop"],
                                     actions: [({ () -> (Void) in
                                        self.usertype5555 = "Distributor"
                                        print("select the ddd")
                                     }),
                                               ({ () -> (Void) in
                                                self.usertype5555 = "Work Shop"
                                               }),
                                               ({ () -> (Void) in
                                                self.usertype5555 = "Part Shop"
                                               })])
        
        
        
        // Do any additional setup after loading the view.
    }
    
    
    
    
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
//        Name.resignFirstResponder()
        Contact.resignFirstResponder()
        City.resignFirstResponder()
        State.resignFirstResponder()
        pincode.resignFirstResponder()
        Email.resignFirstResponder()
        LandLine.resignFirstResponder()
         Mobile.resignFirstResponder()
         Opportunities.resignFirstResponder()
         latitude.resignFirstResponder()
         longitute.resignFirstResponder()
        return true
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
        
    }
    
    func animateTextField(textField: UITextField, up: Bool)
    {
        let movementDistance:CGFloat = -150
        let movementDuration: Double = 0.3
        
        var movement:CGFloat = 0
        if up
        {
            movement = movementDistance
        }
        else
        {
            movement = -movementDistance
        }
        UIView.beginAnimations("animateTextField", context: nil)
        UIView.setAnimationBeginsFromCurrentState(true)
        UIView.setAnimationDuration(movementDuration)
        self.view.frame = self.view.frame.offsetBy(dx: 0, dy: movement)
        UIView.commitAnimations()
    }
    
    
    func textFieldDidBeginEditing(_ textField: UITextField)
    {
        self.animateTextField(textField: textField, up:true)
    }
    
    func textFieldDidEndEditing(_ textField: UITextField)
    {
        self.animateTextField(textField: textField, up:false)
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func add(_ sender: Any) {
        dismissKeyboard()
        self.activityIndicator.isHidden = false
        self.activityIndicator.startAnimating()
        
   
        
        if usertype5555 != ""{
        
        if (!(companyex.text?.isEmpty)!)  && (!(City.text?.isEmpty)!) && (!(State.text?.isEmpty)!) {
        
            if data == nil {
            
                json(params:["Name":"","CompanyName":companyex.text!,"contactperson":Contact.text!,"Address":addresss.text!,"City":City.text!,"State":State.text!,"Pincode":pincode.text!,"Email":Email.text!,"Landline":LandLine.text!,"Mobile":Mobile.text!,"businessOpportunities":Opportunities.text!,"Latitude":latitude.text!,"Longitude":longitute.text!,"Country":country!,"ShopImage1":"","ShopImage":"","Status":"Active", "IsDeleted":"false","TypeOfUser":usertype5555])
            }
            else {
            let strBase64 = data.base64EncodedString(options:.lineLength64Characters)
                
            json(params:["Name":"","CompanyName":companyex.text!,"contactperson":Contact.text!,"Address":addresss.text!,"City":City.text!,"State":State.text!,"Pincode":pincode.text!,"Email":Email.text!,"Landline":LandLine.text!,"Mobile":Mobile.text!,"businessOpportunities":Opportunities.text!,"Latitude":latitude.text!,"Longitude":longitute.text!,"Country":country!,"ShopImage":"","ShopImage1":strBase64,"Status":"Active", "IsDeleted":"false","TypeOfUser":usertype5555])
                
                print(strBase64)
            }
        
        
        }
        else {
            self.activityIndicator.isHidden = true
            self.activityIndicator.stopAnimating()
        displayMyAlertMessage("Fields marked with * are mandatory!")
        
        }
    }
        else {
            displayMyAlertMessage("Please select the user type")
        
        }
        
        
    }

    @IBAction func upload(_ sender: Any) {
        picker.allowsEditing = false
        picker.sourceType = .photoLibrary
        picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
        present(picker, animated: true, completion: nil)
      
    }
    
    @IBAction func cancelbto(_ sender: Any) {
//        _ = self.navigationController?.popViewController(animated: true)
        
//        dismiss(animated: true, completion: nil)
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController,didFinishPickingMediaWithInfo info: [String :Any])
    {
        
        
        if let chosenImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
             //3
            img.image = chosenImage //4
            let qty :CGFloat = 0.5
             data = UIImageJPEGRepresentation(chosenImage,qty) as NSData?
            
//             imagedata = getArrayOfBytesFromImage(imageData: data)
         
            
        } else{
            print("Something went wrong")
        }
        
        
        self.dismiss(animated:true, completion: nil) //5
        
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }

    
    func json (params:[String:Any])
    {
        print(params)
        let session = URLSession.shared
        let url = "http://54.255.163.200/api/distributor/add"
        let request = NSMutableURLRequest(url: NSURL(string: url)! as URL)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        do{
            request.httpBody = try JSONSerialization.data(withJSONObject: params, options: JSONSerialization.WritingOptions())
            let task = session.dataTask(with: request as URLRequest, completionHandler: {(data, response, error) in
                if let response = response {
                    let nsHTTPResponse = response as! HTTPURLResponse
                    let statusCode = nsHTTPResponse.statusCode
                    print ("status code = \(statusCode)")
                }
                if let error = error {
                    print ("\(error)")
                }
                if let data = data {
                    do{
                        let jsonResponse = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions()) as! NSDictionary
                        
                       
                        print(jsonResponse)
                        
                        if let result = jsonResponse["result"] as? String {
                        
                        if result == "Success" {
//                            self.displayMyAlertMessage("Registered Successfully")
                            self.activityIndicator.isHidden = true
                            self.activityIndicator.stopAnimating()
                            
                            let myAlert = UIAlertController(title:"Gates Finder", message:"Registered Successfully", preferredStyle: UIAlertControllerStyle.alert);
                            
                            let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
                                
                                _ = self.navigationController?.popViewController(animated: true)
                                
                            })
                            
                            myAlert.addAction(okAction);
                            
                            self.present(myAlert, animated:true, completion:nil);

                           
                            //
                        }
                        else if result == "AlreadyRegistered"{
                            self.activityIndicator.isHidden = true
                            self.activityIndicator.stopAnimating()
                            self.displayMyAlertMessage("Already Registered User")
                            
                        }
                        else if result == "MobileNotFound" {
                            self.activityIndicator.isHidden = true
                            self.activityIndicator.stopAnimating()
                            self.displayMyAlertMessage("You are not a valid distributor of Gates. Please contact Gates for more details!")
                            
                        }
                        else {
                            self.activityIndicator.isHidden = true
                            self.activityIndicator.stopAnimating()
                            self.displayMyAlertMessage("Adding distributor failed! Please try again later.")
                            print("Something Nothing")
                        }
                        }
                        ///////////
                        //                        let resutl = jsonResponse["result"] as String
                    }catch _ {
                        let erro = String(data: data, encoding: String.Encoding.utf8)
                        print ("OOps not good JSON formatted response\(erro)")
                        self.displayMyAlertMessage("Adding distributor failed! Due to \(erro) Please try again later.")
                        
                        
                        
                    }
                }
            })
            task.resume()
        }catch _ {
            self.activityIndicator.isHidden = true
            self.activityIndicator.stopAnimating()
            print ("Oops something happened buddy")
        }
        
    }
    
   
    
    
    func displayMyAlertMessage(_ userMessage:String)
    {
        self.activityIndicator.isHidden = true
        self.activityIndicator.stopAnimating()
        let myAlert = UIAlertController(title:"Gates Finder", message:userMessage, preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler:nil);
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }
    //
    @IBAction func cancel(_ sender: Any) {
        dismissKeyboard()
        _ = self.navigationController?.popViewController(animated: true)
        
        dismiss(animated: true, completion: nil)
        
    }
    ///// tops buttons
    let screenSize: CGRect = UIScreen.main.bounds
    let btn1 = UIButton(frame: CGRect(x: 0, y: 0, width: 20, height: 15))
    var isclicked:Bool! = true
    var menuclicked = false
    let btn2 = UIButton(type: .custom)
    let customView = UIView()
    let btn3 = UIButton()
    let myView = sildermenu()
    
    
    let signoutUser:UIButton = {
        let screenSize: CGRect = UIScreen.main.bounds
        let button = UIButton()
        button.frame = CGRect(x: screenSize.maxX - 140 , y: 25, width: 140, height: 20)
        let image:UIImage = UIImage(named: "signout")!
        button.imageEdgeInsets = UIEdgeInsets(top: 0,left: 14,bottom: 0,right: 100)
        button.setImage(image, for:.normal)
        button.addTarget(self, action: #selector(userSignOut), for: .touchUpInside)
        
        return button

        
    }()
    
    
    
    
    func userSignOut(){
        
        UserDefaults.standard.set(false,forKey:"distribuUser");
        someTextView2.isHidden = true
        signoutUser.isHidden = true
        let myAlert = UIAlertController(title:"Gates Finder", message:"Signed out successfully", preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
            let vcName = "distributionNetwork"
            let storyboard: UIStoryboard = UIStoryboard (name: "Main", bundle: nil)
            let viewCv = storyboard.instantiateViewController(withIdentifier: vcName)
            self.navigationController?.pushViewController(viewCv, animated: true)
            
        })
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }

    
    let someTextView:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.minX + 60 , y: 25, width: 100, height: 20)
        let usertype = UserDefaults.standard.string(forKey: "name")
        theUserName.text = usertype
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    let someTextView2:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.maxX - 80 , y: 25, width: 80, height: 20)
        theUserName.text = "Sign Out"
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    
    
    let someImageView: UIImageView = {
        let screenSize: CGRect = UIScreen.main.bounds
        let profilepic = UserDefaults.standard.object(forKey: "profileImage")
        let theImageView = UIImageView()
        if profilepic != nil {
            theImageView.image = UIImage(data: profilepic as! Data)
            
        }
        else {
            theImageView.image = UIImage(named:"imagesss")
            
        }
        
        theImageView.frame = CGRect(x: screenSize.minX + 10, y: 16, width: 35, height: 35)
        theImageView.layer.borderWidth = 1.0
        theImageView.layer.masksToBounds = false
        theImageView.layer.borderColor = UIColor.black.cgColor
        theImageView.layer.cornerRadius = theImageView.frame.size.width/2
        theImageView.clipsToBounds = true
        theImageView.translatesAutoresizingMaskIntoConstraints = true //You need to call this property so the image is added to your view
        return theImageView
    }()
    func menubar() {
        let distrubUser = UserDefaults.standard.bool(forKey: "distribuUser")
        
        btn1.setImage(UIImage(named: "NavMenu"), for: .normal)
        btn1.addTarget(self, action: #selector(action), for: .touchUpInside)
        btn2.setImage(UIImage(named: "drowarrow"), for: .normal)
        btn2.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn2.addTarget(self, action: #selector(signout), for: .touchUpInside)
        btn3.setImage(UIImage(named: "left-arrow-key"), for: .normal)
        btn3.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn3.addTarget(self, action: #selector(back), for: .touchUpInside)
        
        
        if distrubUser == true {
            someTextView2.isHidden = false
            signoutUser.isHidden = false
            
        }
        else {
            someTextView2.isHidden = true
            signoutUser.isHidden = true
        }
        let item1 = UIBarButtonItem(customView: btn1)
        let item2 = UIBarButtonItem(customView: btn2)
        let item3 = UIBarButtonItem(customView: btn3)
        self.navigationItem.setRightBarButtonItems([item2,item1], animated: true)
        self.navigationItem.setLeftBarButtonItems([item3], animated: true)
        
        
    }
    func back() {
        _ = self.navigationController?.popViewController(animated: true)
        
        dismiss(animated: true, completion: nil)
        
    }
    
    
    func action(sender:UIButton!) {
        menubaraction()
    }
    
    
    
    func menubaraction() {
        let myviewsize = myView.bounds
        
        
        if (menuclicked){
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            })
            
        }
        else
        {
            self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: self.screenSize.width/2, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: myviewsize.width, height:myviewsize.height)
            })
            
            
            
            
        }
        menuclicked = !menuclicked
        
        view.addSubview(myView)
        
    }
    override func viewDidAppear(_ animated: Bool) {
        
        let myviewsize = myView.bounds
        if (menuclicked){
            
            self.myView.frame = CGRect(x: 0, y: 65, width: 0, height:self.screenSize.height - 65)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            menuclicked = !menuclicked
            
        }
        menubar()
    }
    func signout(){
        
        if isclicked == true {
            isclicked = false
            
            customView.frame = CGRect.init(x: screenSize.minX, y: 64, width: screenSize.width, height: 65)
            customView.backgroundColor = UIColor.white     //give color to the view
            
            self.view.addSubview(customView)
            self.customView.addSubview(someImageView)
            self.customView.addSubview(someTextView)
            self.customView.addSubview(someTextView2)
            self.customView.addSubview(signoutUser)
            
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI))
                
            }
            UIView.animate(withDuration: 0.2, delay: 0.2, options: UIViewAnimationOptions.curveEaseIn, animations: {
                self.customView.alpha = 1.0
                
                
            }, completion: nil)
            
            
            
        }
        else
        {
            isclicked = true
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI * 2))
            }
            
            
            UIView.animate(withDuration: 1.0, animations: {
                self.customView.frame.origin.y = self.view.frame.origin.y - self.view.frame.size.height
                
            })
            
        }
        
        
    }
    
    

}
