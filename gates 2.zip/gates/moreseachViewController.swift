//
//  moreseachViewController.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 06/03/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit
import CoreData

class moreseachViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var showheader: UILabel!
    
    var value1:String!
    var value2:String!
    var value3:String!
    var value4:String!
    var value5:String!
    var value6:String!
    var values7:String!
    var values8:String!
    var values9:String!
    var values10:String!
    var values11:String!
    var values12:String!
     var values13:String!
    var dataGet:String = ""
    var dataGet1:String = ""
    var dataGet2:String = ""
    var dataGet3:String = ""
    var dataGet4:String = ""
    var dataGet5:String = ""
    var dataGet6:String = ""
    var dataGet7:String = ""
    var dataGet8:String = ""
    var dataGet9:String = ""
    var dataGet10:String = ""
    var dataGet11:String = ""
    var dataGet12:String = ""
    var dataGet13:String = ""
    var dataGet14:String = ""
    var dataGet16:String = ""
     var dataGet15:String = ""
    var imageData2:NSData!
   
    
    @IBOutlet var img: UIImageView!
    @IBOutlet var tableView: UITableView!
    @IBOutlet weak var herderimg: UIImageView!
    
    @IBOutlet weak var showlbl: UILabel!
    @IBOutlet weak var mylabel: UILabel!
    
    var titleFoeTable:[String?] = []
    var valueFoeTable:[String?] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        codeshow()
//        showimage()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        tableView.estimatedRowHeight = 100
        tableView.rowHeight = UITableViewAutomaticDimension
        menubar()
        let imageView = UIImageView(frame: self.view.frame)
        let image = UIImage(named: "background-2")!
        imageView.image = image
        self.view.addSubview(imageView)
        self.view.sendSubview(toBack: imageView)
        tableView.backgroundColor = UIColor.clear

        
        herderimg.image = UIImage(named: "title_image.png")
       self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "Back", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
        print("this is the value 1\(value1)")
        
        // travellar
        if value1 == "Passenger Car" {
            
            showlbl.text = "PC & LCV >\(value3!)>\(value4!)>\(value5!)"
            
        }
        else if value1 == "Heavy Commercial"
        {
            
            showlbl.text = "HCV >\(value3!)>\(value4!)>\(value5!)"
            
            
            
        }
        else
        {
            
            showlbl.text = "2 Wheeler >\(value3!)>\(value4!)>\(value5!)"
        }
        
        imageload()
        

        self.title = "More Details"
        
        
        // table info that which in last page
        titleFoeTable = ["Vehicle Make","Vehicle Model","Vehicle Model Code","CC","Year From","Month From","Year Till","Month Till","Part Description","Gates Part Number","Engine Code","Driven Unit 1","Driven Unit 2","Equipment Date From","Equipment Date To","Product Additional Info"]
        valueFoeTable = ["\(dataGet)","\(dataGet1)","\(dataGet2)","\(dataGet3)","\(dataGet4)","\(dataGet5)","\(dataGet6)","\(dataGet7)","\(dataGet8)","\(dataGet9)","\(dataGet10)","\(dataGet11)","\(dataGet12)","\(dataGet13)","\(dataGet14)","\(dataGet16)"]
        
      
        showlbl.numberOfLines = 0
        showlbl.sizeToFit()
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return titleFoeTable.count
    }

    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath ) as! moreseachTableViewCell
        
        cell.tilte.text = titleFoeTable[indexPath.row]
        cell.value.text = valueFoeTable[indexPath.row]
        if indexPath.row % 2 == 0
        {
        cell.backgroundColor = UIColor.darkGray
            cell.tilte.textColor = UIColor.white
            cell.value.textColor = UIColor.white
        }
        else
        {
        cell.backgroundColor = UIColor.lightGray
            cell.tilte.textColor = UIColor.black
            cell.value.textColor = UIColor.black

        }
        
        return cell
    }
    
    
     /// get the data from core data
    func codeshow()  {
        let appdelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appdelegate.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName:"Product")
        let predicate = NSPredicate(format: "segment contains[cd] %@ OR segment contains[cd] %@", value1,value2)
        let predicate1 = NSPredicate(format: "make = %@", value3)
        let predicate2 = NSPredicate(format: "model = %@", value4)
        let predicate3 = NSPredicate(format: "modelcode = %@", value5)
        let predicate4 = NSPredicate(format: "gates_Part_Number = %@", value6)
        let predicate5 = NSPredicate(format: "year_From = %@", values7)
        let predicate6 = NSPredicate(format: "month_From = %@", values8)
        let predicate7 = NSPredicate(format: "year_Till = %@", values9)
        let predicate8 = NSPredicate(format: "month_Till = %@", values10)
        let predicate9 = NSPredicate(format: "enginecode = %@", values11)
        let predicate10 = NSPredicate(format: "stroke = %@", values12)
        let predicate11 = NSPredicate(format: "part_Description = %@", values13)

        let finalpredicate = NSCompoundPredicate(type: NSCompoundPredicate.LogicalType.and, subpredicates: [predicate, predicate1,predicate2,predicate3,predicate4,predicate5,predicate6,predicate7,predicate8,predicate9,predicate10,predicate11])
        request.predicate = finalpredicate
        request.returnsDistinctResults = true
        request.resultType = .dictionaryResultType
        request.propertiesToFetch = ["make","model","modelcode","stroke","year_From","month_From","year_Till","month_Till","part_Description","gates_Part_Number","enginecode","equipment","equipment_2","equipment_Date_From","equipment_Date_To","imageName","productAdditionalInfo"]
        request.returnsObjectsAsFaults = false
        
        do {
            
            let results = try context.fetch(request)
            
            if results.count > 0
            {
                for result in results
                {
                    //
                    if var segment = (result as AnyObject).value(forKey: "make") as? String
                    {
                     segment = segment.trimmingCharacters(in:.whitespaces)
                        dataGet = segment
                        print("this is the segment \(segment)")
                    }
                    if var segment = (result as AnyObject).value(forKey: "model") as? String
                    {
                        segment = segment.trimmingCharacters(in:.whitespaces)
                        dataGet1 = segment
                        
                         print("this is the segment \(segment)")
                    }
                    if var segment = (result as AnyObject).value(forKey: "modelcode") as? String
                    {
                        segment = segment.trimmingCharacters(in:.whitespaces)
                        dataGet2 = segment
                        print("this is the segment \(segment)")
                    }
                    if var segment = (result as AnyObject).value(forKey: "stroke") as? String
                    {
                        segment = segment.trimmingCharacters(in:.whitespaces)
                        dataGet3 = segment
                    print("this is the segment \(segment)")
                    }
                    if var segment = (result as AnyObject).value(forKey: "year_From") as? String
                    {
                        segment = segment.trimmingCharacters(in:.whitespaces)
                        dataGet4 = segment
                         print("this is the segment \(segment)")
                        
                    }
                    if var segment = (result as AnyObject).value(forKey: "month_From") as? String
                    {
                        segment = segment.trimmingCharacters(in:.whitespaces)
                        dataGet5 = segment
                         print("this is the segment \(segment)")
                    }
                    if var segment = (result as AnyObject).value(forKey: "year_Till") as? String
                    {
                        segment = segment.trimmingCharacters(in:.whitespaces)
                        dataGet6 = segment
                       print("this is the segment \(segment)")
                    }
                    if var segment = (result as AnyObject).value(forKey: "month_Till") as? String
                    {
                        segment = segment.trimmingCharacters(in:.whitespaces)
                        dataGet7 = segment
                         print("this is the segment \(segment)")
                    }
                    if var segment = (result as AnyObject).value(forKey: "part_Description") as? String
                    {
                        segment = segment.trimmingCharacters(in:.whitespaces)
                        dataGet8 = segment
                        print(segment)
                        
                    }
                    if var segment = (result as AnyObject).value(forKey: "gates_Part_Number") as? String
                    {
                        segment = segment.trimmingCharacters(in:.whitespaces)
                        dataGet9 = segment
                        print(segment)
                    }
                    if var segment = (result as AnyObject).value(forKey: "enginecode") as? String
                    {
                        segment = segment.trimmingCharacters(in:.whitespaces)
                        dataGet10 = segment
                        print(segment)
                    }
                    if var segment = (result as AnyObject).value(forKey: "equipment") as? String
                    {
                        segment = segment.trimmingCharacters(in:.whitespaces)
                        dataGet11 = segment
                    }
                    if var segment = (result as AnyObject).value(forKey: "equipment_2") as? String
                    {
                        segment = segment.trimmingCharacters(in:.whitespaces)
                        dataGet12 = segment
                        
                    }
                    if var segment = (result as AnyObject).value(forKey: "equipment_Date_From") as? String
                    {
                        segment = segment.trimmingCharacters(in:.whitespaces)
                        dataGet13 = segment
                    }
                    if var segment = (result as AnyObject).value(forKey: "equipment_Date_To") as? String
                    {
                        segment = segment.trimmingCharacters(in:.whitespaces)
                        dataGet14 = segment
                    }
                    
                    if var segment = (result as AnyObject).value(forKey: "imageName") as? String
                    {
                        segment = segment.trimmingCharacters(in:.whitespaces)
                        dataGet15 = segment
                        print(segment)
                    }

                    if var segment = (result as AnyObject).value(forKey: "productAdditionalInfo") as? String
                    {
                        segment = segment.trimmingCharacters(in:.whitespaces)
                        dataGet16 = segment
                        
                    }
                    
                    
                    //
                }
                
            }
            
        }
        catch
        {
            
        }
        
    }
    
  //  get the image from db
    
    func showimage() {
        let appdelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appdelegate.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName:"Image")
        let predicate1 = NSPredicate(format: "imageName = %@", dataGet15)
        request.predicate = predicate1
        request.returnsDistinctResults = true
        request.resultType = .dictionaryResultType
        request.propertiesToFetch = ["imageData"]
        request.returnsObjectsAsFaults = false
        
        do {
            
            let results = try context.fetch(request)
            
            if results.count > 0
            {
                for result in results
                {
                    //
                    if let segment = (result as AnyObject).value(forKey: "imageData") as? NSData
                    {
                        imageData2 = segment
                        
                        print(segment)
                        
                    }
                  
                }
                
            }
            
        }
        catch
        {
            
        }
        
    }
    
    
    ///// tops buttons
    let screenSize: CGRect = UIScreen.main.bounds
    let btn1 = UIButton(frame: CGRect(x: 0, y: 0, width: 20, height: 15))
    var isclicked:Bool! = true
    var menuclicked = false
    let btn2 = UIButton(type: .custom)
    let customView = UIView()
    let btn3 = UIButton()
    let myView = sildermenu()
    
    
    let signoutUser:UIButton = {
        let screenSize: CGRect = UIScreen.main.bounds
        let button = UIButton()
        button.frame = CGRect(x: screenSize.maxX - 140 , y: 25, width: 140, height: 20)
        let image:UIImage = UIImage(named: "signout")!
        button.imageEdgeInsets = UIEdgeInsets(top: 0,left: 14,bottom: 0,right: 100)
        button.setImage(image, for:.normal)
        button.addTarget(self, action: #selector(userSignOut), for: .touchUpInside)
        
        return button

        
    }()
    
    
    
    
    func userSignOut(){
        
        UserDefaults.standard.set(false,forKey:"distribuUser");
        someTextView2.isHidden = true
        signoutUser.isHidden = true
        let myAlert = UIAlertController(title:"Gates Finder", message:"Signed out successfully", preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
            
            
        })
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }

    
    let someTextView:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.minX + 60 , y: 25, width: 100, height: 20)
        let usertype = UserDefaults.standard.string(forKey: "name")
        theUserName.text = usertype
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    let someTextView2:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.maxX - 80 , y: 25, width: 80, height: 20)
        theUserName.text = "Sign Out"
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    
    
    let someImageView: UIImageView = {
        let screenSize: CGRect = UIScreen.main.bounds
        let profilepic = UserDefaults.standard.object(forKey: "profileImage")
        let theImageView = UIImageView()
        if profilepic != nil {
            theImageView.image = UIImage(data: profilepic as! Data)
            
        }
        else {
            theImageView.image = UIImage(named:"imagesss")
            
        }
        
        theImageView.frame = CGRect(x: screenSize.minX + 10, y: 16, width: 35, height: 35)
        theImageView.layer.borderWidth = 1.0
        theImageView.layer.masksToBounds = false
        theImageView.layer.borderColor = UIColor.black.cgColor
        theImageView.layer.cornerRadius = theImageView.frame.size.width/2
        theImageView.clipsToBounds = true
        theImageView.translatesAutoresizingMaskIntoConstraints = true //You need to call this property so the image is added to your view
        return theImageView
    }()
    func menubar() {
        let distrubUser = UserDefaults.standard.bool(forKey: "distribuUser")
        
        btn1.setImage(UIImage(named: "NavMenu"), for: .normal)
        btn1.addTarget(self, action: #selector(action), for: .touchUpInside)
        btn2.setImage(UIImage(named: "drowarrow"), for: .normal)
        btn2.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn2.addTarget(self, action: #selector(signout), for: .touchUpInside)
        btn3.setImage(UIImage(named: "left-arrow-key"), for: .normal)
        btn3.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn3.addTarget(self, action: #selector(back), for: .touchUpInside)
        
        
        if distrubUser == true {
            someTextView2.isHidden = false
            signoutUser.isHidden = false
            
        }
        else {
            someTextView2.isHidden = true
            signoutUser.isHidden = true
        }
        let item1 = UIBarButtonItem(customView: btn1)
        let item2 = UIBarButtonItem(customView: btn2)
        let item3 = UIBarButtonItem(customView: btn3)
        self.navigationItem.setRightBarButtonItems([item2,item1], animated: true)
        self.navigationItem.setLeftBarButtonItems([item3], animated: true)
        
        
        
    }
    func back() {
        _ = self.navigationController?.popViewController(animated: true)
        
        dismiss(animated: true, completion: nil)
        
    }
    
    
    func action(sender:UIButton!) {
        menubaraction()
    }
    
    
    
    func menubaraction() {
        let myviewsize = myView.bounds
        
        
        if (menuclicked){
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            })
            
        }
        else
        {
            self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: self.screenSize.width/2, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: myviewsize.width, height:myviewsize.height)
            })
            
            
            
            
        }
        menuclicked = !menuclicked
        view.addSubview(myView)
        
        
    }
    override func viewDidAppear(_ animated: Bool) {
        
        let myviewsize = myView.bounds
        if (menuclicked){
            
            self.myView.frame = CGRect(x: 0, y: 65, width: 0, height:self.screenSize.height - 65)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            menuclicked = !menuclicked
            
        }
        menubar()
    }
    func signout(){
        
        if isclicked == true {
            isclicked = false
            
            customView.frame = CGRect.init(x: screenSize.minX, y: 64, width: screenSize.width, height: 65)
            customView.backgroundColor = UIColor.white     //give color to the view
            
            self.view.addSubview(customView)
            self.customView.addSubview(someImageView)
            self.customView.addSubview(someTextView)
            self.customView.addSubview(someTextView2)
            self.customView.addSubview(signoutUser)
            
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI))
                
            }
            UIView.animate(withDuration: 0.2, delay: 0.2, options: UIViewAnimationOptions.curveEaseIn, animations: {
                self.customView.alpha = 1.0
                
                
            }, completion: nil)
            
            
            
        }
        else
        {
            isclicked = true
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI * 2))
            }
            
            
            UIView.animate(withDuration: 1.0, animations: {
                self.customView.frame.origin.y = self.view.frame.origin.y - self.view.frame.size.height
                
            })
            
        }
        
        
    }
    
    func imageload() {
    
        
        if dataGet15.characters.count >= 4
        {
            if currentReachabilityStatus == .notReachable {
                self.img.image = UIImage(named:"nointernet-1")
                
            }
            else
            {
                
                let trimmedString = "http://54.255.163.200/ImageUpload/\(dataGet15).jpg"
                print(trimmedString)
                let catPictureURL = URL(string: trimmedString)!
                let session = URLSession(configuration: .default)
                let downloadPicTask = session.dataTask(with: catPictureURL) { (data, response, error) in
                    // The download has finished.
                    if let e = error {
                        print("Error downloading picture: \(e)")
                    } else {
                        // No errors found.
                        // It would be weird if we didn't have a response, so check for that too.
                        if (response as? HTTPURLResponse) != nil {
                            
                            if ((response as? HTTPURLResponse)?.statusCode)! == 200 {
                                
                                if let imageData = data {
                                    // Finally convert that Data into an image and do what you wish with it.
                                    self.img.image = UIImage(data: imageData)
                                    self.mylabel.text = ""
                                    
                                }
                                else {
                                    self.img.image = UIImage(named:"no_image")
                                }
                                // Do something with your image.
                            } else {
                                print("Couldn't get image: Image is nil")
                                self.img.image = UIImage(named:"no_image")
                            }
                        } else {
                            print("Couldn't get response code for some reason")
                            self.img.image = UIImage(named:"no_image")
                        }
                    }
                }
                
                downloadPicTask.resume()
                
                
                
            }
            
        }
        else
        {
            //        img.image = UIImage(data: imageData2 as Data)
            
            img.image = UIImage(named:"no_image")
            
        }
        
    
    
    
    
    }
    

}
