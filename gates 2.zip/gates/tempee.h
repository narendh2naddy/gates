//
//  tempee.h
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 03/03/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface tempee : NSObject

@end
