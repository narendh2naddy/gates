//
//  NotificationTableViewCell.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 29/03/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit

class NotificationTableViewCell: UITableViewCell {
    
    
    @IBOutlet var namelbl: UILabel!
    
    @IBOutlet weak var deslbl: UITextView!
    
    @IBOutlet weak var link: UILabel!

    @IBOutlet weak var linkaction: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
