//
//  WhatsNewNewPageViewController.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 09/09/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit

class WhatsNewNewPageViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {

    @IBOutlet weak var img: UIImageView!
    @IBOutlet weak var collectionView: UICollectionView!
    let activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.whiteLarge)

    var data:[String] = []
    var data1:[String] = []
    var data2:[String] = []
    var data3:[String] = []
    var data4:[String] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        img.image = UIImage(named: "title_image.png")
        
        activityIndicator.center = CGPoint(x: view.bounds.size.width/2, y: view.bounds.size.height/2)
        activityIndicator.color = UIColor.red
        view.addSubview(activityIndicator)
        
        activityIndicator.isHidden = false
        activityIndicator.startAnimating()
        
        self.title = "New Products"
        let background = UIImage(named: "background-2")
        
        var imageView : UIImageView!
        imageView = UIImageView(frame: view.bounds)
        imageView.contentMode =  UIViewContentMode.scaleAspectFill
        imageView.clipsToBounds = true
        imageView.image = background
        imageView.center = view.center
        postdata()
        self.collectionView?.backgroundView = imageView
        
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        
        let myviewsize = myView.bounds
        if (menuclicked){
            
            self.myView.frame = CGRect(x: 0, y: 65, width: 0, height:self.screenSize.height - 65)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            menuclicked = !menuclicked
            
        }
        menubar()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
//////
    
    
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//        let width = UIScreen.main.bounds.width
//        return CGSize(width: (width - 10)/2, height: (width - 10)/2) // width & height are the same to make a square cell
//    }
    
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return data.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:"cell", for: indexPath) as! whatsnewnewpagecellCollectionViewCell
//        cell.imageView.image =  UIImage(named: image[indexPath.row])
        cell.labeltoshow.text = data3[indexPath.row]
        
        cell.productName.text = data2[indexPath.row]
        cell.moreDetalis.tag = indexPath.row
        
        cell.moreDetalis.addTarget(self, action:#selector(moreinfosss), for: .touchUpInside)
        cell.downloadPdf.tag = indexPath.row
        
        cell.downloadPdf.addTarget(self, action:#selector(moreinfossss), for: .touchUpInside)
        
        cell.moreDetalis.layer.cornerRadius = 5
        cell.downloadPdf.layer.cornerRadius = 5
        

        
        if data1[indexPath.row] == "" {
        
        
        }
        else {
        let urlchange = data1[indexPath.row].replacingOccurrences(of: " ", with: "%20")
        let catPictureURL = URL(string:urlchange)!
        let session = URLSession(configuration: .default)
        let downloadPicTask = session.dataTask(with: catPictureURL) { (data, response, error) in
            // The download has finished.
            if let e = error {
                print("Error downloading picture: \(e)")
            } else {
                // No errors found.
                // It would be weird if we didn't have a response, so check for that too.
                if (response as? HTTPURLResponse) != nil {
                    if let imageData = data {
                        // Finally convert that Data into an image and do what you wish with it.
                        cell.whatsImage.image = UIImage(data: imageData)
                        print(imageData)
                        
                        // Do something with your image.
                    } else {
                        print("Couldn't get image: Image is nil")
                    }
                } else {
                    print("Couldn't get response code for some reason")
                }
            }
        }
        
        downloadPicTask.resume()
        
        }
         return cell
    }
    
    func moreinfosss(_ sender : UIButton){
        
        if data[sender.tag] == "" {
        
            self.displayMyAlertMessage("No Link Found!!!")
        
        }
        else {
        
            if data[sender.tag].contains("http"){
                 let urlchange = data[sender.tag].replacingOccurrences(of: " ", with: "%20")
            
                if let url = NSURL(string:urlchange){ UIApplication.shared.open(url as URL, options: [:], completionHandler: nil) }
            }
            else {
            let urlchange = data[sender.tag].replacingOccurrences(of: " ", with: "%20")
            if let url = NSURL(string:"https://\(urlchange)"){ UIApplication.shared.open(url as URL, options: [:], completionHandler: nil) }
            }

        }
    }
    
    func moreinfossss(_ sender : UIButton){
        
        if data4[sender.tag] == "" {
            
            self.displayMyAlertMessage("No PDF Found!!!")
            
        }
        else {
            
             let urlchange = data4[sender.tag].replacingOccurrences(of: " ", with: "%20")
            if let url = NSURL(string:urlchange){ UIApplication.shared.open(url as URL, options: [:], completionHandler: nil) }
            
        }
    }

    
//    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//       
//        if let url = NSURL(string:"http://www.gatesunitta.com/en/passenger-cars-light-trucks"){ UIApplication.shared.open(url as URL, options: [:], completionHandler: nil) }
//
//    }
    
    
    var country = UserDefaults.standard.string(forKey: "country")
    
    func postdata() {
        let urlString = "http://54.255.163.200/api/common/GetWhatsnewProducts?Country=\(country!)"
        
        let url = URL(string: urlString)
        print(url!)
        URLSession.shared.dataTask(with:url!) { (data, response, error) in
            if error != nil {
                print(error!)
            } else {
                do {
                    let parsedData = try JSONSerialization.jsonObject(with: data!, options: []) as! NSDictionary
                    let result = parsedData["result"] as! String
                    print(result)
                    if result == "Success" {
                        let data = parsedData["data"] as! NSArray
                        print(data)
                        if data.count == 0 { self.displayMyAlertMessage("No Data Found!!!")       }
                        else {
                            for i in 0..<data.count {
                                
                                let subb = data[i] as! NSDictionary
                                
                                if subb["Link"] is NSNull {self.data.append(("" as AnyObject) as! String)} else {self.data.append((subb["Link"] as! String as AnyObject) as! String)}
                                if subb["Image"] is NSNull {self.data1.append(("" as AnyObject) as! String)} else {self.data1.append((subb["Image"] as! String as AnyObject) as! String)}
                                if subb["ProductName"] is NSNull {self.data2.append(("" as AnyObject) as! String)} else {self.data2.append((subb["ProductName"] as! String as AnyObject) as! String)}
                                if subb["ProductDescription"] is NSNull {self.data3.append(("" as AnyObject) as! String)} else {self.data3.append((subb["ProductDescription"] as! String as AnyObject) as! String)}
                                if subb["PDFUpload"] is NSNull {self.data4.append(("" as AnyObject) as! String)} else {self.data4.append((subb["PDFUpload"] as! String as AnyObject) as! String)}

                                
//                                self.data.append(subb["Link"] as! String)
//                                self.data1.append(subb["Image"] as! String)
//                                self.data2.append(subb["ProductName"] as! String)
//                                self.data3.append(subb["ProductDescription"] as! String)
//                                self.data4.append(subb["PDFUpload"] as! String)
//                                                               
                                
                                
                            }
                        }
                    }
                    
                }
                catch let error as NSError {
                    print(error)
                }
            }
            self.reload()
            
            }.resume()
        
        reload()
        
        DispatchQueue.main.async(execute: {
            self.activityIndicator.isHidden = true
            self.activityIndicator.stopAnimating()
        })
        
    }
    /////
    
    
    
    func displayMyAlertMessage(_ userMessage:String)
    {
        
        let myAlert = UIAlertController(title:"Gates Finder", message:userMessage, preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
            
//            _ = self.navigationController?.popViewController(animated: true)
            
        })
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }
    
    
    
    func reload() {
        print(data4)
        DispatchQueue.main.async{
            self.collectionView.reloadData()
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    ///// tops buttons
    let screenSize: CGRect = UIScreen.main.bounds
    let btn1 = UIButton(frame: CGRect(x: 0, y: 0, width: 20, height: 15))
    var isclicked:Bool! = true
    var menuclicked = false
    let btn2 = UIButton(type: .custom)
    let customView = UIView()
    let btn3 = UIButton()
    let myView = sildermenu()
    
    
    let signoutUser:UIButton = {
        let screenSize: CGRect = UIScreen.main.bounds
        let button = UIButton()
        button.frame = CGRect(x: screenSize.maxX - 140 , y: 25, width: 140, height: 20)
        let image:UIImage = UIImage(named: "signout")!
        button.imageEdgeInsets = UIEdgeInsets(top: 0,left: 14,bottom: 0,right: 100)
        button.setImage(image, for:.normal)
        button.addTarget(self, action: #selector(userSignOut), for: .touchUpInside)
        
        return button
        
        
    }()
    
    
    
    
    func userSignOut(){
        
        UserDefaults.standard.set(false,forKey:"distribuUser");
        someTextView2.isHidden = true
        signoutUser.isHidden = true
        let myAlert = UIAlertController(title:"Gates Finder", message:"Signed out successfully", preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
            
            
        })
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }
    
    let someTextView:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.minX + 60 , y: 25, width: 100, height: 20)
        let usertype = UserDefaults.standard.string(forKey: "name")
        theUserName.text = usertype
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    let someTextView2:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.maxX - 80 , y: 25, width: 80, height: 20)
        theUserName.text = "Sign Out"
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    
    
    let someImageView: UIImageView = {
        let screenSize: CGRect = UIScreen.main.bounds
        let profilepic = UserDefaults.standard.object(forKey: "profileImage")
        let theImageView = UIImageView()
        if profilepic != nil {
            theImageView.image = UIImage(data: profilepic as! Data)
            
        }
        else {
            theImageView.image = UIImage(named:"imagesss")
            
        }
        
        theImageView.frame = CGRect(x: screenSize.minX + 10, y: 16, width: 35, height: 35)
        theImageView.layer.borderWidth = 1.0
        theImageView.layer.masksToBounds = false
        theImageView.layer.borderColor = UIColor.black.cgColor
        theImageView.layer.cornerRadius = theImageView.frame.size.width/2
        theImageView.clipsToBounds = true
        theImageView.translatesAutoresizingMaskIntoConstraints = true //You need to call this property so the image is added to your view
        return theImageView
    }()
    func menubar() {
        let distrubUser = UserDefaults.standard.bool(forKey: "distribuUser")
        
        btn1.setImage(UIImage(named: "NavMenu"), for: .normal)
        btn1.addTarget(self, action: #selector(action), for: .touchUpInside)
        btn2.setImage(UIImage(named: "drowarrow"), for: .normal)
        btn2.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn2.addTarget(self, action: #selector(signout), for: .touchUpInside)
        btn3.setImage(UIImage(named: "left-arrow-key"), for: .normal)
        btn3.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn3.addTarget(self, action: #selector(back), for: .touchUpInside)
        
        
        if distrubUser == true {
            someTextView2.isHidden = false
            signoutUser.isHidden = false
            
        }
        else {
            someTextView2.isHidden = true
            signoutUser.isHidden = true
        }
        let item1 = UIBarButtonItem(customView: btn1)
        let item2 = UIBarButtonItem(customView: btn2)
        let item3 = UIBarButtonItem(customView: btn3)
        self.navigationItem.setRightBarButtonItems([item2,item1], animated: true)
        self.navigationItem.setLeftBarButtonItems([item3], animated: true)
        
        
        
    }
    func back() {
        _ = self.navigationController?.popViewController(animated: true)
        
        dismiss(animated: true, completion: nil)
        
    }
    
    
    func action(sender:UIButton!) {
        menubaraction()
    }
    
    func menubaraction() {
        let myviewsize = myView.bounds
        
        
        if (menuclicked){
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            })
            
        }
        else
        {
            self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: self.screenSize.width/2, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: myviewsize.width, height:myviewsize.height)
            })
            
            
            
            
        }
        menuclicked = !menuclicked
        
        view.addSubview(myView)
        
    }
    
    func signout(){
        
        if isclicked == true {
            isclicked = false
            
            customView.frame = CGRect.init(x: screenSize.minX, y: 64, width: screenSize.width, height: 65)
            customView.backgroundColor = UIColor.white     //give color to the view
            
            self.view.addSubview(customView)
            self.customView.addSubview(someImageView)
            self.customView.addSubview(someTextView)
            self.customView.addSubview(someTextView2)
            self.customView.addSubview(signoutUser)
            
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI))
                
            }
            UIView.animate(withDuration: 0.2, delay: 0.2, options: UIViewAnimationOptions.curveEaseIn, animations: {
                self.customView.alpha = 1.0
                
                
            }, completion: nil)
            
            
            
        }
        else
        {
            isclicked = true
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI * 2))
            }
            
            
            UIView.animate(withDuration: 1.0, animations: {
                self.customView.frame.origin.y = self.view.frame.origin.y - self.view.frame.size.height
                
            })
            
        }
        
        
    }
    ////

}
