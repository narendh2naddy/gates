//
//  moreseachTableViewCell.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 24/06/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit

class moreseachTableViewCell: UITableViewCell {

    @IBOutlet weak var tilte: UILabel!
    @IBOutlet weak var value: UILabel!
    @IBOutlet weak var value2: UILabel!
    @IBOutlet weak var tilte2: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
