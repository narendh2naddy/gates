//
//  AnotherViewController.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 27/02/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit


class AnotherViewController: UIViewController, UITableViewDelegate, UITableViewDataSource,UISearchResultsUpdating {
    @IBOutlet var tableView: UITableView!

    var catagi:String!
    var trainvd:[String]! = []
    var strURLToOpen:[String]! = []
    var imgdata:[String]! = []
    var filteredData:[String] = []
    var filteredVideo:[String] = []
    var resultSearchController:UISearchController!

    @IBOutlet weak var img: UIImageView!
    
    
    override func viewDidLoad() {
        img.image = UIImage(named: "title_image.png")
        menubar()
        let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
        backgroundImage.image = UIImage(named: "background-2")
        backgroundImage.contentMode =  UIViewContentMode.scaleAspectFill
        self.view.insertSubview(backgroundImage, at: 0)
        
        let label = UILabel(frame: CGRect(x:0, y:0, width:400, height:50))
        label.backgroundColor = UIColor.clear
        label.numberOfLines = 2
        label.font = UIFont(name:"Geogrotesque-Regular", size:20)!
        label.textAlignment = .center
        label.textColor = UIColor.white
        label.text = catagi
        self.navigationItem.titleView = label
        
//        self.title = "Training Video"
        super.viewDidLoad()
        self.tableView.delegate = self
        self.tableView.dataSource = self
        // Do any additional setup after loading the view.
        postdata()
        
        resultSearchController = UISearchController(searchResultsController: nil)
        resultSearchController.searchResultsUpdater = self
        
        resultSearchController.hidesNavigationBarDuringPresentation = false
        
        resultSearchController.dimsBackgroundDuringPresentation = false
        
        resultSearchController.searchBar.searchBarStyle = UISearchBarStyle.prominent
        
        resultSearchController.searchBar.sizeToFit()
        
        self.tableView.tableHeaderView = resultSearchController.searchBar
        
        
        


    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: UITableView
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if resultSearchController.isActive {
            return filteredData.count
        }
        else {
            return trainvd.count
        }

    }
    
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath ) as! traingview2TableViewCell
        
        var urlforimag = ""
        if resultSearchController.isActive {
            cell.label.text = filteredData[indexPath.row]
            ///
            let videourl = filteredVideo[indexPath.row].components(separatedBy: "++")
            if videourl[1].contains("=") {
                let trimmedString = videourl[1].components(separatedBy: "=")
                let stingconvert = trimmedString[1].components(separatedBy: "&")
                print(stingconvert[0])
                urlforimag = "http://img.youtube.com/vi/\(stingconvert[0])/0.jpg"        }
            else {
                let trimmedString = videourl[1].components(separatedBy: "be/")
                urlforimag = "http://img.youtube.com/vi/\(trimmedString[1])/0.jpg"
            
            }
            let catPictureURL = URL(string: urlforimag)!
            let session = URLSession(configuration: .default)
            let downloadPicTask = session.dataTask(with: catPictureURL) { (data, response, error) in
                // The download has finished.
                if let e = error {
                    print("Error downloading picture: \(e)")
                } else {
                    // No errors found.
                    // It would be weird if we didn't have a response, so check for that too.
                    if (response as? HTTPURLResponse) != nil {
                        if let imageData = data {
                            // Finally convert that Data into an image and do what you wish with it.
                           cell.imageViewCell.image = UIImage(data: imageData)
                            
                            // Do something with your image.
                        } else {
                            print("Couldn't get image: Image is nil")
                        }
                    } else {
                        print("Couldn't get response code for some reason")
                    }
                }
            }
            
            downloadPicTask.resume()
        
//
        }
        else {
            cell.label.text = trainvd[indexPath.row]
            print(trainvd[indexPath.row])
            let videourl = strURLToOpen[indexPath.row].components(separatedBy: "++")
            if videourl[1].contains("=") {
                let trimmedString = videourl[1].components(separatedBy: "=")
                let stingconvert = trimmedString[1].components(separatedBy: "&")
                urlforimag = "http://img.youtube.com/vi/\(stingconvert[0])/0.jpg"
            }
            else if videourl[1].contains("be"){
                let trimmedString = videourl[1].components(separatedBy: "be/")
                urlforimag = "http://img.youtube.com/vi/\(trimmedString[1])/0.jpg"
                
            }
            
            else {
            urlforimag = "http://img.youtube.com/vi/_T1glue-6oo/0.jpg"
            }
            let catPictureURL = URL(string: urlforimag)!
            let session = URLSession(configuration: .default)
            let downloadPicTask = session.dataTask(with: catPictureURL) { (data, response, error) in
                // The download has finished.
                if let e = error {
                    print("Error downloading picture: \(e)")
                } else {
                    // No errors found.
                    // It would be weird if we didn't have a response, so check for that too.
                    if (response as? HTTPURLResponse) != nil {
                        if let imageData = data {
                            // Finally convert that Data into an image and do what you wish with it.
                            cell.imageViewCell.image = UIImage(data: imageData)
                            
                            // Do something with your image.
                        } else {
                            print("Couldn't get image: Image is nil")
                        }
                    } else {
                        print("Couldn't get response code for some reason")
                    }
                }
            }
            
            downloadPicTask.resume()
        
            
            ///
        }
        
         cell.backgroundColor = UIColor.clear
        let backgroundView = UIView()
        backgroundView.backgroundColor = UIColor.darkGray
        cell.selectedBackgroundView = backgroundView

        return cell
        
    }
    
    let webView = UIWebView()
    var webViewIsActive:Bool = false
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        if let url = NSURL(string:strURLToOpen[indexPath.row]){ UIApplication.shared.open(url as URL, options: [:], completionHandler: nil) }
        let screenSize = UIScreen.main.bounds
        webView.frame = CGRect(x:0,y:120,width:screenSize.width,height:screenSize.height-120)
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.shouldRotate = true
        
        if resultSearchController.isActive {
            webView.allowsInlineMediaPlayback = true
            
                        let videourl = filteredVideo[indexPath.row].components(separatedBy: "++")
                        let url = videourl[1].replacingOccurrences(of: "watch?v=", with: "embed/")
            
                        webView.loadHTMLString("<iframe width=\"\(webView.frame.width)\" height=\"\(webView.frame.height)\" src=\"\(url)?&playsinline=0&modestbranding=1&showinfo=0&fs=1&rel=0\" frameborder=\"0\" allowfullscreen></iframe>", baseURL: nil)
                        
            
            
        }
        else
        {
            
                webView.allowsInlineMediaPlayback = true
            
                        let videourl = strURLToOpen[indexPath.row].components(separatedBy: "++")
                        let url = videourl[1].replacingOccurrences(of: "watch?v=", with: "embed/")
            
            
            webView.loadHTMLString("<iframe width=\"\(webView.frame.width)\" height=\"\(webView.frame.height)\" src=\"\(url)?&playsinline=0&modestbranding=1&showinfo=0&fs=1&rel=0\" frameborder=\"0\" allowfullscreen></iframe>", baseURL: nil)

        
        }
        webViewIsActive = true
        view.addSubview(webView)
       
        
    }

    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if UIDevice.current.orientation.isLandscape {
 
            webView.frame = CGRect(x:0,y:120,width:screenSize.height,height:screenSize.width)
        }
        else
        {
        
            webView.frame = CGRect(x:0,y:120,width:screenSize.width,height:screenSize.height-120)
        }
    }
    
    
    func updateSearchResults(for searchController: UISearchController) {
        
        if (searchController.searchBar.text?.characters.count)! > 0 {
            
            // 1
            filteredData.removeAll(keepingCapacity: false)
            filteredVideo.removeAll(keepingCapacity: false)
            // 2
            let searchPredicate = NSPredicate(format: "SELF CONTAINS[c] %@", searchController.searchBar.text!)
            // 3
            let array = (trainvd as NSArray).filtered(using: searchPredicate)
            let array2 = (strURLToOpen as NSArray).filtered(using: searchPredicate)
            // 4
            
            filteredData = array as! [String]
            filteredVideo = array2 as![String]
            // 5
            tableView.reloadData()
            
        }
        else {
            
            filteredData.removeAll(keepingCapacity: false)
            filteredVideo.removeAll(keepingCapacity: false)
            filteredData = trainvd
            filteredVideo = strURLToOpen
            tableView.reloadData()
            
        }
        
        
    }
    
    func postdata() {
        let trimmedString = catagi.replacingOccurrences(of: " ", with: "%20")
        var usertype = UserDefaults.standard.string(forKey: "usertype")
        let country = UserDefaults.standard.string(forKey: "country")
        if usertype == "Gates Employee"
        {
            usertype = "GatesEmployee"
        }
        
        let urlString = "http://54.255.163.200/api/common/GetVideos/?UserType=\(usertype!)&Country=\(country!)&Category=\(trimmedString)"
        let urlchange = urlString.replacingOccurrences(of: " ", with: "%20")
        let url = URL(string: urlchange)
        URLSession.shared.dataTask(with:url!) { (data, response, error) in
            if error != nil {
                print(error!)
            } else {
                do {
                    let parsedData = try JSONSerialization.jsonObject(with: data!, options: []) as! NSArray
                  
                    if parsedData.count == 0 {
                        
                        let myAlert = UIAlertController(title:"Gates Finder", message:"No videos found!", preferredStyle: UIAlertControllerStyle.alert);
                        
                        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
                            
                            _ = self.navigationController?.popViewController(animated: true)
                            
                        })
                        
                        myAlert.addAction(okAction);
                        
                        self.present(myAlert, animated:true, completion:nil);

                        
                    
                    }
                    else {
                         for i in 0..<parsedData.count {
                            
                             let Product = parsedData[i] as! NSDictionary
                            print(parsedData)
                            
                            let notification = Product["Videoname"] as! String
                            let description = "\(Product["Videoname"]!)++\(Product["videoURL"]!)"
                            print(description)
                            let url = Product["ProductURL"] as! String
                            print(url)
                            self.trainvd.append(notification)
                            self.strURLToOpen.append(description)
                            self.imgdata.append(url)
                            
                        }
                    
                    }
                    
                } catch let error as NSError {
                    print(error)
                }
            }
            self.reload()
            
            }.resume()
        
        reload()
    }
    
    func reload() {
        trainvd.sort { $0.compare($1, options: .numeric) == .orderedAscending }
        strURLToOpen.sort { $0.compare($1, options: .numeric) == .orderedAscending }
        
        DispatchQueue.main.async{
            self.tableView.reloadData()
        }
    }
    func displayMyAlertMessage(_ userMessage:String)
    {
        
        let myAlert = UIAlertController(title:"Gates Finder", message:userMessage, preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler:nil);
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }
    
    
    ///// tops buttons
    let screenSize: CGRect = UIScreen.main.bounds
    let btn1 = UIButton(frame: CGRect(x: 0, y: 0, width: 20, height: 15))
    var isclicked:Bool! = true
    var menuclicked = false
    let btn2 = UIButton(type: .custom)
    let customView = UIView()
    let btn3 = UIButton()
    let myView = sildermenu()
    
    
    let signoutUser:UIButton = {
        let screenSize: CGRect = UIScreen.main.bounds
        let button = UIButton()
        button.frame = CGRect(x: screenSize.maxX - 140 , y: 25, width: 140, height: 20)
        let image:UIImage = UIImage(named: "signout")!
        button.imageEdgeInsets = UIEdgeInsets(top: 0,left: 14,bottom: 0,right: 100)
        button.setImage(image, for:.normal)
        button.addTarget(self, action: #selector(userSignOut), for: .touchUpInside)
        
        return button

        
    }()
    
    
    
    
    func userSignOut(){
        
        UserDefaults.standard.set(false,forKey:"distribuUser");
        someTextView2.isHidden = true
        signoutUser.isHidden = true
        let myAlert = UIAlertController(title:"Gates Finder", message:"Signed out successfully", preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
            let vcName = "VideosCategory"
            let storyboard: UIStoryboard = UIStoryboard (name: "Main", bundle: nil)
            let viewCv = storyboard.instantiateViewController(withIdentifier: vcName)
            self.navigationController?.pushViewController(viewCv, animated: true)
            
        })
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }
    
    let someTextView:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.minX + 60 , y: 25, width: 100, height: 20)
        let usertype = UserDefaults.standard.string(forKey: "name")
        theUserName.text = usertype
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    let someTextView2:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.maxX - 80 , y: 25, width: 80, height: 20)
        theUserName.text = "Sign Out"
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    
    
    let someImageView: UIImageView = {
        let screenSize: CGRect = UIScreen.main.bounds
        let profilepic = UserDefaults.standard.object(forKey: "profileImage")
        let theImageView = UIImageView()
        if profilepic != nil {
            theImageView.image = UIImage(data: profilepic as! Data)
            
        }
        else {
            theImageView.image = UIImage(named:"imagesss")
            
        }
        
        theImageView.frame = CGRect(x: screenSize.minX + 10, y: 16, width: 35, height: 35)
        theImageView.layer.borderWidth = 1.0
        theImageView.layer.masksToBounds = false
        theImageView.layer.borderColor = UIColor.black.cgColor
        theImageView.layer.cornerRadius = theImageView.frame.size.width/2
        theImageView.clipsToBounds = true
        theImageView.translatesAutoresizingMaskIntoConstraints = true //You need to call this property so the image is added to your view
        return theImageView
    }()
    func menubar() {
        let distrubUser = UserDefaults.standard.bool(forKey: "distribuUser")
        
        btn1.setImage(UIImage(named: "NavMenu"), for: .normal)
        btn1.addTarget(self, action: #selector(action), for: .touchUpInside)
        btn2.setImage(UIImage(named: "drowarrow"), for: .normal)
        btn2.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn2.addTarget(self, action: #selector(signout), for: .touchUpInside)
        btn3.setImage(UIImage(named: "left-arrow-key"), for: .normal)
        btn3.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn3.addTarget(self, action: #selector(back), for: .touchUpInside)
        
        
        if distrubUser == true {
            someTextView2.isHidden = false
            signoutUser.isHidden = false
            
        }
        else {
            someTextView2.isHidden = true
            signoutUser.isHidden = true
        }
        let item1 = UIBarButtonItem(customView: btn1)
        let item2 = UIBarButtonItem(customView: btn2)
        let item3 = UIBarButtonItem(customView: btn3)
        self.navigationItem.setRightBarButtonItems([item2,item1], animated: true)
        self.navigationItem.setLeftBarButtonItems([item3], animated: true)
        
        
        
    }
    func back() {
        
        
        if webViewIsActive {
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            appDelegate.shouldRotate = false
         webView.removeFromSuperview()
        webViewIsActive = false
        }
        else {
        resultSearchController.isActive = false

        _ = self.navigationController?.popViewController(animated: true)
        
        dismiss(animated: true, completion: nil)
        }
        
    }
    
    
    func action(sender:UIButton!) {
        menubaraction()
    }
    
    
    
    func menubaraction() {
        let myviewsize = myView.bounds
        
        
        if (menuclicked){
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            })
            
        }
        else
        {
            self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: self.screenSize.width/2, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: myviewsize.width, height:myviewsize.height)
            })
            
            
            
            
        }
        menuclicked = !menuclicked
        view.addSubview(myView)
        
        
    }
    override func viewDidAppear(_ animated: Bool) {
        
        let myviewsize = myView.bounds
        if (menuclicked){
            
            self.myView.frame = CGRect(x: 0, y: 65, width: 0, height:self.screenSize.height - 65)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            menuclicked = !menuclicked
            
        }
        menubar()
    }
    func signout(){
        
        if isclicked == true {
            isclicked = false
            
            customView.frame = CGRect.init(x: screenSize.minX, y: 64, width: screenSize.width, height: 65)
            customView.backgroundColor = UIColor.white     //give color to the view
            
            self.view.addSubview(customView)
            self.customView.addSubview(someImageView)
            self.customView.addSubview(someTextView)
            self.customView.addSubview(someTextView2)
            self.customView.addSubview(signoutUser)
            
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI))
                
            }
            UIView.animate(withDuration: 0.2, delay: 0.2, options: UIViewAnimationOptions.curveEaseIn, animations: {
                self.customView.alpha = 1.0
                
                
            }, completion: nil)
            
            
            
        }
        else
        {
            isclicked = true
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI * 2))
            }
            
            
            UIView.animate(withDuration: 1.0, animations: {
                self.customView.frame.origin.y = self.view.frame.origin.y - self.view.frame.size.height
                
            })
            
        }
        
        
    }

}

