//
//  productViewController.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 27/02/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit
import CoreData

class productViewController: UIViewController,UITextFieldDelegate {
   
    @IBOutlet var imageHeader: UIImageView!
    
    @IBOutlet weak var partnumber: SearchTextField!
    
     @IBOutlet var labletest: UILabel!
    var filterarray:[String]! = []
   
    
    var value:String!
    let ibutton = UIButton(frame: CGRect(x: 0, y: 0, width: 15, height: 15))
    
    override func viewDidLoad() {
        super.viewDidLoad()
        codeshow()
        let background = UIImage(named: "background-2")
        var imageView : UIImageView!
         self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "Back", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
        imageView = UIImageView(frame: view.bounds)
        imageView.contentMode =  UIViewContentMode.scaleAspectFill
        imageView.clipsToBounds = true
        imageView.image = background
        imageView.center = view.center
        view.addSubview(imageView)
        self.view.sendSubview(toBack: imageView)
        labletest.text = "Vehicle Segment"

        imageHeader.image = UIImage(named: "title_image.png")
        
        self.title = "Product Search"
        menubar()
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(trainingVideoLoginPageViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
        self.partnumber.delegate = self
     
        // label btu image
        ibutton.setImage(UIImage(named: "information.png"), for: .normal)
        ibutton.imageEdgeInsets = UIEdgeInsetsMake(0, 10, 0, -10)
        partnumber.leftViewMode = UITextFieldViewMode.always
        partnumber.leftView = ibutton
        ibutton.addTarget(self, action: #selector(self.info), for: .touchUpInside)
        filterarray = Array(Set(filterarray))
        
       partnumber.filterStrings(filterarray)
        
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
        
    }
    
    
    func info() {
        
        let myAlert = UIAlertController(title:"Gates Finder", message:"You can search with multiple keywords separated by comma (,)\nExample: Audi, BMW (or)\nYou can search for multiple keywords with concatenate (+)\nExample: Honda + City\nNote: Concatenate search will not work with values from different Make or Model or Part number. Example: Honda + Accent will not work as Accent belongs to Hyundai.", preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler:nil);
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
        
    }
    // send next page with car
    @IBAction func car(_ sender: Any) {
        performSegue(withIdentifier: "seachView", sender: "Passenger Car")
       
    }
    
    @IBAction func truck(_ sender: Any) {
        performSegue(withIdentifier: "seachView", sender: "Heavy Commercial")
    }
    @IBAction func wheel(_ sender: Any) {
        performSegue(withIdentifier: "seachView", sender: "2 Wheeler")
        
    }
   
    // oesearch bar
    @IBAction func oesearch(_ sender: Any) {
        
        let viewCv = storyboard?.instantiateViewController(withIdentifier: "textsech")
        self.navigationController?.pushViewController(viewCv!, animated: true)
    }

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "Partnoview" {
            let partnumber = segue.destination as! PartNumberSearchViewController
            partnumber.partNumber = sender as! String
        }
        else {
        let passData = segue.destination as! ProductSechViewController
            passData.value = sender as! String
        }
    }
    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }
    
    @IBAction func actionForEnter(_ sender: Any) {
        if (partnumber.text?.isEmpty)!
        {
            displayMyAlertMessage("Please enter any text to search!")
        }
            
        else {
            
            dismissKeyboard()
            performSegue(withIdentifier: "Partnoview", sender: partnumber.text)
            
            value = partnumber.text
            
        }

        
    }
    
    // part number find the value
    
    @IBAction func partnumberfind(_ sender: Any) {
        
        
      
        if (partnumber.text?.isEmpty)!
        {
            displayMyAlertMessage("Please enter any text to search!")
        }
            
        else {
            
            dismissKeyboard()
            performSegue(withIdentifier: "Partnoview", sender: partnumber.text)
            
            value = partnumber.text
            
        }
        
        
    }
    
   
    ///// tops buttons
    let screenSize: CGRect = UIScreen.main.bounds
    let btn1 = UIButton(frame: CGRect(x: 0, y: 0, width: 20, height: 15))
    var isclicked:Bool! = true
    var menuclicked = false
    let btn2 = UIButton(type: .custom)
    let customView = UIView()
    let btn3 = UIButton()
    let myView = sildermenu()
    
    
    let signoutUser:UIButton = {
        let screenSize: CGRect = UIScreen.main.bounds
        let button = UIButton()
        button.frame = CGRect(x: screenSize.maxX - 140 , y: 25, width: 140, height: 20)
        let image:UIImage = UIImage(named: "signout")!
        button.imageEdgeInsets = UIEdgeInsets(top: 0,left: 14,bottom: 0,right: 100)
        button.setImage(image, for:.normal)
        button.addTarget(self, action: #selector(userSignOut), for: .touchUpInside)
        
        return button

        
    }()
    
    
    
    
    func userSignOut(){
        
        UserDefaults.standard.set(false,forKey:"distribuUser");
        someTextView2.isHidden = true
        signoutUser.isHidden = true
        let myAlert = UIAlertController(title:"Gates Finder", message:"Signed out successfully", preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
            
            
        })
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }

    
    let someTextView:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.minX + 60 , y: 25, width: 100, height: 20)
        let usertype = UserDefaults.standard.string(forKey: "name")
        theUserName.text = usertype
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    let someTextView2:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.maxX - 80 , y: 25, width: 80, height: 20)
        theUserName.text = "Sign Out"
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    
    
    let someImageView: UIImageView = {
        let screenSize: CGRect = UIScreen.main.bounds
        let profilepic = UserDefaults.standard.object(forKey: "profileImage")
        let theImageView = UIImageView()
        if profilepic != nil {
            theImageView.image = UIImage(data: profilepic as! Data)
            
        }
        else {
            theImageView.image = UIImage(named:"imagesss")
            
        }
        
        theImageView.frame = CGRect(x: screenSize.minX + 10, y: 16, width: 35, height: 35)
        theImageView.layer.borderWidth = 1.0
        theImageView.layer.masksToBounds = false
        theImageView.layer.borderColor = UIColor.black.cgColor
        theImageView.layer.cornerRadius = theImageView.frame.size.width/2
        theImageView.clipsToBounds = true
        theImageView.translatesAutoresizingMaskIntoConstraints = true //You need to call this property so the image is added to your view
        return theImageView
    }()
    func menubar() {
        let distrubUser = UserDefaults.standard.bool(forKey: "distribuUser")
        
        btn1.setImage(UIImage(named: "NavMenu"), for: .normal)
        btn1.addTarget(self, action: #selector(action), for: .touchUpInside)
        btn2.setImage(UIImage(named: "drowarrow"), for: .normal)
        btn2.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn2.addTarget(self, action: #selector(signout), for: .touchUpInside)
        btn3.setImage(UIImage(named: "left-arrow-key"), for: .normal)
        btn3.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn3.addTarget(self, action: #selector(back), for: .touchUpInside)
        
        
        if distrubUser == true {
            someTextView2.isHidden = false
            signoutUser.isHidden = false
            
        }
        else {
            someTextView2.isHidden = true
            signoutUser.isHidden = true
        }
        let item1 = UIBarButtonItem(customView: btn1)
        let item2 = UIBarButtonItem(customView: btn2)
        let item3 = UIBarButtonItem(customView: btn3)
        self.navigationItem.setRightBarButtonItems([item2,item1], animated: true)
        self.navigationItem.setLeftBarButtonItems([item3], animated: true)
        
        
        
    }
    func back() {
        
        let vcName = "HomePage"
        let storyboard: UIStoryboard = UIStoryboard (name: "Main", bundle: nil)
        let viewCv = storyboard.instantiateViewController(withIdentifier: vcName)
        self.navigationController?.pushViewController(viewCv, animated: true)

        
    }
    
    
    func action(sender:UIButton!) {
        menubaraction()
    }
    
    
    
    func menubaraction() {
        let myviewsize = myView.bounds
        
        
        if (menuclicked){
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            })
            
        }
        else
        {
            self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: self.screenSize.width/2, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: myviewsize.width, height:myviewsize.height)
            })
            
            
            
            
        }
        menuclicked = !menuclicked
        
        view.addSubview(myView)
        
    }
    override func viewDidAppear(_ animated: Bool) {
        
        let myviewsize = myView.bounds
        if (menuclicked){
            
            self.myView.frame = CGRect(x: 0, y: 65, width: 0, height:self.screenSize.height - 65)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            menuclicked = !menuclicked
            
        }
        menubar()
    }
    func signout(){
        
        if isclicked == true {
            isclicked = false
            
            customView.frame = CGRect.init(x: screenSize.minX, y: 64, width: screenSize.width, height: 65)
            customView.backgroundColor = UIColor.white     //give color to the view
            
            self.view.addSubview(customView)
            self.customView.addSubview(someImageView)
            self.customView.addSubview(someTextView)
            self.customView.addSubview(someTextView2)
            self.customView.addSubview(signoutUser)
            
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI))
                
            }
            UIView.animate(withDuration: 0.2, delay: 0.2, options: UIViewAnimationOptions.curveEaseIn, animations: {
                self.customView.alpha = 1.0
                
                
            }, completion: nil)
            
            
            
        }
        else
        {
            isclicked = true
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI * 2))
            }
            
            
            UIView.animate(withDuration: 1.0, animations: {
                self.customView.frame.origin.y = self.view.frame.origin.y - self.view.frame.size.height
                
            })
            
        }
        
        
    }

    func displayMyAlertMessage(_ userMessage:String)
    {
        
        let myAlert = UIAlertController(title:"Gates Finder", message:userMessage, preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler:nil);
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }
    
    
    
    
    
    //////
    
    func codeshow()  {
        
            let appdelegate = UIApplication.shared.delegate as! AppDelegate
            let context = appdelegate.persistentContainer.viewContext
            let request = NSFetchRequest<NSFetchRequestResult>(entityName:"Product")
            request.returnsDistinctResults = true
            request.resultType = .dictionaryResultType
            request.propertiesToFetch = ["make","model","modelcode","stroke","gates_Part_Number","enginecode"]
            request.returnsObjectsAsFaults = false
            
            do {
                let results = try context.fetch(request)
                if results.count > 0
                {
                    for result in results
                    {
                        //
                        if let segment = (result as AnyObject).value(forKey: "make") as? String
                        {
                            filterarray.append(segment)
                        }
                        if let segment = (result as AnyObject).value(forKey: "model") as? String
                        {
                            filterarray.append(segment)
                        }
                        if let segment = (result as AnyObject).value(forKey: "modelcode") as? String
                        {
                            filterarray.append(segment)
                        }
                        if let segment = (result as AnyObject).value(forKey: "gates_Part_Number") as? String
                        {
                            filterarray.append(segment)
                        }
                        if let segment = (result as AnyObject).value(forKey: "enginecode") as? String
                        {
                            filterarray.append(segment)
                            
                        }
                        
                        //
                    }
                    
                }
                
            }
            catch
            {
                print("error")
            }
           }

    
    
    
    //////
    

}
