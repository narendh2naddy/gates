//
//  MyCollectionViewCell.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 25/02/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    @IBOutlet var imageView: UIImageView!
    @IBOutlet var labelView: UILabel!
    @IBOutlet weak var badge: MIBadgeButton!
    
}
