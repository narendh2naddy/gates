//
//  ViewController.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 23/02/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit
import CoreData

class HomePageController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    @IBOutlet var collectView: UICollectionView!
    @IBOutlet weak var updateview: UIBarButtonItem!
   
    
    @IBOutlet var imgHerader: UIImageView!
    let Datetoshow = UserDefaults.standard.string(forKey: "thedateis")
    let Time = UserDefaults.standard.string(forKey: "theTimeis")
     let country = UserDefaults.standard.string(forKey: "country")
     let downloadsuccss = UserDefaults.standard.bool(forKey: "downloadsuccss")
    let firsttime = UserDefaults.standard.bool(forKey: "firsttime")
    
    var image = ["menusearch1.png","whatsnew1.png","video1.png","notification1.png"]
    
    var label = ["Product Search","What’s New!","Training Videos","Notification"]
    
    var viewControler = ["ProductSearch","What'sNew","VideosCategory","Notification"]
    
    let activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: UIActivityIndicatorViewStyle.whiteLarge)
    
    var downloadViewControllerclose = downloadViewController()
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        downloadViewControllerclose.dismiss(animated: false, completion: nil)
        
        menubar()
        self.navigationController?.viewControllers = [self]
        let background = UIImage(named: "background-2")
        
        var imageView : UIImageView!
        imageView = UIImageView(frame: view.bounds)
        imageView.contentMode =  UIViewContentMode.scaleAspectFill
        imageView.clipsToBounds = true
        imageView.image = background
        imageView.center = view.center
        self.collectView?.backgroundView = imageView
        
        activityIndicator.center = CGPoint(x: view.bounds.size.width/2, y: view.bounds.size.height/2)
        activityIndicator.color = UIColor.red
        view.addSubview(activityIndicator)
                
//
        imgHerader.image = UIImage(named: "title_image.png")
        self.collectView.delegate = self
        self.collectView.dataSource = self
        
        }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = UIScreen.main.bounds.width
        return CGSize(width: (width - 10)/2, height: (width - 10)/2) // width & height are the same to make a square cell
    }

    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return image.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:"cell", for: indexPath) as! MyCollectionViewCell
        cell.imageView.image =  UIImage(named: image[indexPath.row])
        cell.labelView.text = label[indexPath.row]
        
        return cell
    }
    
    
    // collectionview which is the button for all home page
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let gatesEmployee = UserDefaults.standard.string(forKey: "usertype")
        let distrubUser = UserDefaults.standard.bool(forKey: "distribuUser")
        let vcName = viewControler[indexPath.row]
        
        if vcName != "VideosCategory"
        {
            if vcName != "distributionNetwork"
            {
                let viewCv = storyboard?.instantiateViewController(withIdentifier: vcName)
                self.navigationController?.pushViewController(viewCv!, animated: true)

            }
            else
            
            {
                if distrubUser == true {
                let viewCv = storyboard?.instantiateViewController(withIdentifier: "distriLogin")
                self.navigationController?.pushViewController(viewCv!, animated: true)
                }
                else {
                
                    let viewCv = storyboard?.instantiateViewController(withIdentifier: "distributionNetwork")
                    self.navigationController?.pushViewController(viewCv!, animated: true)
                }
            }
            
                }
        else {
        
            
            if gatesEmployee != "Gates Employee"||distrubUser == true
                
            {
                let viewCv = storyboard?.instantiateViewController(withIdentifier: "trainLoginview")
                self.navigationController?.pushViewController(viewCv!, animated: true)
            }
            else {
                let viewCv = storyboard?.instantiateViewController(withIdentifier: "VideosCategory")
                self.navigationController?.pushViewController(viewCv!, animated: true)
            
            }
        
        }
    }
    
    
    
   // check update button
    @IBAction func update(_ sender: Any) {
        
        
        if firsttime {
        
            displayMyAlertMessage("you have been download data recently.. please restart the app and you can able to download the updated data  ")
            print("frist time")
        }
        
        
        else {
        self.activityIndicator.isHidden = false
        self.activityIndicator.startAnimating()
        
        
        let alertController = UIAlertController(title: "Last Updated", message: "Date:\(Datetoshow!) Time:\(Time!)\n Check for update", preferredStyle: .alert)
        
        
        
        // Create OK button
        let OKAction = UIAlertAction(title: "Update", style: .default) { (action:UIAlertAction!) in
            
            ///
            
            if self.currentReachabilityStatus == .notReachable {
                self.alert1()
            }
            else {
                
                
                self.updatetheproduct(params:["date":"\(self.Datetoshow!) \(self.Time!)","Country":"\(self.country!)"])
                self.view.isUserInteractionEnabled = false

            }
            
            
            
            
            ////
        }
        alertController.addAction(OKAction)
        
        // Create Cancel button
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel) { (action:UIAlertAction!) in
            
            self.activityIndicator.isHidden = true
            self.activityIndicator.stopAnimating()
            self.view.isUserInteractionEnabled = true

            
        }
        alertController.addAction(cancelAction)
        
        // Present Dialog message
        self.present(alertController, animated: true, completion:nil)
        
        }
        
    }
   
    // download the product for the update
    func product(){
        let appdelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appdelegate.persistentContainer.viewContext
        // Strat of Produt
        let urlString = "http://54.255.163.200/api/product/get/?Country=\(country!)"
        let url = URL(string: urlString)
        URLSession.shared.dataTask(with:url!) { (data, response, error) in
            if error != nil {
                self.alert("Download interrupted due to \(error?.localizedDescription).Restart the download")
            } else {
                do {
                    
                    
                    
                    
                    let parsedData = try JSONSerialization.jsonObject(with: data!, options: []) as! NSArray
                    DispatchQueue.main.async {
                        for i in 0..<parsedData.count {
                            let product = NSEntityDescription.insertNewObject(forEntityName: "Product", into: context)
                            
                            let Product = parsedData[i] as! NSDictionary
                            
                            
                            if Product["Segment"] is NSNull {product.setValue("", forKey: "segment")}
                            else{product.setValue(Product["Segment"], forKey: "segment")}
                            
                            if Product["Make"] is NSNull {product.setValue("", forKey: "make")}
                            else{product.setValue(Product["Make"], forKey: "make")}
                            
                            if Product["Model"] is NSNull {product.setValue("", forKey: "model")}
                            else{product.setValue(Product["Model"], forKey: "model")}
                            
                            if Product["Stroke"] is NSNull {product.setValue("", forKey: "stroke")}
                            else{product.setValue(Product["Stroke"], forKey: "stroke")}
                            
                            if Product["Modelcode"] is NSNull {product.setValue("", forKey: "modelcode")}
                            else{product.setValue(Product["Modelcode"], forKey: "modelcode")}
                            
                            if Product["Enginecode"] is NSNull {product.setValue("", forKey: "enginecode")}
                            else{product.setValue(Product["Enginecode"], forKey: "enginecode")}
                            
                            if Product["Year_From"] is NSNull {product.setValue("", forKey: "year_From")}
                            else{product.setValue(Product["Year_From"], forKey: "year_From")}
                            
                            if Product["Month_From"] is NSNull {product.setValue("", forKey: "month_From")}
                            else{product.setValue(Product["Month_From"], forKey: "month_From")}
                            
                            if Product["Year_Till"] is NSNull {product.setValue("", forKey: "year_Till")}
                            else{product.setValue(Product["Year_Till"], forKey: "year_Till")}
                            
                            if Product["Month_Till"] is NSNull {product.setValue("", forKey: "month_Till")}
                            else{product.setValue(Product["Month_Till"], forKey: "month_Till")}
                            
                            if Product["PartDescription"] is NSNull {product.setValue("", forKey: "part_Description")}
                            else{product.setValue(Product["PartDescription"], forKey: "part_Description")}
                            
                            if Product["Gates_Part_Number"] is NSNull {product.setValue("", forKey: "gates_Part_Number")}
                            else{product.setValue(Product["Gates_Part_Number"], forKey: "gates_Part_Number")}
                            
                            if Product["Equipment"] is NSNull {product.setValue("", forKey: "equipment")}
                            else{product.setValue(Product["Equipment"], forKey: "equipment")}
                            
                            if Product["Equipment_2"] is NSNull {product.setValue("", forKey: "equipment_2")}
                            else{product.setValue(Product["Equipment_2"], forKey: "equipment_2")}
                            
                            if Product["Equipment_Date_From"] is NSNull {product.setValue("", forKey: "equipment_Date_From")}
                            else{product.setValue(Product["Equipment_Date_From"], forKey: "equipment_Date_From")}
                            
                            if Product["Equipment_Date_To"] is NSNull {product.setValue("", forKey: "equipment_Date_To")}
                            else{product.setValue(Product["Equipment_Date_To"], forKey: "equipment_Date_To")}
                            
                            if Product["Part_Description1"] is NSNull {product.setValue("", forKey: "imageName")}
                            else{product.setValue(Product["Part_Description1"], forKey: "imageName")}
                            
                            if Product["ProductAdditionalInfo"] is NSNull {product.setValue("", forKey: "productAdditionalInfo")}
                            else{product.setValue(Product["ProductAdditionalInfo"], forKey: "productAdditionalInfo")}
                            print("row\(i)\(Product["Make"]!)")
                            do {
                                try context.save()
                                
                            }
                            catch let error as NSError {
                                print(error)
                                self.alert("Download interrupted due to \(error.localizedDescription).Restart the download")
                                
                                
                            }
                            
                            
                            
                        }
                        print("DONE1")
                        self.OE()
                    }
                    
                } catch let error as NSError {
                    print(error)
                    self.alert("Download interrupted due to \(error.localizedDescription).Restart the download")
                    
                }
            }
            
            }.resume()
        
        
        /// end of produt
        
    }
    
    
    
    func OE(){
        let appdelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appdelegate.persistentContainer.viewContext
        
        /// strat of OE
        
        let urlString1 = "http://54.255.163.200/api/product/GetOEParts"
        let url1 = URL(string: urlString1)
        URLSession.shared.dataTask(with:url1!) { (data, response, error) in
            if error != nil {
                self.alert("Download interrupted due to \(error?.localizedDescription).Restart the download")
            } else {
                do {
                    let parsedData1 = try JSONSerialization.jsonObject(with: data!, options: []) as! NSArray
                    DispatchQueue.main.async {
                        for i in 0..<parsedData1.count {
                            ///////
                            let product1 = NSEntityDescription.insertNewObject(forEntityName: "OEsearch", into: context)
                            
                            let Product1 = parsedData1[i] as! NSDictionary
                            
                            if Product1["OEMake"] is NSNull {product1.setValue("", forKey: "oeMake")}
                            else{product1.setValue(Product1["OEMake"], forKey: "oeMake")}
                            
                            if Product1["OENumber"] is NSNull {product1.setValue("", forKey: "oeNumber")}
                            else{product1.setValue(Product1["OENumber"], forKey: "oeNumber")}
                            
                            if Product1["PartDescription"] is NSNull {product1.setValue("", forKey: "partDescription")}
                            else{product1.setValue(Product1["PartDescription"], forKey: "partDescription")}
                            
                            if Product1["gatesPartNumber"] is NSNull {product1.setValue("", forKey: "gatesPartNumber")}
                            else{product1.setValue(Product1["gatesPartNumber"], forKey: "gatesPartNumber")}
                            
                            if Product1["Part_Description"] is NSNull {product1.setValue("", forKey: "imageName")}
                            else{product1.setValue(Product1["Part_Description"], forKey: "imageName")}

                            print("OE Row \(i)")
                            print(Product1["OENumber"]!)
                            do {
                                try context.save()
                                
                            }
                            catch let error as NSError {
                                print(error)
                                self.alert("Download interrupted due to \(error.localizedDescription).Restart the download")
                                
                                
                            }
                            
                           
                            
                            ////////
                            
                        }
                        print("DONE2")
                        self.view.isUserInteractionEnabled = true
                        let myAlert = UIAlertController(title:"Gates Finder", message:"Updated successfully", preferredStyle: UIAlertControllerStyle.alert);
                        
                        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
                            
                            
                            self.activityIndicator.isHidden = true
                            self.activityIndicator.stopAnimating()
                            
                            
                        })
                        
                        myAlert.addAction(okAction);
                        
                        self.present(myAlert, animated:true, completion:nil);
                        

                        
                        
                    }
                    
                } catch let error as NSError {
                    print(error)
                    self.alert("Download interrupted due to \(error.localizedDescription).Restart the download")
                    
                }
            }
            
            }.resume()
        
        
        ///end of oe
    }
    func postdata3() {
        
        let appdelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appdelegate.persistentContainer.viewContext
        
        let urlString = "http://54.255.163.200/api/common/getImages"
        
        let url = URL(string: urlString)
        URLSession.shared.dataTask(with:url!) { (data, response, error) in
            if error != nil {
                print(error!)
            } else {
                do {
                    
                    let parsedData = try JSONSerialization.jsonObject(with: data!, options: []) as! NSDictionary
                    DispatchQueue.main.async {
                        
                        if let result = parsedData["result"] as? String  {
                            print(result)
                            if result == "Success" {
                                let data = parsedData["data"] as! NSArray
                                for i in 0..<data.count {
                                    
                                    let product = NSEntityDescription.insertNewObject(forEntityName: "Image", into: context)
                                    
                                    let Product = data[i] as! NSDictionary
                                    
                                    let aString = (Product["Part_Description"]) as! String
                                    if aString != "" {
                                        let newString = aString.replacingOccurrences(of: " ", with: "_", options: .literal, range: nil)
                                        
                                        print(aString)
                                        product.setValue(newString, forKey: "imageName")
                                    }
                                    
                                    let value = (Product["ProductURL"]) as! String
                                    if value != ""{
                                        let url = value.trimmingCharacters(in: .whitespaces)
                                        let pictureURL = URL(string:url)!
                                        let session = URLSession(configuration: .default)
                                        let downloadPicTask = session.dataTask(with: pictureURL) { (data, response, error) in
                                            // The download has finished.
                                            if let e = error {
                                                print("Error downloading picture: \(e)")
                                            } else {
                                                // No errors found.
                                                // It would be weird if we didn't have a response, so check for that too.
                                                if (response as? HTTPURLResponse) != nil {
                                                    if let imageData = data {
                                                        // Finally convert that Data into an image and do what you wish with it.
                                                        product.setValue(imageData, forKey: "imageData")
                                                        print("this the\(imageData)")
                                                        
                                                        
                                                        // Do something with your image.
                                                    } else {
                                                        print("Couldn't get image: Image is nil")
                                                    }
                                                } else {
                                                    print("Couldn't get response code for some reason")
                                                }
                                            }
                                        }
                                        
                                        downloadPicTask.resume()
                                        
                                    }
                                    
                                }
                                do {
                                    try context.save()
                                    
                                }
                                catch {
                                    print("errro")
                                    
                                }
                                ////////
                            }
                        }
                        //////
                        
                    }
                    self.product()
                    
                } catch let error as NSError {
                    print(error)
                }
            }
            
            }.resume()
        
        //
    }

    func alert(_ userMessage:String){
        
        let alertController = UIAlertController(title: "OOPS!!!", message: userMessage, preferredStyle: UIAlertControllerStyle.alert)
        let ok = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: {(action) -> Void in
            self.activityIndicator.isHidden = true
            self.activityIndicator.stopAnimating()
            self.view.isUserInteractionEnabled = true

            
        })
        
        alertController.addAction(ok)
        self.present(alertController, animated: true, completion: nil)
        
        
        
    }
    func alert1(){
        
        let alertController = UIAlertController(title: "Alert", message: "No internet connection", preferredStyle: UIAlertControllerStyle.alert)
        let ok = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: {(action) -> Void in
            
            _ = self.navigationController?.popViewController(animated: true)
            
        })
        
        alertController.addAction(ok)
        self.present(alertController, animated: true, completion: nil)
    }

    func displayMyAlertMessage(_ userMessage:String)
    {
        
        let myAlert = UIAlertController(title:"Gates Finder", message:userMessage, preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
            
            self.activityIndicator.isHidden = true
            self.activityIndicator.stopAnimating()
            self.view.isUserInteractionEnabled = true
            
        })
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }
    

    
    
    
    func updatetheproduct(params:[String:String])
    {
        let session = URLSession.shared
        let url = "http://54.255.163.200/api/common/CheckUpdate"
        let request = NSMutableURLRequest(url: NSURL(string: url)! as URL)
        request.httpMethod = "POST"
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")
        do{
            request.httpBody = try JSONSerialization.data(withJSONObject:params, options: JSONSerialization.WritingOptions())
            let task = session.dataTask(with: request as URLRequest, completionHandler: {(data, response, error) in
                if let response = response {
                    let nsHTTPResponse = response as! HTTPURLResponse
                    let statusCode = nsHTTPResponse.statusCode
                    print ("status code = \(statusCode)")
                }
                if let error = error {
                    print ("\(error)")
                }
                if let data = data {
                    do{
                        let jsonResponse = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions()) as! NSDictionary
                        let result = jsonResponse["result"] as! String
                        
                        if result == "Success" {
                        
                        self.deletianddownload()
                        
                        
                        }
                        else if result == "NoNewProducts"{
                            
                            self.displayMyAlertMessage("Application is up to date!")
                            
                        }
                        else {
                            //                                self.displayMyAlertMessage("Something Nothing")
                            print("Something Nothing")
                        }
                        
                        
                        //                        let resutl = jsonResponse["result"] as String
                    }catch _ {
                        let erro = String(data: data, encoding: String.Encoding.utf8)
                        print ("OOps not good JSON formatted response\(erro)")
                        
                        
                        
                    }
                }
            })
            task.resume()
        }catch _ {
            print ("Oops something happened buddy")
        }
        
       

        
    }

    ////
    
    func getthedate(){
        let date = Date()
        let formatter = DateFormatter()
        let hour = Calendar.current.component(.hour, from: date)
        let minutes = Calendar.current.component(.minute, from: date)
        let seconds = Calendar.current.component(.second, from: date)
        let time = "\(hour):\(minutes):\(seconds)"
        formatter.dateFormat = "yyyy.MM.dd"
        let Date2 = formatter.string(from: date)
        UserDefaults.standard.set(Date2, forKey: "thedateis")
        
        UserDefaults.standard.set(time, forKey: "theTimeis")
        
        UserDefaults.standard.synchronize();
        
        
    }
    ////
    
    
    
    let screenSize: CGRect = UIScreen.main.bounds
    var isclicked:Bool! = true
    let btn2 = UIButton(type: .custom)
    let customView = UIView()
    let btn1 = UIButton()
    let myView = sildermenu()
    var menuclicked = false
    
    let signoutUser:UIButton = {
        let screenSize: CGRect = UIScreen.main.bounds
        let button = UIButton()
        button.frame = CGRect(x: screenSize.maxX - 140 , y: 25, width: 140, height: 20)
        let image:UIImage = UIImage(named: "signout")!
        button.imageEdgeInsets = UIEdgeInsets(top: 0,left: 14,bottom: 0,right: 100)
        button.setImage(image, for:.normal)
        button.addTarget(self, action: #selector(userSignOut), for: .touchUpInside)
        
        return button

        
    }()
    
    func userSignOut(){
        
        UserDefaults.standard.set(false,forKey:"distribuUser");
        someTextView2.isHidden = true
        signoutUser.isHidden = true
        let myAlert = UIAlertController(title:"Gates Finder", message:"Signed out successfully", preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
            
            
        })
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }
    
    let someTextView:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.minX + 60 , y: 25, width: 100, height: 20)
         let name = UserDefaults.standard.string(forKey: "name")
        theUserName.text = name
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    let someTextView2:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.maxX - 80 , y: 25, width: 80, height: 20)
        theUserName.text = "Sign Out"
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    
    
    let someImageView: UIImageView = {
        let screenSize: CGRect = UIScreen.main.bounds
        let profilepic = UserDefaults.standard.object(forKey: "profileImage")
        let theImageView = UIImageView()
        if profilepic != nil {
            theImageView.image = UIImage(data: profilepic as! Data)
            
        }
        else {
            theImageView.image = UIImage(named:"imagesss")
            
        }
        
        theImageView.frame = CGRect(x: screenSize.minX + 10, y: 16, width: 35, height: 35)
        theImageView.layer.borderWidth = 1.0
        theImageView.layer.masksToBounds = false
        theImageView.layer.borderColor = UIColor.black.cgColor
        theImageView.layer.cornerRadius = theImageView.frame.size.width/2
        theImageView.clipsToBounds = true
        theImageView.translatesAutoresizingMaskIntoConstraints = true //You need to call this property so the image is added to your view
        return theImageView
    }()
    func menubar() {
         let distrubUser = UserDefaults.standard.bool(forKey: "distribuUser")
       
        btn1.setImage(UIImage(named: "NavMenu"), for: .normal)
        btn1.frame = CGRect(x: 0, y: 0, width: 20, height: 15)
        btn1.addTarget(self, action: #selector(action), for: .touchUpInside)

        btn2.setImage(UIImage(named: "drowarrow"), for: .normal)
        btn2.frame = CGRect(x: 0, y: 0, width: 30, height: 30)
        btn2.addTarget(self, action: #selector(signout), for: .touchUpInside)
        
        if distrubUser == true {
            someTextView2.isHidden = false
            signoutUser.isHidden = false
        }
        else {
            someTextView2.isHidden = true
            signoutUser.isHidden = true
        }
         let item2 = UIBarButtonItem(customView: btn2)
          let item1 = UIBarButtonItem(customView: btn1)
        self.navigationItem.setRightBarButtonItems([updateview,item2], animated: true)
        self.navigationItem.setLeftBarButtonItems([item1], animated: true)
        
    }
    
    
    func action(sender:UIButton!) {
        menubaraction()
    }
    
    
    
    func menubaraction() {
        let myviewsize = myView.bounds
        
        
        if (menuclicked){
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            })
            
        }
        else
        {
            self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: self.screenSize.width/2, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: myviewsize.width, height:myviewsize.height)
            })
            
            
            
            
        }
        menuclicked = !menuclicked
        view.addSubview(myView)
        
        
    }

    override func viewDidAppear(_ animated: Bool) {
        
        let myviewsize = myView.bounds
        if (menuclicked){
            
            self.myView.frame = CGRect(x: 0, y: 65, width: 0, height:self.screenSize.height - 65)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            menuclicked = !menuclicked
            
        }
        
        menubar()
        let isUserLoggedIn = UserDefaults.standard.bool(forKey: "isUserLoggedIn");
        
        if(!isUserLoggedIn)
        {
            self.performSegue(withIdentifier: "loginview", sender: self);
        }
        else if (!downloadsuccss) {downloadfails()}
        
        

    }
    
    
    
    
    
  
    func signout(){
        
        if isclicked == true {
            isclicked = false
            
            customView.frame = CGRect.init(x: screenSize.minX, y: 64, width: screenSize.width, height: 65)
            customView.backgroundColor = UIColor.white     //give color to the view
            
            self.view.addSubview(customView)
            self.customView.addSubview(someImageView)
            self.customView.addSubview(someTextView)
            self.customView.addSubview(someTextView2)
            self.customView.addSubview(signoutUser)
            
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI))
                
            }
            UIView.animate(withDuration: 0.2, delay: 0.2, options: UIViewAnimationOptions.curveEaseIn, animations: {
                self.customView.alpha = 1.0
            }, completion: nil)
            
            
            
        }
        else
        {
            isclicked = true
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI * 2))
            }
            
            UIView.animate(withDuration: 0.2, delay: 0.2, options: UIViewAnimationOptions.curveEaseOut, animations: {
                self.customView.alpha = 0.0
            }, completion: nil)
            
        }
        
        
    }
    
    
    func downloadfails(){
        
        
        let myAlert = UIAlertController(title:"Gates Finder", message:"❗️Download failed due to unknown error please download data again !!!", preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
            
             self.deletianddownload()
            self.activityIndicator.isHidden = false
            self.activityIndicator.startAnimating()
            UserDefaults.standard.set(true, forKey: "downloadsuccss")
            
            UserDefaults.standard.synchronize();
            
        })
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);

        
        
    }
    
    
    func deletianddownload(){

            let appDel = UIApplication.shared.delegate as! AppDelegate
            let context = appDel.persistentContainer.viewContext
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Product")
            request.returnsObjectsAsFaults = false
            
            do {
                let results = try context.fetch(request)
                
                if results.count > 0 {
                    
                    for result in results as! [NSManagedObject]
                    {
                        print(result)
                        context.delete(result)
                        print("NSManagedObject has been Deleted")
                    }
                    try context.save() } }
            catch {
        
                print("error getting xml string: \(error)")
        
        }
            
            
            
            let request1 = NSFetchRequest<NSFetchRequestResult>(entityName: "OEsearch")
            request1.returnsObjectsAsFaults = false
            
            do {
                let results = try context.fetch(request1)
                
                if results.count > 0 {
                    
                    for result in results as! [NSManagedObject]
                    {
                        context.delete(result)
                        print("NSManagedObject has been Deleted")
                    }
                    try context.save() } } catch {}
            
//            let request2 = NSFetchRequest<NSFetchRequestResult>(entityName: "Image")
//            request2.returnsObjectsAsFaults = false
//            
//            do {
//                let results = try context.fetch(request2)
//                
//                if results.count > 0 {
//                    
//                    for result in results as! [NSManagedObject]
//                    {
//                        context.delete(result)
//                        print("NSManagedObject has been Deleted")
//                    }
//                    try context.save() } } catch {}
            self.getthedate()
            self.product()
//            self.postdata3()
        
        
    
    
    }
    
    
    
    
}

