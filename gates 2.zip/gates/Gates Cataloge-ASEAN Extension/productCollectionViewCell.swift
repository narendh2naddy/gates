//
//  productCollectionViewCell.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 27/02/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit

class productCollectionViewCell: UICollectionViewCell {
    
}
