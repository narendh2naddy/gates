//
//  tempee.m
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 03/03/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

#import "tempee.h"

@implementation tempee

@end
