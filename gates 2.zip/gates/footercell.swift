//
//  footercell.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 26/07/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit

class footercell: UICollectionReusableView {
    
    
    @IBOutlet weak var facebook: UIButton!
    
    @IBOutlet weak var linked: UIButton!
    
    
   
    
    @IBAction func facebookaction(_ sender: Any) {
        if let url = NSURL(string:"https://www.facebook.com/GatesSoutheastAsia/"){ UIApplication.shared.open(url as URL, options: [:], completionHandler: nil) }

    }
    
    @IBAction func linkedinaction(_ sender: Any) {
        if let url = NSURL(string:"https://www.linkedin.com/company-beta/7167/"){ UIApplication.shared.open(url as URL, options: [:], completionHandler: nil) }

        
    }
    
        
}
