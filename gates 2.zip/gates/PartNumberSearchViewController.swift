//
//  PartNumberSearchViewController.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 25/03/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit
import CoreData

class PartNumberSearchViewController: UIViewController,UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var headimg: UIImageView!
    
    @IBOutlet var tableView: UITableView!
    
    var partNumber:String!
    
    
    var partnumbersep:[String]!
    
    
    var value1:String!
    var value2:String!
    var value3:String!
    var value4:String!
    var value5:String!
    var value6:String!
    var values7:String!
    var values8:String!
    var values9:String!
    var values10:String!
    var values11:String!
    var values12:String!
    var values13:String!
    var dataGet:[String]! = []
    var dataGet1:[String]! = []
    var dataGet2:[String]! = []
    var dataGet3:[String]! = []
    var dataGet4:[String]! = []
    var dataGet5:[String]! = []
    var dataGet6:[String]! = []
    var dataGet7:[String]! = []
    var dataGet8:[String]! = []
    var dataGet9:[String]! = []
    var dataGet10:[String]! = []
    var dataGet11:[String]! = []
    var dataGet12:[String]! = []
    var dataGet13:[String]! = []
    var dataGet14:[String]! = []
    var dataGet15:[String]! = []
    
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let imageView = UIImageView(frame: self.view.frame)
        let image = UIImage(named: "background-2")!
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "Back", style: UIBarButtonItemStyle.plain, target: nil, action: nil)
        imageView.image = image
        self.view.addSubview(imageView)
        self.view.sendSubview(toBack: imageView)
        tableView.backgroundColor = UIColor.clear
        self.title = "Part Search"
        
        
        
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        headimg.image = UIImage(named: "title_image.png")
        
        
        // sreach for concatenate
        
        partNumber = partNumber.replacingOccurrences(of: " ", with: "")
        
        if partNumber.contains("+") && partNumber.contains(","){
            displayMyAlertMessage("Please use either comma (,) or concatenate (+) for searching!")
        }
        else{
            if partNumber.contains("+"){
                
                partnumbersep = partNumber.components(separatedBy: "+")
                codeshow2()
            }
            else{
                partnumbersep = partNumber.components(separatedBy: ",")
                codeshow()
            }
        }
        menubar()
        
        
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int
    {
        return 2
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat
    {
        
        return 60
        
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        
        let reuseIdentifier : String!
        reuseIdentifier = String(format: "HeaderCell")
        
        let headerView = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier)
        
        return headerView
    }
    

    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if dataGet.count == 0 {
            displayMyAlertMessage("No Data Found")
        }
        
        return dataGet.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath ) as! PartseacrhTableViewCell
        
        cell.lbl1.text = " \(dataGet[indexPath.row])"
        cell.lbl2.text = dataGet1[indexPath.row]
        cell.lbl3.text = dataGet2[indexPath.row]
        cell.lbl4.attributedText = NSAttributedString(string: dataGet9[indexPath.row], attributes:
            [NSUnderlineStyleAttributeName: NSUnderlineStyle.styleSingle.rawValue])
        
        cell.lbl5.text = dataGet10[indexPath.row]
        cell.backgroundColor = UIColor.clear
        let backgroundView = UIView()
        backgroundView.backgroundColor = UIColor.darkGray
        cell.selectedBackgroundView = backgroundView

        
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        // value sends the data to next page
        
        value1 = dataGet15[indexPath.row]
        value3 = dataGet[indexPath.row]
        value4 = dataGet1[indexPath.row]
        value5 = dataGet2[indexPath.row]
        value6 = dataGet9[indexPath.row]
        values7 = dataGet4[indexPath.row]
        values8 = dataGet5[indexPath.row]
        values9 = dataGet6[indexPath.row]
        values10 = dataGet7[indexPath.row]
        values11 = dataGet10[indexPath.row]
        values12 = dataGet3[indexPath.row]
        values13 = dataGet8[indexPath.row]
        
        performSegue(withIdentifier: "partTomore", sender: self)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?){
        let passData = segue.destination as! moreseachViewController
        passData.value1 = value1 // segment
        passData.value2 = "No data"
        passData.value3 = value3 // make
        passData.value4 = value4 // model
        passData.value5 = value5 // modelcode
        passData.value6 = value6 // gates_Part_Number
        passData.values7 = values7 // year_From
        passData.values8 = values8 // month_From
        passData.values9 = values9 // year_Till
        passData.values10 = values10 // month_Till
        passData.values11 = values11 // enginecode
        passData.values12 = values12 // stroke
        passData.values13 = values13 // part_Description
        
    }
    
    
    func codeshow()  {
        
        for find in partnumbersep {
            
            // sreach with , code
            let appdelegate = UIApplication.shared.delegate as! AppDelegate
            let context = appdelegate.persistentContainer.viewContext
            let request = NSFetchRequest<NSFetchRequestResult>(entityName:"Product")
            let predicate1 = NSPredicate(format: "make  LIKE[cd] %@","\(find)*")
            let predicate2 = NSPredicate(format: "model LIKE[cd] %@","\(find)*")
            let predicate3 = NSPredicate(format: "modelcode LIKE[cd] %@","\(find)*")
            let predicate4 = NSPredicate(format: "gates_Part_Number LIKE[cd] %@","\(find)*")
            let predicate5 = NSPredicate(format: "enginecode LIKE[cd] %@","\(find)*")
            
            
            let finalpredicate = NSCompoundPredicate(type: NSCompoundPredicate.LogicalType.or, subpredicates: [predicate1,predicate2,predicate3,predicate4,predicate5])
            request.predicate = finalpredicate
            request.returnsDistinctResults = true
            request.resultType = .dictionaryResultType
            request.propertiesToFetch = ["make","model","modelcode","stroke","year_From","month_From","year_Till","month_Till","part_Description","gates_Part_Number","enginecode","equipment","equipment_2","equipment_Date_From","equipment_Date_To","segment"]
            request.returnsObjectsAsFaults = false
            
            do {
                
                let results = try context.fetch(request)
                
                if results.count > 0
                {
                    for result in results
                    {
                        //
                        if let segment = (result as AnyObject).value(forKey: "make") as? String
                        {
                            
                            dataGet.append(segment)
                            print(segment)
                        }
                        if let segment = (result as AnyObject).value(forKey: "model") as? String
                        {
                            
                            dataGet1.append(segment)
                        }
                        if let segment = (result as AnyObject).value(forKey: "modelcode") as? String
                        {
                            
                            dataGet2.append(segment)
                            print(segment)
                        }
                        if let segment = (result as AnyObject).value(forKey: "stroke") as? String
                        {
                            
                            dataGet3.append(segment)
                            print(segment)
                        }
                        if let segment = (result as AnyObject).value(forKey: "year_From") as? String
                        {
                            
                            dataGet4.append(segment)
                            print(segment)
                        }
                        if let segment = (result as AnyObject).value(forKey: "month_From") as? String
                        {
                            
                            dataGet5.append(segment)
                            print(segment)
                        }
                        if let segment = (result as AnyObject).value(forKey: "year_Till") as? String
                        {
                            
                            dataGet6.append(segment)
                            print(segment)
                        }
                        if let segment = (result as AnyObject).value(forKey: "month_Till") as? String
                        {
                            
                            dataGet7.append(segment)
                            print(segment)
                        }
                        if let segment = (result as AnyObject).value(forKey: "part_Description") as? String
                        {
                            
                            dataGet8.append(segment)
                            print(segment)
                            
                        }
                        if let segment = (result as AnyObject).value(forKey: "gates_Part_Number") as? String
                        {
                            
                            dataGet9.append(segment)
                            print(segment)
                        }
                        if let segment = (result as AnyObject).value(forKey: "enginecode") as? String
                        {
                            
                            dataGet10.append(segment)
                            print(segment)
                        }
                        if let segment = (result as AnyObject).value(forKey: "equipment") as? String
                        {
                            
                            dataGet11.append(segment)
                            print(segment)
                        }
                        if let segment = (result as AnyObject).value(forKey: "equipment_2") as? String
                        {
                            
                            dataGet12.append(segment)
                            print(segment)
                            
                        }
                        if let segment = (result as AnyObject).value(forKey: "equipment_Date_From") as? String
                        {
                            
                            dataGet13.append(segment)
                            print(segment)
                        }
                        if let segment = (result as AnyObject).value(forKey: "equipment_Date_To") as? String
                        {
                            
                            dataGet14.append(segment)
                            print(segment)
                        }
                        if let segment = (result as AnyObject).value(forKey: "segment") as? String
                        {
                            
                            dataGet15.append(segment)
                            print(segment)
                        }
                        
                        
                        //
                    }
                    
                }
                
            }
            catch
            {
                
            }
        }
    }
    
    func codeshow2()  {
        // code for + code
        let appdelegate = UIApplication.shared.delegate as! AppDelegate
        let context = appdelegate.persistentContainer.viewContext
        let request = NSFetchRequest<NSFetchRequestResult>(entityName:"Product")
        
        var predicate1 = NSPredicate()
        var predicate2 = NSPredicate()
        var predicate3 = NSPredicate()
        var predicate4 = NSPredicate()
        var predicate5 = NSPredicate()
        var predicate6 = NSPredicate()
        var predicate7 = NSPredicate()
        var predicate8 = NSPredicate()
        var predicate9 = NSPredicate()
        var predicate10 = NSPredicate()
        var predicate11 = NSPredicate()
        var predicate12 = NSPredicate()
        var predicate13 = NSPredicate()
        var predicate14 = NSPredicate()
        var predicate15 = NSPredicate()
        var predicate16 = NSPredicate()
        var predicate17 = NSPredicate()
        var predicate18 = NSPredicate()
        var predicate19 = NSPredicate()
        var predicate20 = NSPredicate()
        var predicate21 = NSPredicate()
        var predicate22 = NSPredicate()
        var predicate23 = NSPredicate()
        var predicate24 = NSPredicate()
        var predicate25 = NSPredicate()
        var predicate26 = NSPredicate()
        var predicate27 = NSPredicate()
        var predicate28 = NSPredicate()
        var predicate29 = NSPredicate()
        var predicate30 = NSPredicate()
        var predicate31 = NSPredicate()
        var predicate32 = NSPredicate()
        var predicate33 = NSPredicate()
        var predicate34 = NSPredicate()
        var predicate35 = NSPredicate()
        var predicate36 = NSPredicate()
        var predicate37 = NSPredicate()
        var predicate38 = NSPredicate()
        var predicate39 = NSPredicate()
        var predicate40 = NSPredicate()
        var predicate41 = NSPredicate()
        var predicate42 = NSPredicate()
        var predicate43 = NSPredicate()
        var predicate44 = NSPredicate()
        var predicate45 = NSPredicate()
        var predicate46 = NSPredicate()
        var predicate47 = NSPredicate()
        var predicate48 = NSPredicate()
        var predicate49 = NSPredicate()
        var predicate50 = NSPredicate()
        var predicate51 = NSPredicate()
        var predicate52 = NSPredicate()
        var predicate53 = NSPredicate()
        var predicate54 = NSPredicate()
        var predicate55 = NSPredicate()
        var predicate56 = NSPredicate()
        var predicate57 = NSPredicate()
        var predicate58 = NSPredicate()
        var predicate59 = NSPredicate()
        var predicate60 = NSPredicate()
        var finalpredicate = NSCompoundPredicate()
        
        
        
        switch partnumbersep.count {
        case 2:
            predicate1 = NSPredicate(format: "make CONTAINS[c] %@ AND model CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate2 = NSPredicate(format: "model CONTAINS[c] %@ AND make CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate3 = NSPredicate(format: "make CONTAINS[c] %@ AND modelcode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate4 = NSPredicate(format: "modelcode CONTAINS[c] %@ AND make CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate5 = NSPredicate(format: "model CONTAINS[c] %@ AND modelcode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate6 = NSPredicate(format: "modelcode CONTAINS[c] %@ AND model CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate7 = NSPredicate(format: "make CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate8 = NSPredicate(format: "gates_Part_Number CONTAINS[c] %@ AND make CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate9 = NSPredicate(format: "model CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate10 = NSPredicate(format: "gates_Part_Number CONTAINS[c] %@ AND model CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate11 = NSPredicate(format: "gates_Part_Number CONTAINS[c] %@ AND modelcode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate12 = NSPredicate(format: "modelcode CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate13 = NSPredicate(format: "make CONTAINS[c] %@ AND enginecode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate14 = NSPredicate(format: "enginecode CONTAINS[c] %@ AND make CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate15 = NSPredicate(format: "model CONTAINS[c] %@ AND enginecode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate16 = NSPredicate(format: "enginecode CONTAINS[c] %@ AND model CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate17 = NSPredicate(format: "modelcode CONTAINS[c] %@ AND enginecode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate18 = NSPredicate(format: "enginecode CONTAINS[c] %@ AND modelcode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate19 = NSPredicate(format: "enginecode CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate20 = NSPredicate(format: "gates_Part_Number CONTAINS[c] %@ AND enginecode CONTAINS[c] %@", argumentArray: partnumbersep)
            finalpredicate = NSCompoundPredicate(type: NSCompoundPredicate.LogicalType.or, subpredicates: [predicate1,predicate2,predicate3,predicate4,predicate5,predicate6,predicate7,predicate8,predicate9,predicate10,predicate11,predicate12,predicate13,predicate14,predicate15,predicate16,predicate17,predicate18,predicate19,predicate20,])
            
        case 3:
            predicate1 = NSPredicate(format: "make CONTAINS[c] %@ AND model CONTAINS[c] %@ AND modelcode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate2 = NSPredicate(format: "model CONTAINS[c] %@ AND modelcode CONTAINS[c] %@ AND make CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate3 = NSPredicate(format: "modelcode CONTAINS[c] %@ AND make CONTAINS[c] %@ AND model CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate4 = NSPredicate(format: "modelcode CONTAINS[c] %@ AND model CONTAINS[c] %@ AND make CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate5 = NSPredicate(format: "model CONTAINS[c] %@ AND make CONTAINS[c] %@ AND modelcode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate6 = NSPredicate(format: "make CONTAINS[c] %@ AND modelcode CONTAINS[c] %@ AND model CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate7 = NSPredicate(format: "make CONTAINS[c] %@ AND model CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate8 = NSPredicate(format: "model CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@ AND make CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate9 = NSPredicate(format: "gates_Part_Number CONTAINS[c] %@ AND make CONTAINS[c] %@ AND model CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate10 = NSPredicate(format: "gates_Part_Number CONTAINS[c] %@ AND model CONTAINS[c] %@ AND make CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate11 = NSPredicate(format: "model CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@ AND model CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate12 = NSPredicate(format: "make CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@ AND model CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate13 = NSPredicate(format: "make CONTAINS[c] %@ AND model CONTAINS[c] %@ AND enginecode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate14 = NSPredicate(format: "model CONTAINS[c] %@ AND enginecode CONTAINS[c] %@ AND make CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate15 = NSPredicate(format: "enginecode CONTAINS[c] %@ AND make CONTAINS[c] %@ AND model CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate16 = NSPredicate(format: "enginecode CONTAINS[c] %@ AND model CONTAINS[c] %@ AND make CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate17 = NSPredicate(format: "model CONTAINS[c] %@ AND make CONTAINS[c] %@ AND enginecode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate18 = NSPredicate(format: "make CONTAINS[c] %@ AND enginecode CONTAINS[c] %@ AND model CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate19 = NSPredicate(format: "make CONTAINS[c] %@ AND modelcode CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate20 = NSPredicate(format: "modelcode CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@ AND make CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate21 = NSPredicate(format: "gates_Part_Number CONTAINS[c] %@ AND make CONTAINS[c] %@ AND modelcode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate22 = NSPredicate(format: "gates_Part_Number CONTAINS[c] %@ AND modelcode CONTAINS[c] %@ AND make CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate23 = NSPredicate(format: "modelcode CONTAINS[c] %@ AND make CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate24 = NSPredicate(format: "make CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@ AND modelcode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate25 = NSPredicate(format: "make CONTAINS[c] %@ AND modelcode CONTAINS[c] %@ AND enginecode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate26 = NSPredicate(format: "modelcode CONTAINS[c] %@ AND enginecode CONTAINS[c] %@ AND make CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate27 = NSPredicate(format: "enginecode CONTAINS[c] %@ AND make CONTAINS[c] %@ AND modelcode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate28 = NSPredicate(format: "enginecode CONTAINS[c] %@ AND modelcode CONTAINS[c] %@ AND make CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate29 = NSPredicate(format: "modelcode CONTAINS[c] %@ AND make CONTAINS[c] %@ AND enginecode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate30 = NSPredicate(format: "make CONTAINS[c] %@ AND enginecode CONTAINS[c] %@ AND modelcode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate31 = NSPredicate(format: "make CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@ AND enginecode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate32 = NSPredicate(format: "gates_Part_Number CONTAINS[c] %@ AND enginecode CONTAINS[c] %@ AND make CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate33 = NSPredicate(format: "enginecode CONTAINS[c] %@ AND make CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate34 = NSPredicate(format: "enginecode CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@ AND make CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate35 = NSPredicate(format: "gates_Part_Number CONTAINS[c] %@ AND make CONTAINS[c] %@ AND enginecode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate36 = NSPredicate(format: "make CONTAINS[c] %@ AND enginecode CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate37 = NSPredicate(format: "model CONTAINS[c] %@ AND modelcode CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate38 = NSPredicate(format: "modelcode CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@ AND model CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate39 = NSPredicate(format: "gates_Part_Number CONTAINS[c] %@ AND model CONTAINS[c] %@ AND modelcode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate40 = NSPredicate(format: "gates_Part_Number CONTAINS[c] %@ AND modelcode CONTAINS[c] %@ AND model CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate41 = NSPredicate(format: "modelcode CONTAINS[c] %@ AND model CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate42 = NSPredicate(format: "model CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@ AND modelcode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate43 = NSPredicate(format: "model CONTAINS[c] %@ AND modelcode CONTAINS[c] %@ AND enginecode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate44 = NSPredicate(format: "modelcode CONTAINS[c] %@ AND enginecode CONTAINS[c] %@ AND model CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate45 = NSPredicate(format: "enginecode CONTAINS[c] %@ AND model CONTAINS[c] %@ AND modelcode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate46 = NSPredicate(format: "enginecode CONTAINS[c] %@ AND modelcode CONTAINS[c] %@ AND model CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate47 = NSPredicate(format: "modelcode CONTAINS[c] %@ AND model CONTAINS[c] %@ AND enginecode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate48 = NSPredicate(format: "model CONTAINS[c] %@ AND enginecode CONTAINS[c] %@ AND modelcode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate49 = NSPredicate(format: "model CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@ AND enginecode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate50 = NSPredicate(format: "gates_Part_Number CONTAINS[c] %@ AND enginecode CONTAINS[c] %@ AND model CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate51 = NSPredicate(format: "enginecode CONTAINS[c] %@ AND model CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate52 = NSPredicate(format: "enginecode CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@ AND model CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate53 = NSPredicate(format: "gates_Part_Number CONTAINS[c] %@ AND model CONTAINS[c] %@ AND enginecode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate54 = NSPredicate(format: "model CONTAINS[c] %@ AND enginecode CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate55 = NSPredicate(format: "modelcode CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@ AND enginecode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate56 = NSPredicate(format: "gates_Part_Number CONTAINS[c] %@ AND enginecode CONTAINS[c] %@ AND modelcode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate57 = NSPredicate(format: "enginecode CONTAINS[c] %@ AND modelcode CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate58 = NSPredicate(format: "enginecode CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@ AND modelcode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate59 = NSPredicate(format: "gates_Part_Number CONTAINS[c] %@ AND modelcode CONTAINS[c] %@ AND enginecode CONTAINS[c] %@", argumentArray: partnumbersep)
            predicate60 = NSPredicate(format: "modelcode CONTAINS[c] %@ AND enginecode CONTAINS[c] %@ AND gates_Part_Number CONTAINS[c] %@", argumentArray: partnumbersep)
            finalpredicate = NSCompoundPredicate(type: NSCompoundPredicate.LogicalType.or, subpredicates: [predicate1,predicate2,predicate3,predicate4,predicate5,predicate6,predicate7,predicate8,predicate9,predicate10,predicate11,predicate12,predicate13,predicate14,predicate15,predicate16,predicate17,predicate18,predicate19,predicate20,predicate21,predicate22,predicate23,predicate24,predicate25,predicate26,predicate27,predicate28,predicate29,predicate30,predicate31,predicate32,predicate33,predicate34,predicate35,predicate36,predicate37,predicate38,predicate39,predicate40,predicate41,predicate42,predicate43,predicate44,predicate45,predicate46,predicate47,predicate48,predicate49,predicate50,predicate51,predicate52,predicate53,predicate54,predicate55,predicate56,predicate57,predicate58,predicate59,predicate60,])
            
        default:
            predicate1 = NSPredicate(format: "make CONTAINS[c] %@","xxxxxxxxxx")
            finalpredicate = NSCompoundPredicate(type: NSCompoundPredicate.LogicalType.or, subpredicates: [predicate1])
            displayMyAlertMessage("Please only use maximum of two concatenate (+) symbols between keywords!")
        }
        
        
        request.predicate = finalpredicate
        request.returnsDistinctResults = true
        request.resultType = .dictionaryResultType
        request.propertiesToFetch = ["make","model","modelcode","stroke","year_From","month_From","year_Till","month_Till","part_Description","gates_Part_Number","enginecode","equipment","equipment_2","equipment_Date_From","equipment_Date_To","segment"]
        request.returnsObjectsAsFaults = false
        
        do {
            
            let results = try context.fetch(request)
            
            if results.count > 0
            {
                for result in results
                {
                    //
                    if let segment = (result as AnyObject).value(forKey: "make") as? String
                    {
                        
                        dataGet.append(segment)
                        print(segment)
                    }
                    if let segment = (result as AnyObject).value(forKey: "model") as? String
                    {
                        
                        dataGet1.append(segment)
                    }
                    if let segment = (result as AnyObject).value(forKey: "modelcode") as? String
                    {
                        
                        dataGet2.append(segment)
                        print(segment)
                    }
                    if let segment = (result as AnyObject).value(forKey: "stroke") as? String
                    {
                        
                        dataGet3.append(segment)
                        print(segment)
                    }
                    if let segment = (result as AnyObject).value(forKey: "year_From") as? String
                    {
                        
                        dataGet4.append(segment)
                        print(segment)
                    }
                    if let segment = (result as AnyObject).value(forKey: "month_From") as? String
                    {
                        
                        dataGet5.append(segment)
                        print(segment)
                    }
                    if let segment = (result as AnyObject).value(forKey: "year_Till") as? String
                    {
                        
                        dataGet6.append(segment)
                        print(segment)
                    }
                    if let segment = (result as AnyObject).value(forKey: "month_Till") as? String
                    {
                        
                        dataGet7.append(segment)
                        print(segment)
                    }
                    if let segment = (result as AnyObject).value(forKey: "part_Description") as? String
                    {
                        
                        dataGet8.append(segment)
                        print(segment)
                        
                    }
                    if let segment = (result as AnyObject).value(forKey: "gates_Part_Number") as? String
                    {
                        
                        dataGet9.append(segment)
                        print(segment)
                    }
                    if let segment = (result as AnyObject).value(forKey: "enginecode") as? String
                    {
                        
                        dataGet10.append(segment)
                        print(segment)
                    }
                    if let segment = (result as AnyObject).value(forKey: "equipment") as? String
                    {
                        
                        dataGet11.append(segment)
                        print(segment)
                    }
                    if let segment = (result as AnyObject).value(forKey: "equipment_2") as? String
                    {
                        
                        dataGet12.append(segment)
                        print(segment)
                        
                    }
                    if let segment = (result as AnyObject).value(forKey: "equipment_Date_From") as? String
                    {
                        
                        dataGet13.append(segment)
                        print(segment)
                    }
                    if let segment = (result as AnyObject).value(forKey: "equipment_Date_To") as? String
                    {
                        
                        dataGet14.append(segment)
                        print(segment)
                    }
                    
                    if let segment = (result as AnyObject).value(forKey: "segment") as? String
                    {
                        
                        dataGet15.append(segment)
                        print(segment)
                    }
                    
                    //
                }
                
            }
            
        }
        catch
        {
            
        }
        
    }
    
    ///// tops buttons
    let screenSize: CGRect = UIScreen.main.bounds
    let btn1 = UIButton(frame: CGRect(x: 0, y: 0, width: 20, height: 15))
    var isclicked:Bool! = true
    var menuclicked = false
    let btn2 = UIButton(type: .custom)
    let customView = UIView()
    let btn3 = UIButton()
    let myView = sildermenu()
    
    
    let signoutUser:UIButton = {
        let screenSize: CGRect = UIScreen.main.bounds
        let button = UIButton()
        button.frame = CGRect(x: screenSize.maxX - 140 , y: 25, width: 140, height: 20)
        let image:UIImage = UIImage(named: "signout")!
        button.imageEdgeInsets = UIEdgeInsets(top: 0,left: 14,bottom: 0,right: 100)
        button.setImage(image, for:.normal)
        button.addTarget(self, action: #selector(userSignOut), for: .touchUpInside)
        
        return button

        
    }()
    
    
    
    
    func userSignOut(){
        
        UserDefaults.standard.set(false,forKey:"distribuUser");
        someTextView2.isHidden = true
        signoutUser.isHidden = true
        let myAlert = UIAlertController(title:"Gates Finder", message:"Signed out successfully", preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
            
            
        })
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }

    
    let someTextView:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.minX + 60 , y: 25, width: 100, height: 20)
        let usertype = UserDefaults.standard.string(forKey: "name")
        theUserName.text = usertype
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    let someTextView2:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.maxX - 80 , y: 25, width: 80, height: 20)
        theUserName.text = "Sign Out"
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    
    
    let someImageView: UIImageView = {
        let screenSize: CGRect = UIScreen.main.bounds
        let profilepic = UserDefaults.standard.object(forKey: "profileImage")
        let theImageView = UIImageView()
        if profilepic != nil {
            theImageView.image = UIImage(data: profilepic as! Data)
            
        }
        else {
            theImageView.image = UIImage(named:"imagesss")
            
        }
        
        theImageView.frame = CGRect(x: screenSize.minX + 10, y: 16, width: 35, height: 35)
        theImageView.layer.borderWidth = 1.0
        theImageView.layer.masksToBounds = false
        theImageView.layer.borderColor = UIColor.black.cgColor
        theImageView.layer.cornerRadius = theImageView.frame.size.width/2
        theImageView.clipsToBounds = true
        theImageView.translatesAutoresizingMaskIntoConstraints = true //You need to call this property so the image is added to your view
        return theImageView
    }()
    func menubar() {
        let distrubUser = UserDefaults.standard.bool(forKey: "distribuUser")
        
        btn1.setImage(UIImage(named: "NavMenu"), for: .normal)
        btn1.addTarget(self, action: #selector(action), for: .touchUpInside)
        btn2.setImage(UIImage(named: "drowarrow"), for: .normal)
        btn2.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn2.addTarget(self, action: #selector(signout), for: .touchUpInside)
        btn3.setImage(UIImage(named: "left-arrow-key"), for: .normal)
        btn3.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn3.addTarget(self, action: #selector(back), for: .touchUpInside)
        
        
        if distrubUser == true {
            someTextView2.isHidden = false
            signoutUser.isHidden = false
            
        }
        else {
            someTextView2.isHidden = true
            signoutUser.isHidden = true
        }
        let item1 = UIBarButtonItem(customView: btn1)
        let item2 = UIBarButtonItem(customView: btn2)
        let item3 = UIBarButtonItem(customView: btn3)
        self.navigationItem.setRightBarButtonItems([item2,item1], animated: true)
        self.navigationItem.setLeftBarButtonItems([item3], animated: true)
        
        
        
    }
    func back() {
        _ = self.navigationController?.popViewController(animated: true)
        
        dismiss(animated: true, completion: nil)
        
    }
    
    
    func action(sender:UIButton!) {
        menubaraction()
    }
    
    
    
    func menubaraction() {
        let myviewsize = myView.bounds
        
        
        if (menuclicked){
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            })
            
        }
        else
        {
            self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: self.screenSize.width/2, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: myviewsize.width, height:myviewsize.height)
            })
            
            
            
            
        }
        menuclicked = !menuclicked
        
        view.addSubview(myView)
        
    }
    override func viewDidAppear(_ animated: Bool) {
        
        let myviewsize = myView.bounds
        if (menuclicked){
            
            self.myView.frame = CGRect(x: 0, y: 65, width: 0, height:self.screenSize.height - 65)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            menuclicked = !menuclicked
            
        }
        menubar()
    }
    func signout(){
        
        if isclicked == true {
            isclicked = false
            
            customView.frame = CGRect.init(x: screenSize.minX, y: 64, width: screenSize.width, height: 65)
            customView.backgroundColor = UIColor.white     //give color to the view
            
            self.view.addSubview(customView)
            self.customView.addSubview(someImageView)
            self.customView.addSubview(someTextView)
            self.customView.addSubview(someTextView2)
            self.customView.addSubview(signoutUser)
            
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI))
                
            }
            UIView.animate(withDuration: 0.2, delay: 0.2, options: UIViewAnimationOptions.curveEaseIn, animations: {
                self.customView.alpha = 1.0
                
                
            }, completion: nil)
            
            
            
        }
        else
        {
            isclicked = true
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI * 2))
            }
            
            
            UIView.animate(withDuration: 1.0, animations: {
                self.customView.frame.origin.y = self.view.frame.origin.y - self.view.frame.size.height
                
            })
            
        }
        
        
    }
    
    
    func displayMyAlertMessage(_ userMessage:String)
    {
        
        let myAlert = UIAlertController(title:"Gates Finder", message:userMessage, preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in

            _ = self.navigationController?.popViewController(animated: true)
            
            self.dismiss(animated: true, completion: nil)
            
        })
            
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }
}
