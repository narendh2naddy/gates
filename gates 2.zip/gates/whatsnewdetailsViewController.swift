//
//  whatsnewdetailsViewController.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 15/03/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit

class whatsnewdetailsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource  {

    @IBOutlet var tableView: UITableView!

    var value:Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()

        self.tableView.delegate = self
        self.tableView.dataSource = self
        tableView.alwaysBounceVertical = false
        // Do any additional setup after loading the view.
    }

    override func viewDidAppear(_ animated: Bool) {
        if (tableView.contentSize.height < tableView.frame.size.height) {
            tableView.isScrollEnabled = false;
        }
        else {
            tableView.isScrollEnabled = true;
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return  1
        
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let cond = 0
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath )
//        if value == cond {
//            cell.label1.text = "Petrol"
//            cell.lbl3.text = "1"
//            cell.lbl5.text = "VVTi"
//            cell.lbl6.text = "2013"
//            cell.lbl7.text = "11"
//            cell.lbl8.text = "2016"
//            cell.lbl9.text = "5"
       
        
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        
        
        return "  \t\t Fuel \t\t\t Storke \t\t\t Type \t\t\t Year From  \t\t\t\t\t   Month From  \t\t\t\t   Year Till \t\t\t\t     Month Till \t\t\t\t             More "
    }
    
    func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int)
    {
        let header = view as! UITableViewHeaderFooterView
        header.textLabel?.font = UIFont(name: "Futura", size: 11)
        header.textLabel?.textColor = UIColor.lightGray
    }









}
