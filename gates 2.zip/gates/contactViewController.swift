//
//  contactViewController.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 14/03/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit
import MapKit

class contactViewController: UIViewController,UICollectionViewDelegate, UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
       @IBOutlet var img: UIImageView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var facebook: UIButton!
    @IBOutlet weak var linkedin: UIButton!
    @IBOutlet weak var youtube: UIButton!
    
    let conutry = [" SINGAPORE (East Asia & India) HQ"," SINGAPORE"," MALAYSIA","THAILAND (Bangkok)","THAILAND (Rayong)","AUSTRALIA","JAPAN (Tokyo)","JAPAN (Nara)","KOREA (Seoul)","KOREA (Dae-Gu)","INDIA (Gurgaon)","INDIA (Chennai)","INDIA (Lalru)","INDIA (Faridabad)","INDIA (Pune)"]
    
    
    let address = ["3A International Business Park \nUnit: #10-01/05 ICON@IBP, Tower A \nSingapore 609935 \n Tel: +65-6832-2368 \n Fax:  +65-6659-1607","40 Gul Circle \nSingapore 629575 \nTel: +65-6861-7322 \nFax:  +65-6861-7631","11th Floor, Unit A1101, West Wing Wisma Consplant 2,\nNo. 7 Jalan SS16/1,47500 Subang Jaya,\nSelangor Darul Ehsan,\n Malaysia \nTel: +60-3-5033 4588 \nFax: +60-3-5033 4546","Bhiraj Tower at Bitec 14th Floor, Unit 1401\n 4345 Sukhumvit Road, Bang Na Bangkok \nThailand 10260 \nTel: +66-2-399-5925 \nFax: +66-2-399-5926","Eastern Seaboard Industrial Estate, 64/86 Moo 4,\nT.Pluakdang, A.Pluakdang, Rayong 21140,\n Thailand \nTel: +66-38-954-361 \nFax: +66-38-954-362","101 Sheffield Road, Welshpool, WA 6106 \nWestern Australia\nTel:  +61-8-9258-8399","8-2-1 Ginza, 5F \n Chuo-ku,\n Tokyo 104-0061, \nJapan \nTel:+81-3-6744-2730","172, Ikezawa-cho, Yamatokoriyama-City,\nNara 639-1032,\n Japan.\nTel: +81-743-56-1361","24, Beoman-ro 16-gil, Geumcheon-Gu, \nSeoul, \nKorea 08602\nTel:+82-2-2107-2315","523, Non-Gong-Ro, Non-Gong Eup, Dal-Sung Gun,\nDae-Gu, \nKorea 711-855 \n Tel:+82-53-610-6100","3rd Floor ,Building #10, Tower C,\nDLF Cyber City, Phase 2,\nGurgaon, Haryana, 122002 \nTel:+91-124-493-3500","F-19, Sipcot Industrial Park,\nPondur A, Sriperumbudur, \n Chennai,Tamil Nadu 602106, \nIndia \nTel:+91-44-4711-5100","Ambala-Chandigarh Higway \n Lalru, \n Punjab – 140501 \nTel:+91-176-2506-888","Plot # 133-134, Sec – 59,\nPhase – 2, Industrial Area\nFaridabad, Haryana 121004 \nTel: +91-129-4288-770","Plot No. K-8, Khalumbre,\nPune, Maharashtra  410501\nTel:+91-213-5690-398"]
    
   let latearr = ["1.328569","1.314475","3.081567","13.670038","13.004685","31.994881","35.669116","34.614345","37.465428","35.740517","28.494578","12.934609","30.457620","28.315655","18.752332"]
    let longarr = ["103.748675","103.664156","101.583539","100.605903","101.162380","115.973448","139.764891","135.775297","126.895003","128.464990","77.088905","79.920121","76.787261","77.310010","73.777018"]
   
    
   
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let backgroundImage = UIImageView(frame: UIScreen.main.bounds)
        backgroundImage.image = UIImage(named: "background-2")
        backgroundImage.contentMode =  UIViewContentMode.scaleAspectFill
        self.view.insertSubview(backgroundImage, at: 0)
        
        self.title = "Contact Us"
        menubar()
        self.collectionView.delegate = self
        self.collectionView.dataSource = self

   img.image = UIImage(named: "title_image.png")
        

        facebook.layer.cornerRadius = facebook.frame.height/2
        linkedin.layer.cornerRadius = linkedin.frame.height/2
        youtube.layer.cornerRadius = youtube.frame.height/2
        
    }

    
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//        let width = UIScreen.main.bounds.width
//        let height = UIScreen.main.bounds.height
//
//        return CGSize(width:(width - 10)/2, height:height/3) // width & height are the same to make a square cell
//    }

    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return conutry.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier:"cell", for: indexPath) as! contactCollectionViewCell
       
        cell.heading.text = conutry[indexPath.row]
        cell.address.text = address[indexPath.row]
        cell.map.tag = indexPath.row
        cell.map.addTarget(self, action:#selector(handleRegister), for: .touchUpInside)
        cell.map.layer.cornerRadius = 5
        
        return cell
    }
    
//    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
//        let footer = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionElementKindSectionFooter, withReuseIdentifier: "footercell", for: indexPath)
//        
//        
//        return footer
//    }
//    
//    
    func handleRegister(_ sender : UIButton)  {
        
        
       openMapForPlace(late:Double(latearr[sender.tag])!,long:Double(longarr[sender.tag])!,place:address[sender.tag])
        
    }
    
    
    
    ///// tops buttons
    let screenSize: CGRect = UIScreen.main.bounds
    let btn1 = UIButton(frame: CGRect(x: 0, y: 0, width: 20, height: 15))
    var isclicked:Bool! = true
    var menuclicked = false
    let btn2 = UIButton(type: .custom)
    let customView = UIView()
    let btn3 = UIButton()
    let myView = sildermenu()
    
    
    let signoutUser:UIButton = {
        let screenSize: CGRect = UIScreen.main.bounds
        let button = UIButton()
        button.frame = CGRect(x: screenSize.maxX - 140 , y: 25, width: 140, height: 20)
        let image:UIImage = UIImage(named: "signout")!
        button.imageEdgeInsets = UIEdgeInsets(top: 0,left: 14,bottom: 0,right: 100)
        button.setImage(image, for:.normal)
        button.addTarget(self, action: #selector(userSignOut), for: .touchUpInside)
        
        return button

        
    }()
    
    
    
    
    func userSignOut(){
        
        UserDefaults.standard.set(false,forKey:"distribuUser");
        someTextView2.isHidden = true
        signoutUser.isHidden = true
        let myAlert = UIAlertController(title:"Gates Finder", message:"Signed out successfully", preferredStyle: UIAlertControllerStyle.alert);
        
        let okAction = UIAlertAction(title:"Ok", style:UIAlertActionStyle.default, handler: {(action) -> Void in
            
            
        })
        
        myAlert.addAction(okAction);
        
        self.present(myAlert, animated:true, completion:nil);
        
    }

    
    let someTextView:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.minX + 60 , y: 25, width: 100, height: 20)
        let usertype = UserDefaults.standard.string(forKey: "name")
        theUserName.text = usertype
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    let someTextView2:UILabel = {
        let screenSize: CGRect = UIScreen.main.bounds
        let theUserName = UILabel()
        theUserName.frame = CGRect(x: screenSize.maxX - 80 , y: 25, width: 80, height: 20)
        theUserName.text = "Sign Out"
        theUserName.font = UIFont.boldSystemFont(ofSize: theUserName.font.pointSize)
        theUserName.translatesAutoresizingMaskIntoConstraints = true
        return theUserName
    }()
    
    
    let someImageView: UIImageView = {
        let screenSize: CGRect = UIScreen.main.bounds
        let profilepic = UserDefaults.standard.object(forKey: "profileImage")
        let theImageView = UIImageView()
        if profilepic != nil {
            theImageView.image = UIImage(data: profilepic as! Data)
            
        }
        else {
            theImageView.image = UIImage(named:"imagesss")
            
        }
        
        theImageView.frame = CGRect(x: screenSize.minX + 10, y: 16, width: 35, height: 35)
        theImageView.layer.borderWidth = 1.0
        theImageView.layer.masksToBounds = false
        theImageView.layer.borderColor = UIColor.black.cgColor
        theImageView.layer.cornerRadius = theImageView.frame.size.width/2
        theImageView.clipsToBounds = true
        theImageView.translatesAutoresizingMaskIntoConstraints = true //You need to call this property so the image is added to your view
        return theImageView
    }()
    func menubar() {
        let distrubUser = UserDefaults.standard.bool(forKey: "distribuUser")
        
        btn1.setImage(UIImage(named: "NavMenu"), for: .normal)
        btn1.addTarget(self, action: #selector(action), for: .touchUpInside)
        btn2.setImage(UIImage(named: "drowarrow"), for: .normal)
        btn2.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn2.addTarget(self, action: #selector(signout), for: .touchUpInside)
        btn3.setImage(UIImage(named: "left-arrow-key"), for: .normal)
        btn3.frame = CGRect(x: 0, y: 0, width: 20, height: 20)
        btn3.addTarget(self, action: #selector(back), for: .touchUpInside)
        
        
        if distrubUser == true {
            someTextView2.isHidden = false
            signoutUser.isHidden = false
            
        }
        else {
            someTextView2.isHidden = true
            signoutUser.isHidden = true
        }
        let item1 = UIBarButtonItem(customView: btn1)
        let item2 = UIBarButtonItem(customView: btn2)
        let item3 = UIBarButtonItem(customView: btn3)
        self.navigationItem.setRightBarButtonItems([item2,item1], animated: true)
        self.navigationItem.setLeftBarButtonItems([item3], animated: true)
        
        
    }
    func back() {
        _ = self.navigationController?.popViewController(animated: true)
        
        dismiss(animated: true, completion: nil)
        
    }
    
    
    func action(sender:UIButton!) {
        menubaraction()
    }
    
    
    
    func menubaraction() {
        let myviewsize = myView.bounds
        
        
        if (menuclicked){
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            })
            
        }
        else
        {
            self.myView.frame = CGRect(x: 0, y: 64, width: 0, height:self.screenSize.height - 64)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            UIView.animate(withDuration: 0.2, animations: {
                self.myView.frame = CGRect(x: 0, y: 64, width: self.screenSize.width/2, height:self.screenSize.height - 64)
                self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: myviewsize.width, height:myviewsize.height)
            })
            
            
            
            
        }
        menuclicked = !menuclicked
        
        view.addSubview(myView)
        
    }
    override func viewDidAppear(_ animated: Bool) {
        
        let myviewsize = myView.bounds
        if (menuclicked){
            
            self.myView.frame = CGRect(x: 0, y: 65, width: 0, height:self.screenSize.height - 65)
            self.myView.stackViewft.frame = CGRect(x: 0, y: 0, width: 0, height:myviewsize.height)
            menuclicked = !menuclicked
            
        }
        menubar()
    }
    func signout(){
        
        if isclicked == true {
            isclicked = false
            
            customView.frame = CGRect.init(x: screenSize.minX, y: 64, width: screenSize.width, height: 65)
            customView.backgroundColor = UIColor.white     //give color to the view
            
            self.view.addSubview(customView)
            self.customView.addSubview(someImageView)
            self.customView.addSubview(someTextView)
            self.customView.addSubview(someTextView2)
            self.customView.addSubview(signoutUser)
            
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI))
                
            }
            UIView.animate(withDuration: 0.2, delay: 0.2, options: UIViewAnimationOptions.curveEaseIn, animations: {
                self.customView.alpha = 1.0
                
                
            }, completion: nil)
            
            
            
        }
        else
        {
            isclicked = true
            UIView.animate(withDuration: 0.5) { () -> Void in
                
                self.btn2.transform = CGAffineTransform(rotationAngle: CGFloat(M_PI * 2))
            }
            
            
            UIView.animate(withDuration: 1.0, animations: {
                self.customView.frame.origin.y = self.view.frame.origin.y - self.view.frame.size.height
                
            })
            
        }
        
        
    }
    

   

   
    func openMapForPlace(late:Double,long:Double,place:String) {
        
        let latitude: CLLocationDegrees = late
        let longitude: CLLocationDegrees = long
        
        let regionDistance:CLLocationDistance = 10
        let coordinates = CLLocationCoordinate2DMake(latitude, longitude)
        let regionSpan = MKCoordinateRegionMakeWithDistance(coordinates, regionDistance, regionDistance)
        let options = [
            MKLaunchOptionsMapCenterKey: NSValue(mkCoordinate: regionSpan.center),
            MKLaunchOptionsMapSpanKey: NSValue(mkCoordinateSpan: regionSpan.span)
        ]
        let placemark = MKPlacemark(coordinate: coordinates, addressDictionary: nil)
        let mapItem = MKMapItem(placemark: placemark)
        mapItem.name = place
        mapItem.openInMaps(launchOptions: options)
    }

    @IBAction func facebook(_ sender: Any) {
        if let url = NSURL(string:"https://www.facebook.com/GatesSoutheastAsia/"){ UIApplication.shared.open(url as URL, options: [:], completionHandler: nil) }
    }
    
    
    @IBAction func linkedin(_ sender: Any) {
        if let url = NSURL(string:"https://www.linkedin.com/company-beta/13391117/"){ UIApplication.shared.open(url as URL, options: [:], completionHandler: nil) }
        
    }
   
    @IBAction func gateslinkvideo(_ sender: Any) {
        if let url = NSURL(string:"https://www.youtube.com/channel/UCXTu89ceeqTBaADSpw-W6GA"){ UIApplication.shared.open(url as URL, options: [:], completionHandler: nil) }

    }
}
