//
//  whatsnewnewpagecellCollectionViewCell.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 09/09/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit

class whatsnewnewpagecellCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var whatsImage: UIImageView!
    
    @IBOutlet weak var labeltoshow: UILabel!
    @IBOutlet weak var productName: UILabel!
    
    @IBOutlet weak var moreDetalis: UIButton!
    @IBOutlet weak var downloadPdf: UIButton!
    
    
    
}
