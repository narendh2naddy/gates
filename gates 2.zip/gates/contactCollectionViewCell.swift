//
//  contactCollectionViewCell.swift
//  Gates Cataloge-ASEAN Extension
//
//  Created by Kumaravel Raman on 08/06/17.
//  Copyright © 2017 Brainmagic. All rights reserved.
//

import UIKit

class contactCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var heading: UILabel!
    @IBOutlet weak var address: UITextView!

    @IBOutlet weak var map: UIButton!
}
